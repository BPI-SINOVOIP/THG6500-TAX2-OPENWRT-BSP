/****************************************************************************
**
** Copyright (C) 2020 SoftAtHome. All rights reserved.
**
** SoftAtHome reserves all rights not expressly granted herein.
**
** - DISCLAIMER OF WARRANTY -
**
** THIS FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
** EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
** WARRANTIES OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
** PURPOSE.
**
** THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE SOURCE
** CODE IS WITH YOU. SHOULD THE SOURCE CODE PROVE DEFECTIVE, YOU
** ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
**
** - LIMITATION OF LIABILITY -
**
** IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
** WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES
** AND/OR DISTRIBUTES THE SOURCE CODE, BE LIABLE TO YOU FOR DAMAGES,
** INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
** ARISING OUT OF THE USE OR INABILITY TO USE THE SOURCE CODE
** (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
** INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE
** OF THE SOURCE CODE TO OPERATE WITH ANY OTHER PROGRAM), EVEN IF SUCH
** HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGES.
**
****************************************************************************/
#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <setjmp.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <cmocka.h>

#include <debug/sahtrace.h>
#include "swla/ttb/swla_ttbVariant.h"
#include "swla/swla_tupleType.h"
#include "swla/types/swla_tupleTypeArray.h"
#include "swl/swl_common.h"
#include "swla/swla_conversion.h"
#include "swla/swla_commonLib.h"
#include "swla/swla_type.h"
#include "test-toolbox/ttb_assert.h"

#define NR_TYPES 3
#define NR_VALUES 4

#define MY_TEST_TABLE_VAR(X, Y) \
    X(Y, gtSwl_type_int32, index) \
    X(Y, gtSwl_type_int64, key) \
    X(Y, gtSwl_type_charPtr, val)
SWL_TT(myTestTTType, swl_myTestTT_t, MY_TEST_TABLE_VAR, structMod);


swl_myTestTT_t myTestTable[NR_VALUES] = {
    {1, 100, "test1"},
    {2, -200, "test2"},
    {-8852, 289870, "foobar"},
    {8851, -289869, "barfoo"},
};

swl_myTestTT_t myTestTableDup[NR_VALUES] = {
    {1, 100, "test1"},
    {1, -200, "test2"},
    {2, -200, "test3"},
    {3, -300, "test3"},
};

swl_myTestTT_t zeroValues = {0, 0, NULL};


char* names[NR_TYPES] = {"SmallInt", "BigInt", "String"};

const char* columnArrays[NR_TYPES] = {
    "1,2,-8852,8851",
    "100,-200,289870,-289869",
    "test1,test2,foobar,barfoo"
};

/**
 * Strings with one offset, for offset testing
 */
const char* columnArraysOffset[NR_TYPES] = {
    "2,-8852,8851,1",
    "-200,289870,-289869,100",
    "test2,foobar,barfoo,test1"
};

#define NR_OTHER_DATA 2

swl_myTestTT_t otherData[NR_OTHER_DATA] = {
    {5, 500, "notHere"},
    {-5, -500, "alsoNotHere"},
};


static void test_swl_tta_toMapOfChar(void** state _UNUSED) {

    amxc_var_t myVar;

    char nameBuffer[32] = {0};
    for(size_t i = 0; i <= NR_VALUES; i++) {
        amxc_var_init(&myVar);
        amxc_var_set_type(&myVar, AMXC_VAR_ID_HTABLE);
        swl_tta_toMapOfChar(&myVar, names, &myTestTTType, myTestTable, i);
        snprintf(nameBuffer, sizeof(nameBuffer), "toMap/test_%zu.txt", i);
        swl_ttbVariant_assertToFileMatchesFile(&myVar, nameBuffer);
        amxc_var_clean(&myVar);
    }
}


static void test_swl_tta_fromMapOfChar(void** state _UNUSED) {

    amxc_var_t myVar;
    amxc_var_init(&myVar);
    amxc_var_set_type(&myVar, AMXC_VAR_ID_HTABLE);


    swl_tta_toMapOfChar(&myVar, names, &myTestTTType, myTestTable, NR_VALUES);


    swl_myTestTT_t testData[NR_VALUES];
    memset(testData, 0, sizeof(testData));

    swl_tta_fromMapOfChar(&myVar, names, &myTestTTType, testData, NR_VALUES);

    swl_ttb_assertBigTypeArrayEquals(&myTestTTType.type, testData, NR_VALUES, myTestTable, NR_VALUES);

    swl_type_arrayCleanup(&myTestTTType.type, testData, NR_VALUES);
    amxc_var_clean(&myVar);
}

static void test_swl_tta_mapAddColumn(void** state _UNUSED) {

    amxc_var_t myVar;

    char nameBuffer[32] = {0};
    for(size_t i = 0; i < NR_TYPES; i++) {
        amxc_var_init(&myVar);
        amxc_var_set_type(&myVar, AMXC_VAR_ID_HTABLE);
        swl_tta_mapAddColumnChar(&myVar, names[i], &myTestTTType, myTestTable, NR_VALUES, i);
        snprintf(nameBuffer, sizeof(nameBuffer), "mapAddColumn/test_%zu.txt", i);
        swl_ttbVariant_assertToFileMatchesFile(&myVar, nameBuffer);
        amxc_var_clean(&myVar);

    }

    for(size_t i = 0; i < NR_TYPES; i++) {
        amxc_var_init(&myVar);
        amxc_var_set_type(&myVar, AMXC_VAR_ID_HTABLE);
        swl_tta_mapAddColumnCharOffset(&myVar, names[i], &myTestTTType, myTestTable, NR_VALUES, i, 1, -1);
        snprintf(nameBuffer, sizeof(nameBuffer), "mapAddColumn/testOffset_%zu.txt", i);
        swl_ttbVariant_assertToFileMatchesFile(&myVar, nameBuffer);
        amxc_var_clean(&myVar);
    }
}

static void test_swl_tta_toListOfMaps(void** state _UNUSED) {

    amxc_var_t myVar;

    char nameBuffer[32] = {0};
    for(size_t i = 0; i <= NR_VALUES; i++) {
        amxc_var_init(&myVar);
        amxc_var_set_type(&myVar, AMXC_VAR_ID_LIST);

        swl_tta_toListOfMaps(&myVar, names, &myTestTTType, myTestTable, i);
        snprintf(nameBuffer, sizeof(nameBuffer), "toList/test_%zu.txt", i);
        swl_ttbVariant_assertToFileMatchesFile(&myVar, nameBuffer);
        amxc_var_clean(&myVar);
    }
}


static void test_swl_tta_fromListOfMaps(void** state _UNUSED) {

    amxc_var_t myVar;
    amxc_var_init(&myVar);
    amxc_var_set_type(&myVar, AMXC_VAR_ID_LIST);



    swl_tta_toListOfMaps(&myVar, names, &myTestTTType, myTestTable, NR_VALUES);


    swl_myTestTT_t testData[NR_VALUES];
    memset(testData, 0, sizeof(testData));


    swl_tta_fromListOfMaps(&myVar, names, &myTestTTType, testData, NR_VALUES);
    swl_ttb_assertBigTypeArrayEquals(&myTestTTType.type, testData, NR_VALUES, myTestTable, NR_VALUES);


    swl_type_arrayCleanup(&myTestTTType.type, testData, NR_VALUES);
    amxc_var_clean(&myVar);

}

static int setup_suite(void** state _UNUSED) {
    return 0;
}

static int teardown_suite(void** state _UNUSED) {
    return 0;
}

int main(int argc _UNUSED, char* argv[] _UNUSED) {
    sahTraceOpen(__FILE__, TRACE_TYPE_STDERR);
    if(!sahTraceIsOpen()) {
        fprintf(stderr, "FAILED to open SAH TRACE\n");
    }
    sahTraceSetLevel(TRACE_LEVEL_WARNING);
    sahTraceSetTimeFormat(TRACE_TIME_APP_SECONDS);
    sahTraceAddZone(sahTraceLevel(), "swlConv");
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_swl_tta_toMapOfChar),
        cmocka_unit_test(test_swl_tta_fromMapOfChar),
        cmocka_unit_test(test_swl_tta_mapAddColumn),
        cmocka_unit_test(test_swl_tta_toListOfMaps),
        cmocka_unit_test(test_swl_tta_fromListOfMaps),
    };
    int rc = 0;
    ttb_util_setFilter();
    rc = cmocka_run_group_tests(tests, setup_suite, teardown_suite);
    sahTraceClose();
    return rc;
}

