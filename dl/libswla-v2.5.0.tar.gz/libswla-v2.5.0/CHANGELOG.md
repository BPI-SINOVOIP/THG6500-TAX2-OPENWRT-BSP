# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release v2.5.0 - 2023-02-07(08:06:28 +0000)

### Other

- restore swla exec apis

## Release v2.4.1 - 2023-01-16(14:23:47 +0000)

### Other

- - Header files not exported
- - Fix variant printing

## Release v2.4.0 - 2023-01-02(09:23:25 +0000)

### Other

- - add Tuple Type array map functions

## Release v2.3.1 - 2022-12-21(10:24:49 +0000)

### Other

- - fix circ table

## Release v2.3.0 - 2022-12-19(16:11:36 +0000)

### Other

- - add File compare functions
- remove squash commits as no needed anymore

## Release v2.2.0 - 2022-11-29(09:49:22 +0000)

### Other

- Add getReferenceObject api

## Release v2.1.0 - 2022-11-09(16:26:15 +0000)

### Other

- squash commits before opensourcing them to make sahbot principal author for SoftAtHome deliveries
- - Add collection type

## Release v2.0.3 - 2022-10-07(08:59:06 +0000)

### Other

- build with -Wformat -Wformat-security

## Release v2.0.2 - 2022-10-05(13:08:04 +0000)

### Other

- - Add tupleType type functions and test example
- - update type and obj tests

## Release v2.0.1 - 2022-09-28(07:44:46 +0000)

### Other

- - Fix testing
- - Add named tuple type

## Release v2.0.0 - 2022-09-27(07:22:29 +0000)

### Other

- [prpl] clean swl swla headers install

## Release v1.1.1 - 2022-06-17(14:00:41 +0000)

### Other

- - move swl_circTable_getMatchingTuple function to libswlc

## Release v1.1.0 - 2022-06-17(09:10:18 +0000)

### Other

- - [prplMesh_WHM] provide STA capabilities for STA connected BWL Event
- [amx] ambiorix swlc awla and wld/pwhm

## Release v1.0.3 - 2022-06-09(09:40:16 +0000)

### Other

- revert ambiorix template

## Release v1.0.2 - 2022-06-08(08:24:31 +0000)

### Other

- disable complexity check

## Release v1.0.1 - 2022-06-07(07:15:30 +0000)

### Other

- include ambiorix template for ambiorix components
- [prpl] opensource pwhm swla and swlc

