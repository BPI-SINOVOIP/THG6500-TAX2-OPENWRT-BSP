/****************************************************************************
**
** Copyright (C) 2022 SoftAtHome. All rights reserved.
**
** SoftAtHome reserves all rights not expressly granted herein.
**
** - DISCLAIMER OF WARRANTY -
**
** THIS FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
** EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
** WARRANTIES OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
** PURPOSE.
**
** THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE SOURCE
** CODE IS WITH YOU. SHOULD THE SOURCE CODE PROVE DEFECTIVE, YOU
** ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
**
** - LIMITATION OF LIABILITY -
**
** IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
** WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES
** AND/OR DISTRIBUTES THE SOURCE CODE, BE LIABLE TO YOU FOR DAMAGES,
** INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
** ARISING OUT OF THE USE OR INABILITY TO USE THE SOURCE CODE
** (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
** INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE
** OF THE SOURCE CODE TO OPERATE WITH ANY OTHER PROGRAM), EVEN IF SUCH
** HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGES.
**
****************************************************************************/

#include "swl/swl_common.h"
#include "swla/swla_type.h"
#include "swl/swl_map.h"
#include "swl/types/swl_mapType.h"

#define ME "swlMapT"

static bool s_toVariant_cb(swl_type_t* type _UNUSED, amxc_var_t* tgt, const swl_typeData_t* srcData) {
    ASSERTS_NOT_NULL(tgt, false, ME, "NULL");
    swl_map_t* map = (swl_map_t*) srcData;

    if(amxc_var_type_of(tgt) != AMXC_VAR_ID_HTABLE) {
        amxc_var_init(tgt);
        amxc_var_set_type(tgt, AMXC_VAR_ID_HTABLE);
    }

    swl_mapIt_t mapIt;
    SAH_TRACEZ_ERROR(ME, "%u %p", swl_map_isInitialized(map), map);
    swl_map_for_each(mapIt, map) {
        char* keyChar = swl_type_toCStringExt(map->keyType, swl_map_itKey(&mapIt), &g_swl_print_dm);
        ASSERT_NOT_NULL(keyChar, false, ME, "KEY ERROR");
        amxc_var_t* tmpVar = amxc_var_add_new_key(tgt, keyChar);

        bool success = swl_type_toVariant(map->valueType, tmpVar, swl_map_itValue(&mapIt));

        if(!success) {
            SAH_TRACEZ_ERROR(ME, "VALUE ERROR -%s-", keyChar);
            free(keyChar);
            return false;
        }
        free(keyChar);
    }

    return true;
}

static bool s_fromVariant_cb(swl_type_t* type _UNUSED, swl_typeEl_t* tgtData, const amxc_var_t* var) {
    swl_map_t* map = (swl_map_t*) tgtData;
    swl_mapType_t* mapType = (swl_mapType_t*) type;
    if(!swl_map_isInitialized(map)) {
        swl_map_init(map, mapType->keyType, mapType->valueType);
    }

    const amxc_htable_t* htable = &var->data.vm;
    amxc_htable_for_each(it, htable) {
        amxc_var_t* item = amxc_var_from_htable_it(it);
        swl_mapEntry_t* entry = swl_map_alloc(map);
        ASSERT_NOT_NULL(entry, false, ME, "ALLOC FAIL");
        bool ret = swl_type_fromChar(map->keyType, swl_map_getEntryKeyRef(map, entry), it->key);
        ret &= swl_type_fromVariant(map->valueType, swl_map_getEntryValueRef(map, entry), item);
        if(!ret) {
            swl_map_deleteEntry(map, entry);
            return false;
        }
    }
    return true;
}

SWL_CONSTRUCTOR static void s_mapType_var_init(void) {
    swl_map_fun.toVariant = (swl_type_toVariant_cb) s_toVariant_cb;
    swl_map_fun.fromVariant = (swl_type_fromVariant_cb) s_fromVariant_cb;
}
