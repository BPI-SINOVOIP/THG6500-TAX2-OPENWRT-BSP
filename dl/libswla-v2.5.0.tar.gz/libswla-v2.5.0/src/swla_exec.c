/****************************************************************************
**
** Copyright (C) 2023 SoftAtHome. All rights reserved.
**
** SoftAtHome reserves all rights not expressly granted herein.
**
** - DISCLAIMER OF WARRANTY -
**
** THIS FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
** EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
** WARRANTIES OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
** PURPOSE.
**
** THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE SOURCE
** CODE IS WITH YOU. SHOULD THE SOURCE CODE PROVE DEFECTIVE, YOU
** ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
**
** - LIMITATION OF LIABILITY -
**
** IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
** WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES
** AND/OR DISTRIBUTES THE SOURCE CODE, BE LIABLE TO YOU FOR DAMAGES,
** INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
** ARISING OUT OF THE USE OR INABILITY TO USE THE SOURCE CODE
** (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
** INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE
** OF THE SOURCE CODE TO OPERATE WITH ANY OTHER PROGRAM), EVEN IF SUCH
** HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGES.
**
****************************************************************************/

/**
 * Helper functions to streamline executing other programs or scripts.
 */

#define _GNU_SOURCE
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "swla/swla_commonLib.h"
#include "swla/swla_exec.h"
#include "swla/swla_lib.h"

#define ME "swlExec"

typedef struct {
    const char* file;
    uint32_t line;
    amxc_string_t argBuffer;
    amxp_subproc_t* subProc;
} swl_exec_debugInfo_t;

typedef struct {
    swl_exec_debugInfo_t dbgInfo;
    swl_exec_result_t info;
} swl_exec_fdinfo_t;

typedef struct {
    swl_exec_debugInfo_t dbgInfo;
    swl_exec_doneHandler_f fDoneCb;
    void* userData;
} swl_exec_cbInfo_t;


/**
 * Redirect the given output stream (stdOut or stdErr) to a tempfile to
 * allow more data to be written.
 */
static swl_rc_ne s_redirOutstreamToTmpFile(amxp_subproc_t* subProc, int stdRedirRequested) {
    ASSERT_NOT_NULL(subProc, SWL_RC_INVALID_PARAM, ME, "NULL");
    /*
     * use temporary files instead of pipes to redirect std streams
     * as pipes transmits at most pipe-max-size (1MB), and by default 16 mempages( 16x4KB=64KB)
     * which may be not enough to retrieve all child's output
     */
    int stdFd = -1;
    FILE* fTemp = tmpfile();
    ASSERT_NOT_NULL(fTemp, SWL_RC_ERROR, ME, "fail to create temp redir stream (%d:%s)", errno, strerror(errno));
    // duplicate stream fd, for the parent to keep file open (kernel level) after closing the stream
    stdFd = dup(fileno(fTemp));
    // close useless stream: to free allocated stream mem;
    //tmp file will remain opened as fd are already duplicated
    fclose(fTemp);
    ASSERT_NOT_EQUALS(stdFd, -1, SWL_RC_ERROR, ME, "fail to create redir (%d:%s)", errno, strerror(errno));

    subProc->fd[stdRedirRequested][0] = stdFd;
    /*
     * temporary file are not mapped to filesystem and will be naturally removed when
     * all file descriptors (references) are closed (parent and child)
     */
    // create another fd dup for the child usage
    subProc->fd[stdRedirRequested][1] = dup(stdFd);
    return SWL_RC_OK;
}

/**
 * Get the file handler of the temp file a given output stream (stdOut or stdErr)
 * This requires s_redirOutstreamToTmpFile to be called before process start for the given
 * file handler.
 */
static void s_getOutStreamFileHandler(amxp_subproc_t* subProc, int stdRedirRequested, int* pFd) {
    ASSERTS_NOT_NULL(pFd, , ME, "NULL");
    ASSERT_NOT_NULL(subProc, , ME, "NULL");
    int* pBufFd = &subProc->fd[stdRedirRequested][0];
    *pFd = *pBufFd;
    ASSERTS_NOT_EQUALS(*pBufFd, -1, , ME, "no redir fd");
    //rewind buffer fd to let caller read from the beginning
    ASSERT_NOT_EQUALS(lseek(*pBufFd, 0L, SEEK_SET), (off_t) -1, , ME, "fail to rewind %d:%s", errno, strerror(errno));
    //reset fd to avoid closing tmp buf fd (and then removing tmp file) when cleaning redirection ctx.
    //let the caller read the fd, then close it (and trigger tmp file deletion)
    *pBufFd = -1;
}

static void s_fillExitInfo(swl_exec_procExitInfo_t* pExitInfo, const amxc_var_t* const pEventData, swl_exec_debugInfo_t* pDbgInfo) {
    swl_exec_procExitInfo_t exitInfo;
    memset(&exitInfo, 0, sizeof(exitInfo));
    const char* cmdLine = ((pDbgInfo != NULL) ? amxc_string_get(&pDbgInfo->argBuffer, 0) : "");
    amxp_subproc_t* subProc = ((pDbgInfo != NULL) ? pDbgInfo->subProc : NULL);
    pid_t childPid = 0;

    if(pEventData) {
        childPid = GET_INT32(pEventData, "PID");
        exitInfo.isExited = (GET_ARG(pEventData, "ExitCode") != NULL);
        if(exitInfo.isExited) {
            exitInfo.exitStatus = GET_INT32(pEventData, "ExitCode");
        }
        exitInfo.isSignaled = (GET_ARG(pEventData, "Signalled") != NULL);
        if(exitInfo.isSignaled) {
            exitInfo.termSignal = GET_INT32(pEventData, "Signal");
        }
    }
    if((subProc != NULL) &&
       ((pEventData == NULL) || (!exitInfo.isExited && !exitInfo.isSignaled))) {
        childPid = amxp_subproc_get_pid(subProc);
        exitInfo.isExited = (amxp_subproc_ifexited(subProc) != 0);
        if(exitInfo.isExited) {
            exitInfo.exitStatus = amxp_subproc_get_exitstatus(subProc);
        }
        exitInfo.isSignaled = (amxp_subproc_ifsignaled(subProc) != 0);
        if(exitInfo.isSignaled) {
            exitInfo.termSignal = amxp_subproc_get_termsig(subProc);
        }
    }
    if(exitInfo.isSignaled) {
        SAH_TRACEZ_INFO(ME, "exec \"%s\" %p pid(%d) signaled (sig=%s)",
                        cmdLine, subProc, childPid, strsignal(exitInfo.termSignal));
    } else if(exitInfo.isExited) {
        SAH_TRACEZ_INFO(ME, "exec \"%s\" %p terminated (ret=%d)",
                        cmdLine, subProc, exitInfo.exitStatus);
    }
    if(pExitInfo != NULL) {
        memcpy(pExitInfo, &exitInfo, sizeof(*pExitInfo));
    }
}
/**
 * Callback handler on process completion for background execution
 */
static void s_procExitHandlerBgCb(const char* const event_name,
                                  const amxc_var_t* const pEventData,
                                  void* const priv) {

    SAH_TRACEZ_INFO(ME, "AMX Signal = %s", event_name);
    swl_exec_cbInfo_t* pExecInfo = (swl_exec_cbInfo_t*) priv;
    swl_exec_debugInfo_t* pDbgInfo = ((pExecInfo != NULL) ? &pExecInfo->dbgInfo : NULL);
    swl_exec_procExitInfo_t exitInfo;
    s_fillExitInfo(&exitInfo, pEventData, pDbgInfo);

    ASSERTW_NOT_NULL(pExecInfo, , ME, "NULL");
    if(pExecInfo->fDoneCb != NULL) {
        pExecInfo->fDoneCb(pDbgInfo->subProc, &exitInfo, pExecInfo->userData);
    }

    amxc_string_clean(&pDbgInfo->argBuffer);
    amxp_subproc_delete(&pDbgInfo->subProc);
    free(pExecInfo);
}

/**
 * Common execution functionality.
 */
static amxp_subproc_t* s_exec_common(swl_exec_debugInfo_t* dbgInfo, const char* prg, char* str,
                                     int* pFdOut, int* pFdErr, amxp_slot_fn_t handler, void* userData) {
    ASSERT_STR(prg, NULL, ME, "Empty");
    amxp_subproc_t* subProc = NULL;

    char prgCopy[swl_str_len(prg) + 1];
    swl_str_copy(prgCopy, sizeof(prgCopy), prg);
    if(basename(prgCopy) != prgCopy) {
        // full path given
        ASSERT_EQUALS(access(prg, F_OK | X_OK), 0, NULL, ME, "prg (%s) can not be executed", prg);
    }

    if(swl_str_isEmpty(str)) {
        amxc_string_set(&dbgInfo->argBuffer, prg);
    } else {
        ASSERT_NULL(strchr(str, '>'), NULL, ME, "Don't run task with redirection -\"%s %s\" aborted", prg, str);
        ASSERT_NULL(strchr(str, '|'), NULL, ME, "Don't run task with pipes -\"%s %s\" aborted", prg, str);
        ASSERT_NULL(strchr(str, '&'), NULL, ME, "Don't run task in background -\"%s %s\" aborted", prg, str);
        amxc_string_setf(&dbgInfo->argBuffer, "%s %s", prg, str);
    }
    const char* cmdLine = amxc_string_get(&dbgInfo->argBuffer, 0);

    int ret = 0;
    ret = amxp_subproc_new(&subProc);
    if(ret != 0) {
        SAH_TRACEZ_ERROR(ME, "fail to create process");
        goto error;
    }
    if((pFdOut) && (s_redirOutstreamToTmpFile(subProc, STDOUT_FILENO) != SWL_RC_OK)) {
        SAH_TRACEZ_ERROR(ME, "fail to create stdout redirection");
        goto error;
    }
    if((pFdErr) && (s_redirOutstreamToTmpFile(subProc, STDERR_FILENO) != SWL_RC_OK)) {
        SAH_TRACEZ_ERROR(ME, "fail to create stderr redirection");
        goto error;
    }

    amxc_array_t aArgs;
    amxc_array_init(&aArgs, 10);
    amxc_llist_t lArgs;
    amxc_llist_init(&lArgs);
    amxc_string_split_to_llist(&dbgInfo->argBuffer, &lArgs, ' ');
    amxc_llist_for_each(it, &lArgs) {
        amxc_string_t* arg = amxc_container_of(it, amxc_string_t, it);
        if(!amxc_string_is_empty(arg)) {
            amxc_array_append_data(&aArgs, (void*) amxc_string_get(arg, 0));
        }
    }

    amxp_signal_mngr_t* sigMngr = amxp_subproc_get_sigmngr(subProc);
    if(handler != NULL) {
        amxp_slot_connect(sigMngr, "stop", NULL, handler, userData);
    }

    ret = amxp_subproc_astart(subProc, &aArgs);
    amxc_array_clean(&aArgs, NULL);
    amxc_llist_clean(&lArgs, amxc_string_list_it_free);
    if(ret != 0) {
        SAH_TRACEZ_ERROR(ME, "could not start %s", cmdLine);
        goto error;
    }
    dbgInfo->subProc = subProc;
    SAH_TRACEZ_INFO(ME, "exec -%s- %p @ %s:%u", prg, subProc, dbgInfo->file, dbgInfo->line);
    SAH_TRACEZ_INFO(ME, " * cmd: %s", cmdLine);

    return subProc;
error:
    amxc_string_clean(&dbgInfo->argBuffer);
    amxp_subproc_delete(&subProc);
    return NULL;
}

/**
 * Common functionality for file descriptor execution
 */
static swl_rc_ne s_common_fd(const char* file, uint32_t line,
                             int* pFdOut, int* pFdErr, swl_exec_result_t* pResult,
                             const char* prg, char* str) {

    swl_rc_ne ret = SWL_RC_ERROR;
    swl_exec_fdinfo_t execInfo;
    memset(&execInfo, 0, sizeof(swl_exec_fdinfo_t));
    execInfo.dbgInfo.file = file;
    execInfo.dbgInfo.line = line;
    amxc_string_init(&execInfo.dbgInfo.argBuffer, 0);

    amxp_subproc_t* subProc = s_exec_common(&execInfo.dbgInfo, prg, str,
                                            pFdOut, pFdErr, NULL, NULL);
    ASSERT_NOT_NULL(subProc, SWL_RC_ERROR, ME, "fail to create process");

    int waitRet = amxp_subproc_wait(subProc, -1);
    if((waitRet == 0)) {
        swl_exec_procExitInfo_t* pProcExitInfo = &execInfo.info.exitInfo;
        s_fillExitInfo(pProcExitInfo, NULL, &execInfo.dbgInfo);
        //check here if child has been really executed
        if(((pProcExitInfo->isExited) && (pProcExitInfo->exitStatus == EXIT_FAILURE)) ||
           (pProcExitInfo->isSignaled)) {
            SAH_TRACEZ_ERROR(ME, "(%s)(pid:%d) execution stops abnormally", prg, amxp_subproc_get_pid(subProc));
        }
        if(pResult) {
            memcpy(&pResult->exitInfo, pProcExitInfo, sizeof(pResult->exitInfo));
        }

        s_getOutStreamFileHandler(subProc, STDOUT_FILENO, pFdOut);
        s_getOutStreamFileHandler(subProc, STDERR_FILENO, pFdErr);
        ret = SWL_RC_OK;
    }

    amxc_string_clean(&execInfo.dbgInfo.argBuffer);
    amxp_subproc_delete(&subProc);
    return ret;
}

/**
 * @brief execute a program in background, and call doneHandler when done
 *
 * @param file: the file from where call is made, for debugging purposes
 * @param line: the line from where call is made, for debugging purposes
 * @param doneHandler: the callback handler. Shall be called when task finishes. Can be NULL
 * @param userData: the userdata to be passed to the callback handler
 * @param prg: the program to be called to execute
 * @param format: the arguements to be added, as list of arguements
 * @return new subProc context if program correctly started, NULL otherwise
 */
amxp_subproc_t* swl_exec_common_bg(const char* file, uint32_t line,
                                   swl_exec_doneHandler_f doneHandler, void* userData,
                                   const char* prg, char* format, ...) {

    va_list args;
    amxp_subproc_t* subProc = NULL;
    char* str = NULL;
    // Create the command
    va_start(args, format);
    int retVal = vasprintf(&str, format, args);
    va_end(args);
    ASSERT_NOT_EQUALS(retVal, -1, NULL, ME, "fail to format command");

    swl_exec_cbInfo_t* cbInfo = calloc(1, sizeof(swl_exec_cbInfo_t));
    if(cbInfo == NULL) {
        SAH_TRACEZ_ERROR(ME, "Info calloc failed");
        goto err;
    }
    cbInfo->fDoneCb = doneHandler;
    cbInfo->userData = userData;
    cbInfo->dbgInfo.file = file;
    cbInfo->dbgInfo.line = line;
    amxc_string_init(&cbInfo->dbgInfo.argBuffer, 0);

    subProc = s_exec_common(&cbInfo->dbgInfo, prg, str, NULL, NULL, s_procExitHandlerBgCb, cbInfo);
err:
    free(str);
    return subProc;
}

/**
 * @brief execute a program and put output in provided file descriptors
 *
 * @param file: the file from where call is made, for debugging purposes
 * @param line: the line from where call is made, for debugging purposes
 * @param pFdOut: the output file descriptor
 * @param pFdErr: the error file descriptor
 * @param prg: the program to be called to execute
 * @param format: the arguements to be added, as list of arguements
 * @return SWL_RC_OK if program correctly started, SWL_RC_ERROR otherwise. Note that
 *   it is possible the program failed during run, but this shall not be reflected in return value.
 */
swl_rc_ne swl_exec_common_fd(const char* file, uint32_t line,
                             int* pFdOut, int* pFdErr,
                             const char* prg, char* format, ...) {
    va_list args;
    char* str = NULL;
    swl_rc_ne ret = SWL_RC_ERROR;
    /* Create the command */
    va_start(args, format);
    int retVal = vasprintf(&str, format, args);
    va_end(args);
    ASSERT_NOT_EQUALS(retVal, -1, SWL_RC_ERROR, ME, "fail to format command");
    ret = s_common_fd(file, line, pFdOut, pFdErr, NULL, prg, str);
    free(str);
    return ret;
}

/**
 * dump stream content into buffer
 */
static void s_dumpFd(int fd, char* dstBuf, uint32_t dstBufSize) {
    ASSERTS_NOT_EQUALS(fd, -1, , TRACEZ_IO_OUT, "INVALID");
    char localBuf[128] = {0};
    //just read out the data if not enabled, so we are where we need to be next time
    int readRet = 0;
    do {
        readRet = read(fd, localBuf, sizeof(localBuf) - 1);
        if(readRet < 0) {
            //flag O_NONBLOCK was set on fd_out
            if((errno == EAGAIN) || (errno == EWOULDBLOCK)) {
                continue;
            }
            SAH_TRACEZ_ERROR(ME, "fail to read fd(%d): %d:%s", fd, errno, strerror(errno));
            break;
        }
        localBuf[readRet] = 0;
        swl_str_cat(dstBuf, dstBufSize, localBuf);
    } while(readRet > 0);
}

/**
 * @brief execute a program and write stdOut into given buffer
 *
 * @param file: the file from where call is made, for debugging purposes
 * @param line: the line from where call is made, for debugging purposes
 * @param buf: the buffer to write output to
 * @param bufSize: bufSize
 * @param prg: the program to be called to execute
 * @param format: the arguements to be added, as list of arguements
 * @return SWL_RC_OK if program correctly started, SWL_RC_ERROR otherwise. Note that
 *   it is possible the program failed during run, but this shall not be reflected in return value.
 */
swl_rc_ne swl_exec_common_buf(const char* file, uint32_t line,
                              char* buf, size_t bufSize,
                              const char* prg, char* format, ...) {
    va_list args;
    char* str = NULL;
    int fd = -1;
    swl_rc_ne ret = SWL_RC_ERROR;
    /* Create the command */
    va_start(args, format);
    ret = vasprintf(&str, format, args);
    va_end(args);
    ASSERT_NOT_EQUALS(ret, -1, SWL_RC_ERROR, ME, "fail to format command");
    ret = s_common_fd(file, line, &fd, NULL, NULL, prg, str);
    free(str);

    if(ret < 0) {
        return ret;
    }
    s_dumpFd(fd, buf, bufSize);
    close(fd);
    return ret;
}

/**
 * @brief execute a program and write stdOut stdErr (buffers), exitCode and exitSignal into given structure.
 *
 * @param retResult: pointer to struct to be filled with all execution results
 * @param prg: the program to be called to execute
 * @param format: the arguements to be added, as list of arguements
 * @return SWL_RC_OK if program correctly started, SWL_RC_ERROR otherwise. Note that
 *   it is possible the program failed during run, but this shall not be reflected in return value.
 *   Output and error buffers are filled only if not null and sized.
 */
swl_rc_ne swl_exec_common_buf_ext(const char* file, uint32_t line,
                                  swl_exec_result_t* pResult,
                                  const char* prg, char* format, ...) {
    va_list args;
    char* str = NULL;
    int fdOut = -1;
    int* pFdOut = NULL;
    int fdErr = -1;
    int* pFdErr = NULL;

    if(pResult) {
        if(pResult->outBuf && pResult->outBufSize) {
            pResult->outBuf[0] = 0;
            pFdOut = &fdOut;
        }
        if(pResult->errBuf && pResult->errBufSize) {
            pResult->errBuf[0] = 0;
            pFdErr = &fdErr;
        }
    }

    swl_rc_ne ret = SWL_RC_ERROR;
    /* Create the command */
    va_start(args, format);
    ret = vasprintf(&str, format, args);
    va_end(args);
    ASSERT_NOT_EQUALS(ret, -1, SWL_RC_ERROR, ME, "fail to format command");
    ret = s_common_fd(file, line, pFdOut, pFdErr, pResult, prg, str);
    free(str);

    if(ret < 0) {
        return ret;
    }
    if(pFdOut && (*pFdOut != -1)) {
        s_dumpFd(*pFdOut, pResult->outBuf, pResult->outBufSize);
        close(*pFdOut);
    }
    if(pFdErr && (*pFdErr != -1)) {
        s_dumpFd(*pFdErr, pResult->errBuf, pResult->errBufSize);
        close(*pFdErr);
    }
    return ret;
}
