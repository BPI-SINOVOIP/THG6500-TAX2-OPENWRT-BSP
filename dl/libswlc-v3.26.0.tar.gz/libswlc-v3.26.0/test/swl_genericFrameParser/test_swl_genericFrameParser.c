/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <unistd.h>
#include <libgen.h>
#include <cmocka.h>
#include <swl/swl_common.h>
#include "swl/swl_genericFrameParser.h"

// Create buffer
#define BUFF_SIZE 5120

static int setup_suite(void** state _UNUSED) {
    return 0;
}

static int teardown_suite(void** state _UNUSED) {
    return 0;
}

static size_t s_loadFrame(uint8_t* buf, size_t bufSize, const char* binFileName) {
    memset(buf, 0, bufSize);
    FILE* fp = fopen(binFileName, "rb");
    assert_non_null(fp);

    size_t flen = fread(buf, 1, bufSize, fp);
    fclose(fp);
    assert_true(flen <= bufSize);
    return flen;
}

static void s_checkingResults(swl_wirelessDevice_infoElements_t* ieExpectedData, swl_wirelessDevice_infoElements_t* ieData) {

    printf("vendorOUI: %d ==> %d\n", ieData->vendorOUI.count, ieExpectedData->vendorOUI.count);
    for(uint8_t i = 0; i < ieData->vendorOUI.count; i++) {
        printf("OUI: %x ==> %x\n", SWL_OUI_GET(ieData->vendorOUI.oui[i].ouiBytes), SWL_OUI_GET(ieExpectedData->vendorOUI.oui[i].ouiBytes));
    }
    printf("capabilities:  %d ==> %d\n", ieData->capabilities, ieExpectedData->capabilities);
    printf("htCapabilities: %d ==> %d\n", ieData->htCapabilities, ieExpectedData->htCapabilities);
    printf("vhtCapabilities: %d ==> %d\n", ieData->vhtCapabilities, ieExpectedData->vhtCapabilities);
    printf("heCapabilities: %d ==> %d\n", ieData->heCapabilities, ieExpectedData->heCapabilities);
    printf("freqCapabilities: %d ==> %d\n", ieData->freqCapabilities, ieExpectedData->freqCapabilities);
    printf("uniiBandsCapabilities: 0x%x ==> 0x%x\n", ieData->uniiBandsCapabilities, ieExpectedData->uniiBandsCapabilities);
    printf("operChanSpec:  b:%d/c:%d/w:%d ==> b:%d/c:%d/w:%d\n",
           ieData->operChanInfo.band, ieData->operChanInfo.channel, ieData->operChanInfo.bandwidth,
           ieExpectedData->operChanInfo.band, ieExpectedData->operChanInfo.channel, ieExpectedData->operChanInfo.bandwidth);
    printf("ssidLen: %d ==> %d, (SIZE = %ld)\n", ieData->ssidLen, ieExpectedData->ssidLen, strlen(ieExpectedData->ssid));
    printf("ssid: %s %s\n", ieData->ssid, ieExpectedData->ssid);
    printf("secModeEnabled: %d ==> %d\n", ieData->secModeEnabled, ieExpectedData->secModeEnabled);
    printf("operatingStandards: %d ==> %d\n", ieData->operatingStandards, ieExpectedData->operatingStandards);
    printf("WPS_ConfigMethodsEnabled: %d ==> %d\n", ieData->WPS_ConfigMethodsEnabled, ieExpectedData->WPS_ConfigMethodsEnabled);

    // testing
    assert_int_equal((int) ieData->vendorOUI.count, (int) ieExpectedData->vendorOUI.count);
    for(uint8_t i = 0; i < ieData->vendorOUI.count; i++) {
        assert_int_equal(SWL_OUI_GET(ieData->vendorOUI.oui[i].ouiBytes), SWL_OUI_GET(ieExpectedData->vendorOUI.oui[i].ouiBytes));
    }
    assert_int_equal((int) ieData->capabilities, (int) ieExpectedData->capabilities);
    assert_int_equal((int) ieData->htCapabilities, (int) ieExpectedData->htCapabilities);
    assert_int_equal((int) ieData->vhtCapabilities, (int) ieExpectedData->vhtCapabilities);
    assert_int_equal((int) ieData->heCapabilities, (int) ieExpectedData->heCapabilities);
    assert_int_equal((int) ieData->freqCapabilities, (int) ieExpectedData->freqCapabilities);
    assert_int_equal((int) ieData->uniiBandsCapabilities, (int) ieExpectedData->uniiBandsCapabilities);
    assert_int_equal((int) ieData->operChanInfo.band, (int) ieExpectedData->operChanInfo.band);
    assert_int_equal((int) ieData->operChanInfo.bandwidth, (int) ieExpectedData->operChanInfo.bandwidth);
    assert_int_equal((int) ieData->operChanInfo.channel, (int) ieExpectedData->operChanInfo.channel);
    assert_int_equal((int) ieData->ssidLen, (int) ieExpectedData->ssidLen);
    assert_string_equal(ieData->ssid, ieExpectedData->ssid);
    assert_int_equal((int) ieData->secModeEnabled, (int) ieExpectedData->secModeEnabled);
    assert_int_equal((int) ieData->operatingStandards, (int) ieExpectedData->operatingStandards);
    assert_int_equal((int) ieData->WPS_ConfigMethodsEnabled, (int) ieExpectedData->WPS_ConfigMethodsEnabled);
}

struct {
    const char* iesFileName;
    const char* frameFileName;
    swl_80211_mgmtFrame_t expectedHeader;
    swl_wirelessDevice_infoElements_t expectedIEs;
} rawIEsInfo[] = {
    {
        .iesFileName = "probRespIE2GHz",
        .frameFileName = "probRespFrame2GHz.bin",
        .expectedHeader = {
            .fc = {.subType = (SWL_80211_MGT_FRAME_TYPE_PROBE_RESPONSE >> 4), },
            .transmitter = {{0xd8, 0xfb, 0x5e, 0x5d, 0x1e, 0xe4}},
            .destination = {{0x48, 0x8d, 0x36, 0xd5, 0xdf, 0x94}},
            .bssid = {{0xd8, 0xfb, 0x5e, 0x5d, 0x1e, 0xe4}},
        },
        .expectedIEs = {
            .vendorOUI.count = 3,
            .vendorOUI.oui = { { {0x00, 0x50, 0xf2}},     // OUI Microsoft Corp. (there is two of this one in the frame, but the 2nd will not be taken into acount because of: swl_typeOui_arrayContains())
                { {0x00, 0x90, 0x4c}},                    // OUI Epigram, Inc.
                { {0x00, 0x10, 0x18}} },                  // OUI Broadcom.

            .capabilities = M_SWL_STACAP_RRM,
            .htCapabilities = (M_SWL_STACAP_HT_40MHZ | M_SWL_STACAP_HT_SGI20 | M_SWL_STACAP_HT_SGI40),       // extracted from 0x19e3
            .vhtCapabilities = (M_SWL_STACAP_VHT_SGI80 | M_SWL_STACAP_VHT_SU_BFR | M_SWL_STACAP_VHT_SU_BFE), // extracted from 0x0f8379b0
            .heCapabilities = 0,                                                                             // not supported in this frame
            .rrmCapabilities = (M_SWL_STACAP_RRM_LINK_ME | M_SWL_STACAP_RRM_NEIGHBOR_RE | M_SWL_STACAP_RRM_BEACON_ACTIVE_ME |
                                M_SWL_STACAP_RRM_BEACON_PASSIVE_ME | M_SWL_STACAP_RRM_FRAME_ME | M_SWL_STACAP_RRM_CHAN_LOAD_ME |
                                M_SWL_STACAP_RRM_NOISE_HISTOGRAM_ME | M_SWL_STACAP_RRM_STATS_ME | M_SWL_STACAP_RRM_TRANS_SC_ME),
            .rrmOnChannelMaxDuration = 0,
            .rrmOffChannelMaxDuration = 0,
            .freqCapabilities = M_SWL_FREQ_BAND_EXT_5GHZ,                                                    // deduced from VHT Operation info in this frame
            .operChanInfo = {
                .channel = 104,
                .bandwidth = SWL_BW_80MHZ,
                .band = SWL_FREQ_BAND_EXT_5GHZ,
            },

            .ssidLen = 23,
            .ssid = "Internet-Box-51595_5GHz",
            .secModeEnabled = SWL_SECURITY_APMODE_WPA2_P,
            .operatingStandards = (M_SWL_RADSTD_A | M_SWL_RADSTD_N | M_SWL_RADSTD_AC),
            .WPS_ConfigMethodsEnabled = (M_SWL_WPS_CFG_MTHD_ETH | M_SWL_WPS_CFG_MTHD_LABEL | M_SWL_WPS_CFG_MTHD_PBC | M_SWL_WPS_CFG_MTHD_PBC_V | M_SWL_WPS_CFG_MTHD_PBC_P), // extracted from 0x0686
        }
    },
    {
        .iesFileName = "probRespIE5GHz",
        .frameFileName = "probRespFrame5GHz.bin",
        .expectedHeader = {
            .fc = {.subType = (SWL_80211_MGT_FRAME_TYPE_PROBE_RESPONSE >> 4), },
            .transmitter = {{0x98, 0x42, 0x65, 0x2d, 0x23, 0x40}},
            .destination = {{0x02, 0xaf, 0xc6, 0x91, 0x51, 0xc4}},
            .bssid = {{0x98, 0x42, 0x65, 0x2d, 0x23, 0x40}},
        },
        .expectedIEs = {
            .vendorOUI.count = 4,
            .vendorOUI.oui = { { {0x00, 0x26, 0x86}},  // OUI Quantina.
                { {0x00, 0x50, 0xf2}},                 // OUI Microsoft Corp. (there is two of this one in the frame, but the 2nd will not be taken into acount because of: swl_typeOui_arrayContains())
                { {0x00, 0x90, 0x4c}},                 // OUI Epigram, Inc.
                { {0x00, 0x10, 0x18}} },               // OUI Broadcom.

            .capabilities = M_SWL_STACAP_RRM,
            .htCapabilities = (M_SWL_STACAP_HT_40MHZ | M_SWL_STACAP_HT_SGI20 | M_SWL_STACAP_HT_SGI40),                                 // extracted from 0x01ef
            .vhtCapabilities = (M_SWL_STACAP_VHT_SGI80 | M_SWL_STACAP_VHT_SU_BFR | M_SWL_STACAP_VHT_SU_BFE | M_SWL_STACAP_VHT_MU_BFR), // extracted from 0x0f8b79b6
            .heCapabilities = (M_SWL_STACAP_HE_SU_BFR | M_SWL_STACAP_HE_SU_AND_MU_BFE | M_SWL_STACAP_HE_MU_BFR),                       // extracted from 0x6fc0
            .rrmCapabilities = (M_SWL_STACAP_RRM_LINK_ME | M_SWL_STACAP_RRM_NEIGHBOR_RE | M_SWL_STACAP_RRM_BEACON_ACTIVE_ME |
                                M_SWL_STACAP_RRM_BEACON_PASSIVE_ME | M_SWL_STACAP_RRM_FRAME_ME | M_SWL_STACAP_RRM_CHAN_LOAD_ME |
                                M_SWL_STACAP_RRM_NOISE_HISTOGRAM_ME | M_SWL_STACAP_RRM_STATS_ME | M_SWL_STACAP_RRM_TRANS_SC_ME),
            .rrmOnChannelMaxDuration = 0,
            .rrmOffChannelMaxDuration = 0,
            .freqCapabilities = M_SWL_FREQ_BAND_EXT_5GHZ,
            .operChanInfo = {
                .channel = 100,
                .bandwidth = SWL_BW_80MHZ,
                .band = SWL_FREQ_BAND_EXT_5GHZ,
            },
            .uniiBandsCapabilities = M_SWL_BAND_UNII_ALL_5G,

            .ssidLen = 12,
            .ssid = "Livebox-2340",
            .secModeEnabled = SWL_SECURITY_APMODE_WPA2_P,
            .operatingStandards = (M_SWL_RADSTD_A | M_SWL_RADSTD_N | M_SWL_RADSTD_AC | M_SWL_RADSTD_AX),
            .WPS_ConfigMethodsEnabled = 0,  // Registrar Config Methods not supported in this frame
        }
    },
};

static void test_parseMultiIEsInRawBuffer(void** state _UNUSED) {
    swl_wirelessDevice_infoElements_t results;
    uint8_t binData[BUFF_SIZE] = {0};
    for(uint32_t i = 0; i < SWL_ARRAY_SIZE(rawIEsInfo); i++) {
        memset(&results, 0, sizeof(swl_wirelessDevice_infoElements_t));
        size_t binLen = s_loadFrame(binData, sizeof(binData), rawIEsInfo[i].iesFileName);
        ssize_t parsedLen = swl_80211_parseInfoElementsBuffer(&results, NULL, binLen, binData);
        assert_int_equal(parsedLen, binLen);
        s_checkingResults(&results, &rawIEsInfo[i].expectedIEs);
    }
}

static void test_parseMultiIEsInMgmtFrame(void** state _UNUSED) {
    swl_wirelessDevice_infoElements_t results;
    uint8_t binData[BUFF_SIZE] = {0};
    for(uint32_t i = 0; i < SWL_ARRAY_SIZE(rawIEsInfo); i++) {
        memset(&results, 0, sizeof(swl_wirelessDevice_infoElements_t));
        size_t binLen = s_loadFrame(binData, sizeof(binData), rawIEsInfo[i].frameFileName);
        swl_80211_mgmtFrame_t* frame = swl_80211_getMgmtFrame(binData, binLen);
        assert_non_null(frame);
        size_t iesLen = 0;
        swl_bit8_t* iesData = swl_80211_getInfoElementsOfMgmtFrame(&iesLen, binData, binLen);
        assert_non_null(iesData);
        assert_int_equal(swl_80211_parseInfoElementsBuffer(&results, NULL, iesLen, iesData), iesLen);
        assert_int_equal(frame->fc.subType, rawIEsInfo[i].expectedHeader.fc.subType);
        assert_memory_equal(&frame->transmitter, &rawIEsInfo[i].expectedHeader.transmitter, SWL_MAC_BIN_LEN);
        assert_memory_equal(&frame->destination, &rawIEsInfo[i].expectedHeader.destination, SWL_MAC_BIN_LEN);
        assert_memory_equal(&frame->bssid, &rawIEsInfo[i].expectedHeader.bssid, SWL_MAC_BIN_LEN);
        s_checkingResults(&results, &rawIEsInfo[i].expectedIEs);
    }
}

#define IE_MAX_SIZE 255
static void test_parseOneIE(void** state _UNUSED) {
    struct {
        uint8_t ieData[IE_MAX_SIZE];
        swl_wirelessDevice_infoElements_t expectedIEs;
    } oneIEInfo[] = {
        //parse IE SSID
        {
            .ieData = {SWL_80211_EL_ID_SSID, strlen("testSSID"), 't', 'e', 's', 't', 'S', 'S', 'I', 'D'},
            .expectedIEs = {
                .ssidLen = strlen("testSSID"),
                .ssid = {"testSSID"},
            },
        },
        //parse IE VHT Operation Info
        {
            /* center sg0 106, center sg1 114 */
            .ieData = {SWL_80211_EL_ID_VHT_OP, 5, SWL_80211_VHT_OPER_CHAN_WIDTH_80_160_8080, 106, 114, 0x00, 0x00},
            .expectedIEs = {
                .operChanInfo.bandwidth = SWL_BW_160MHZ,
                .operatingStandards = M_SWL_RADSTD_AC,
            },
        },
        //parse IE HT Operation Info
        {
            /* primary chan 11, 0x8: no secd channel, bw only 20MHz.*/
            .ieData = {SWL_80211_EL_ID_HT_OP, 22, 11, 0x8, 0x00, 0x11, /* remaining zeros */ },
            .expectedIEs = {
                .operChanInfo = {.channel = 11, .bandwidth = SWL_BW_20MHZ, .band = SWL_FREQ_BAND_EXT_2_4GHZ, },
                .freqCapabilities = M_SWL_FREQ_BAND_EXT_2_4GHZ,
                .operatingStandards = M_SWL_RADSTD_G | M_SWL_RADSTD_N,
            },
        },
        //parse IE Supported operating classes
        {
            /* Current operating class 84, alternates: 81, 83, 84 */
            .ieData = {SWL_80211_EL_ID_SUP_OP_CLASS, 4, 84, 81, 83, 84, },
            .expectedIEs = {
                .operChanInfo = {.band = SWL_FREQ_BAND_EXT_2_4GHZ, .bandwidth = SWL_BW_40MHZ, },
                .freqCapabilities = M_SWL_FREQ_BAND_EXT_2_4GHZ,
                .operatingStandards = M_SWL_RADSTD_G, /* Legacy */
                .uniiBandsCapabilities = 0,
            },
        },
        //parse IE Supported operating classes
        {
            /* Current operating class 128, no alternates: 0 */
            .ieData = {SWL_80211_EL_ID_SUP_OP_CLASS, 2, 128, 0, },
            .expectedIEs = {
                .operChanInfo = {.band = SWL_FREQ_BAND_EXT_5GHZ, .bandwidth = SWL_BW_80MHZ, },
                .freqCapabilities = M_SWL_FREQ_BAND_EXT_5GHZ,
                .operatingStandards = M_SWL_RADSTD_A, /* Legacy */
                .uniiBandsCapabilities = M_SWL_BAND_UNII_ALL_5G,
            },
        },
    };
    swl_wirelessDevice_infoElements_t results;
    for(uint32_t i = 0; i < SWL_ARRAY_SIZE(oneIEInfo); i++) {
        memset(&results, 0, sizeof(swl_wirelessDevice_infoElements_t));
        swl_rc_ne rc = swl_80211_processInfoElementFrame(&results, NULL, oneIEInfo[i].ieData[0], oneIEInfo[i].ieData[1], &oneIEInfo[i].ieData[2]);
        assert_int_equal(rc, SWL_RC_OK);
        s_checkingResults(&results, &oneIEInfo[i].expectedIEs);
    }
}

int main(int argc _UNUSED, char* argv[] _UNUSED) {
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_parseMultiIEsInRawBuffer),
        cmocka_unit_test(test_parseMultiIEsInMgmtFrame),
        cmocka_unit_test(test_parseOneIE),
    };
    return cmocka_run_group_tests(tests, setup_suite, teardown_suite);
}
