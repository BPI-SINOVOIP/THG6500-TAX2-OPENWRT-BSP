/****************************************************************************
**
** Copyright (C) 2020 SoftAtHome. All rights reserved.
**
** SoftAtHome reserves all rights not expressly granted herein.
**
** - DISCLAIMER OF WARRANTY -
**
** THIS FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
** EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
** WARRANTIES OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
** PURPOSE.
**
** THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE SOURCE
** CODE IS WITH YOU. SHOULD THE SOURCE CODE PROVE DEFECTIVE, YOU
** ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
**
** - LIMITATION OF LIABILITY -
**
** IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
** WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES
** AND/OR DISTRIBUTES THE SOURCE CODE, BE LIABLE TO YOU FOR DAMAGES,
** INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
** ARISING OUT OF THE USE OR INABILITY TO USE THE SOURCE CODE
** (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
** INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE
** OF THE SOURCE CODE TO OPERATE WITH ANY OTHER PROGRAM), EVEN IF SUCH
** HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGES.
**
****************************************************************************/
#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <setjmp.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <cmocka.h>

#include <debug/sahtrace.h>
#include "swl/swl_common.h"
#include "swl/swl_common_type.h"
#include "swl/ttb/swl_ttb.h"
#include "swl/fileOps/swl_fileUtils.h"
#include "swl/types/swl_arrayBufType.h"
#include "swl/swl_common_tupleType.h"

#define NR_TYPES 6
#define NR_VALUES 4


#define MY_TEST_TABLE_VAR(X, Y) \
    X(Y, gtSwl_type_int8, test2) \
    X(Y, gtSwl_type_int64, index) \
    X(Y, gtSwl_type_charPtr, val)

SWL_TT(tMyTestTupleType, swl_myTestTT_t, MY_TEST_TABLE_VAR, )

SWL_ARRAY_BUF_TYPE(tMyTestArrayBufType, tMyTestTupleType, 4, false);

/**
 * Defining a tuple type using a table
 */
swl_myTestTT_t myTestValues[NR_VALUES] = {
    {1, 100, "test1"},
    {2, -200, "test2"},
    {-88, 289870, "foobar"},
    {88, -289869, "barfoo"},
};

const char* strData[NR_VALUES] = {
    "[1,100,test1]",
    "[2,-200,test2]",
    "[-88,289870,foobar]",
    "[88,-289869,barfoo]"
};


tMyTestArrayBufType_type testData[] = {
    {.data = {
            {1, 100, "test1"},
            {2, -200, "test2"},
            {-88, 289870, "foobar"},
            {88, -289869, "barfoo"},
        }, .size = 4 },
    {.data = {
            {2, 100, "test1"}, // 2 changed here
            {2, -200, "test2"},
            {-88, 289870, "foobar"},
            {88, -289869, "barfoo"},
        }, .size = 4},
    {.data = {
            {2, 100, "test1"},
            {2, -202, "test2"}, // -202 changed here
            {-88, 289870, "foobar"},
            {88, -289869, "barfoo"},
        }, .size = 4},
    {.data = {
            {2, 100, "test1"},
            {2, -200, "test2"},
            {-88, 289870, "foobars"}, // fobars changed here
            {88, -289869, "barfoo"},
        }, .size = 4},
    {.data = {
            {1, 100, "test1"},
            {2, -200, "test2"},
            {-88, 289870, "foobar"},
            {0, 0, NULL},
        }, .size = 3},
    {.data = {
            {0, 0, NULL},
            {0, 0, NULL},
            {0, 0, NULL},
            {0, 0, NULL},
        }, .size = 0},
};



static void test_swl_ttb_val(void** state _UNUSED) {
    for(size_t i = 0; i < SWL_ARRAY_SIZE(myTestValues); i++) {
        swl_myTestTT_t tmpVal;
        memset(&tmpVal, 0, sizeof(swl_myTestTT_t));
        swl_type_copyTo(&tMyTestTupleType.type, &tmpVal, &myTestValues[i]);

        for(size_t j = 0; j < SWL_ARRAY_SIZE(myTestValues); j++) {
            if(i == j) {
                swl_ttb_assertTypeEquals(&tMyTestTupleType.type, &myTestValues[j], &tmpVal);
                swl_ttb_assertBigTypeEquals(&tMyTestTupleType.type, &myTestValues[j], &tmpVal);

                swl_ttb_assertTypeValEquals(&tMyTestTupleType.type, myTestValues[j], tmpVal);
                swl_ttb_assertBigTypeValEquals(&tMyTestTupleType.type, myTestValues[j], tmpVal);

                swl_ttb_assertTypeBuf32StrMatches(&tMyTestTupleType.type, &myTestValues[j], strData[i]);
                swl_ttb_assertTypeValBuf32StrMatches(&tMyTestTupleType.type, myTestValues[j], strData[i]);
            } else {
                swl_ttb_assertTypeNotEquals(&tMyTestTupleType.type, &myTestValues[j], &tmpVal);
                swl_ttb_assertBigTypeNotEquals(&tMyTestTupleType.type, &myTestValues[j], &tmpVal);

                swl_ttb_assertTypeValNotEquals(&tMyTestTupleType.type, myTestValues[j], tmpVal);
                swl_ttb_assertBigTypeValNotEquals(&tMyTestTupleType.type, myTestValues[j], tmpVal);

                swl_ttb_assertTypeBuf32StrNotMatches(&tMyTestTupleType.type, &myTestValues[j], strData[i]);
                swl_ttb_assertTypeValBuf32StrNotMatches(&tMyTestTupleType.type, myTestValues[j], strData[i]);
            }
            swl_ttb_assertTypeNotEmpty(&tMyTestTupleType.type, &tmpVal);
            swl_ttb_assertTypeValNotEmpty(&tMyTestTupleType.type, tmpVal);
        }
        swl_type_cleanup(&tMyTestTupleType.type, &tmpVal);
    }

    swl_myTestTT_t tmpVal;
    memset(&tmpVal, 0, sizeof(swl_myTestTT_t));
    swl_ttb_assertTypeEmpty(&tMyTestTupleType.type, &tmpVal);
    swl_ttb_assertTypeValEmpty(&tMyTestTupleType.type, tmpVal);
}

static void test_swl_ttb_array(void** state _UNUSED) {
    for(size_t i = 0; i < SWL_ARRAY_SIZE(testData); i++) {
        tMyTestArrayBufType_type tmpVal;
        memset(&tmpVal, 0, sizeof(tMyTestArrayBufType_type));
        swl_type_copyTo(&tMyTestArrayBufType.type.type, &tmpVal, &testData[i]);

        printf("%zu %s\n", i, swl_type_toBuf128(&tMyTestArrayBufType.type.type, &tmpVal).buf);
        for(size_t j = 0; j < SWL_ARRAY_SIZE(myTestValues); j++) {
            if(i == j) {
                swl_ttb_assertTypeArrayEquals(&tMyTestTupleType.type, testData[j].data, testData[j].size, tmpVal.data, tmpVal.size);
            } else {
                swl_ttb_assertTypeArrayNotEquals(&tMyTestTupleType.type, testData[j].data, testData[j].size, tmpVal.data, tmpVal.size);
            }
        }

        swl_type_cleanup(&tMyTestArrayBufType.type.type, &tmpVal);
    }
}

static void test_swl_ttb_file(void** state _UNUSED) {
    swl_ttb_assertFileEquals("testfile_0_0.txt", "testfile_0_1.txt");

    for(size_t i = 0; i < SWL_ARRAY_SIZE(myTestValues); i++) {
        char buffer[128];
        snprintf(buffer, sizeof(buffer), "typeTestPrint/file_%zu.txt", i);
        swl_ttb_assertTypeToFileEquals(&tMyTestTupleType.type, buffer, &myTestValues[i], NULL, false);
    }
}


static int setup_suite(void** state _UNUSED) {
    printf("TYPE INIT %p\n", &tMyTestTupleType);
    for(size_t i = 0; i < SWL_ARRAY_SIZE(testData); i++) {
        testData[i].maxSize = 4;
        testData[i].type = (swl_type_t*) &tMyTestTupleType;
    }
    return 0;
}

static int teardown_suite(void** state _UNUSED) {
    return 0;
}

int main(int argc _UNUSED, char* argv[] _UNUSED) {
    sahTraceOpen(__FILE__, TRACE_TYPE_STDERR);
    if(!sahTraceIsOpen()) {
        fprintf(stderr, "FAILED to open SAH TRACE\n");
    }
    sahTraceSetLevel(TRACE_LEVEL_WARNING);
    sahTraceSetTimeFormat(TRACE_TIME_APP_SECONDS);
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_swl_ttb_val),
        cmocka_unit_test(test_swl_ttb_array),
        cmocka_unit_test(test_swl_ttb_file),
    };


    int rc = cmocka_run_group_tests(tests, setup_suite, teardown_suite);


    sahTraceClose();
    return rc;
}
