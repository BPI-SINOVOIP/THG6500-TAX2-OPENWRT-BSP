/****************************************************************************
**
** Copyright (C) 2020 SoftAtHome. All rights reserved.
**
** SoftAtHome reserves all rights not expressly granted herein.
**
** - DISCLAIMER OF WARRANTY -
**
** THIS FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
** EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
** WARRANTIES OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
** PURPOSE.
**
** THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE SOURCE
** CODE IS WITH YOU. SHOULD THE SOURCE CODE PROVE DEFECTIVE, YOU
** ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
**
** - LIMITATION OF LIABILITY -
**
** IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
** WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES
** AND/OR DISTRIBUTES THE SOURCE CODE, BE LIABLE TO YOU FOR DAMAGES,
** INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
** ARISING OUT OF THE USE OR INABILITY TO USE THE SOURCE CODE
** (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
** INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE
** OF THE SOURCE CODE TO OPERATE WITH ANY OTHER PROGRAM), EVEN IF SUCH
** HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGES.
**
****************************************************************************/
#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <setjmp.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <cmocka.h>

#include <debug/sahtrace.h>
#include "swl/swl_common.h"
#include "swl/swl_common_type.h"
#include "swl/fileOps/swl_fileUtils.h"
#include "swl/types/swl_arrayType.h"
#include "swl/swl_common_tupleType.h"
#include "swl/swl_map.h"
#include "swl/types/swl_mapType.h"

#define NR_VALUES 12



#define MY_TEST_MAP_KEY_VAR(X, Y) \
    X(Y, gtSwl_type_int64, index) \
    X(Y, gtSwl_type_charPtr, val)
SWL_TT(tMyTestKey, swl_myTestKey_t, MY_TEST_MAP_KEY_VAR, )

#define MY_TEST_MAP_VALUE_VAR(X, Y) \
    X(Y, gtSwl_type_int8, test2) \
    X(Y, gtSwl_type_int64, index) \
    X(Y, gtSwl_type_charPtr, val)
SWL_TT(tMyTestValue, swl_myTestValue_t, MY_TEST_MAP_VALUE_VAR, )

SWL_MAP_TYPE(tMyTestMap, &tMyTestKey.type, &tMyTestValue.type);


swl_arrayType_t* testArrType;
const char* filePrefix;
/**
 * Defining a tuple type using a table
 */
swl_myTestKey_t myTestKeyValues[NR_VALUES] = {
    {1001, "test1k"},
    {-2001, "test2k"},
    {2898701, "foobark"},
    {-2898691, "barfook"},
    {1002, "test1kl"},
    {-2002, "test2kl"},
    {2898702, "foobarkl"},
    {-2898692, "barfookl"},
    {1003, "test1km"},
    {-2003, "test2km"},
    {2898703, "foobarkm"},
    {-2898693, "barfookm"},
};

swl_myTestValue_t myTestValues[NR_VALUES] = {
    {11, 1001, "test1a"},
    {21, -2001, "test2a"},
    {-81, 289871, "foobara"},
    {81, -289861, "barfooa"},
    {12, 102, "test1b"},
    {22, -202, "test2b"},
    {-82, 289872, "foobarb"},
    {82, -289862, "barfoob"},
    {12, 103, "test1c"},
    {22, -203, "test2c"},
    {-82, 289873, "foobarc"},
    {82, -289863, "barfooc"},
};

#define NR_TEST_MAPS 4

swl_map_t testMaps[NR_TEST_MAPS];

static void test_swl_mapToFromChar(void** state _UNUSED) {
    for(size_t i = 0; i < NR_TEST_MAPS; i++) {
        char buffer[512] = {0};
        ssize_t tmpSize = swl_type_toChar(&tMyTestMap.type, buffer, sizeof(buffer), &testMaps[i]);

        assert_true(tmpSize > 0);
        printf("%s\n", buffer);

        swl_map_t tmpMap;
        memset(&tmpMap, 0, sizeof(tmpMap));
        assert_true(swl_type_fromChar(&tMyTestMap.type, &tmpMap, buffer));

        char buffer2[512] = {0};
        swl_type_toChar(&tMyTestMap.type, buffer2, sizeof(buffer2), &tmpMap);
        printf("%s\n", buffer2);

        assert_true(swl_type_equals(&tMyTestMap.type, &tmpMap, &testMaps[i]));

        swl_type_cleanup(&tMyTestMap.type, &tmpMap);
    }
}


static void test_swl_mapCopyEquals(void** state _UNUSED) {
    for(size_t i = 0; i < NR_TEST_MAPS; i++) {
        swl_typeData_t* data = swl_type_copy(&tMyTestMap.type, &testMaps[i]);
        assert_ptr_not_equal(data, &testMaps[i]);

        for(size_t j = 0; j < NR_TEST_MAPS; j++) {
            if(i == j) {
                assert_true(swl_type_equals(&tMyTestMap.type, &testMaps[j], data));
            } else {
                assert_false(swl_type_equals(&tMyTestMap.type, &testMaps[j], data));
            }
        }

        swl_type_cleanupPtr(&tMyTestMap.type, &data);
    }

}
static void test_swl_mapToFile(void** state _UNUSED) {
    for(size_t i = 0; i < SWL_ARRAY_SIZE(testMaps); i++) {
        char fileNameBuf[128] = {0};
        snprintf(fileNameBuf, sizeof(fileNameBuf), "data_%zu.txt", i);

        //char* tmpFile = "tmp.txt";
        FILE* fp = fopen(fileNameBuf, "w");
        swl_type_toFile(&tMyTestMap.type, fp, &testMaps[i], &g_swl_print_jsonCompact);
        fclose(fp);
        //assert_true(swl_fileUtils_contentMatches(fileNameBuf, tmpFile));
        //unlink(tmpFile);
    }
}

static int setup_suite(void** state _UNUSED) {
    for(size_t i = 0; i < NR_TEST_MAPS; i++) {
        memset(&testMaps[i], 0, sizeof(swl_map_t));
        swl_map_init(&testMaps[i], &tMyTestKey.type, &tMyTestValue.type);

        if((i % 2) == 1) {
            for(size_t j = 0; j < NR_VALUES / 2; j++) {
                swl_map_add(&testMaps[i], &myTestKeyValues[j], &myTestValues[j]);
            }
        }
        if((i / 2) == 1) {
            for(size_t j = 0; j < NR_VALUES / 2; j++) {
                swl_map_add(&testMaps[i], &myTestKeyValues[j + NR_VALUES / 2], &myTestValues[j + NR_VALUES / 2]);
            }
        }
    }


    return 0;
}

static int teardown_suite(void** state _UNUSED) {
    for(size_t i = 0; i < NR_TEST_MAPS; i++) {
        swl_map_cleanup(&testMaps[i]);
    }
    return 0;
}

int main(int argc _UNUSED, char* argv[] _UNUSED) {
    sahTraceOpen(__FILE__, TRACE_TYPE_STDERR);
    if(!sahTraceIsOpen()) {
        fprintf(stderr, "FAILED to open SAH TRACE\n");
    }
    sahTraceSetLevel(TRACE_LEVEL_WARNING);
    sahTraceSetTimeFormat(TRACE_TIME_APP_SECONDS);
    sahTraceAddZone(sahTraceLevel(), "swlConv");
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_swl_mapToFromChar),
        cmocka_unit_test(test_swl_mapCopyEquals),
        cmocka_unit_test(test_swl_mapToFile),
    };

    int rc = cmocka_run_group_tests(tests, setup_suite, teardown_suite);

    sahTraceClose();
    return rc;
}
