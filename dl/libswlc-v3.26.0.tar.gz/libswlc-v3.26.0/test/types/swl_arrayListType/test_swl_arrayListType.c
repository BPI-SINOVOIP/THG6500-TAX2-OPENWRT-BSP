/****************************************************************************
**
** Copyright (C) 2020 SoftAtHome. All rights reserved.
**
** SoftAtHome reserves all rights not expressly granted herein.
**
** - DISCLAIMER OF WARRANTY -
**
** THIS FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
** EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
** WARRANTIES OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
** PURPOSE.
**
** THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE SOURCE
** CODE IS WITH YOU. SHOULD THE SOURCE CODE PROVE DEFECTIVE, YOU
** ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
**
** - LIMITATION OF LIABILITY -
**
** IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
** WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES
** AND/OR DISTRIBUTES THE SOURCE CODE, BE LIABLE TO YOU FOR DAMAGES,
** INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
** ARISING OUT OF THE USE OR INABILITY TO USE THE SOURCE CODE
** (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
** INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE
** OF THE SOURCE CODE TO OPERATE WITH ANY OTHER PROGRAM), EVEN IF SUCH
** HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGES.
**
****************************************************************************/
#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <setjmp.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <cmocka.h>

#include <debug/sahtrace.h>
#include "swl/swl_common.h"
#include "swl/swl_common_type.h"
#include "swl/types/swl_arrayBufType.h"
#include "swl/types/swl_arrayListType.h"
#include "swl/swl_common_tupleType.h"
#include "swl/fileOps/swl_fileUtils.h"

#define NR_TYPES 6
#define NR_VALUES 4


#define MY_TEST_TABLE_VAR(X, Y) \
    X(Y, gtSwl_type_int8, test2) \
    X(Y, gtSwl_type_int64, index) \
    X(Y, gtSwl_type_charPtr, val)

SWL_TT(tMyTestTupleType, swl_myTestTT_t, MY_TEST_TABLE_VAR, )
#define ptMyTestTupleType (swl_type_t*) &tMyTestTupleType

SWL_ARRAY_BUF_TYPE(tMyTestArrayBufType, tMyTestTupleType, 4, false);

SWL_ARRAY_LIST_TYPE(tMyTestArrayListType, tMyTestTupleType, false);
#define ptMyTestArrayListType (swl_type_t*) &tMyTestArrayListType
/**
 * Defining a tuple type using a table
 */
swl_myTestTT_t myTestValues[NR_VALUES] = {
    {1, 100, "test1"},
    {2, -200, "test2"},
    {-88, 289870, "foobar"},
    {88, -289869, "barfoo"},
};


#define NR_TEST_EL 6

tMyTestArrayBufType_type testData[NR_TEST_EL] = {
    {.data = {
            {1, 100, "test1"},
            {2, -200, "test2"},
            {-88, 289870, "foobar"},
            {88, -289869, "barfoo"},
        }, .size = 4},
    {.data = {
            {2, 100, "test1"}, // 2 changed here
            {2, -200, "test2"},
            {-88, 289870, "foobar"},
            {88, -289869, "barfoo"},
        }, .size = 4},
    {.data = {
            {2, 100, "test1"},
            {2, -202, "test2"}, // -202 changed here
            {-88, 289870, "foobar"},
            {88, -289869, "barfoo"},
        }, .size = 4},
    {.data = {
            {2, 100, "test1"},
            {2, -200, "test2"},
            {-88, 289870, "foobars"}, // fobars changed here
            {88, -289869, "barfoo"},
        }, .size = 4},
    {.data = {
            {1, 100, "test1"},
            {2, -200, "test2"},
            {-88, 289870, "foobar"},
        }, .size = 3},
    {.data = {
        }
        , .size = 0},
};


swl_arrayList_t testLists[NR_TEST_EL] = {0};

static void test_swl_typeArrayToFromChar(void** state _UNUSED) {
    for(size_t i = 0; i < SWL_ARRAY_SIZE(testData); i++) {
        char buffer[256] = {0};
        ssize_t tmpSize = swl_type_toChar((swl_type_t*) &tMyTestArrayListType, buffer, sizeof(buffer), &testLists[i]);
        swl_arrayList_t dataBuff;
        memset(&dataBuff, 0, sizeof(dataBuff));

        printf("%s\n", buffer);
        assert_true(tmpSize > 0);
        assert_true(swl_type_fromChar((swl_type_t*) &tMyTestArrayListType, &dataBuff, buffer));

        assert_true(swl_type_equals((swl_type_t*) &tMyTestArrayListType, &dataBuff, &testLists[i]));

        swl_type_cleanup((swl_type_t*) &tMyTestArrayListType, &dataBuff);
    }
}


static void test_swl_typeArrayCopyEquals(void** state _UNUSED) {
    for(size_t i = 0; i < SWL_ARRAY_SIZE(testData); i++) {
        swl_typeData_t* data = swl_type_copy((swl_type_t*) &tMyTestArrayListType, &testLists[i]);
        assert_ptr_not_equal(data, &testData[i]);

        for(size_t j = 0; j < SWL_ARRAY_SIZE(testData); j++) {
            if(i == j) {
                assert_true(swl_type_equals((swl_type_t*) &tMyTestArrayListType, &testLists[j], data));
            } else {
                assert_false(swl_type_equals((swl_type_t*) &tMyTestArrayListType, &testLists[j], data));
            }
        }

        swl_type_cleanupPtr((swl_type_t*) &tMyTestArrayListType, &data);
    }
}
static void test_swl_arrayListToFile(void** state _UNUSED) {
    for(size_t i = 0; i < SWL_ARRAY_SIZE(testData); i++) {
        char fileNameBuf[128] = {0};
        snprintf(fileNameBuf, sizeof(fileNameBuf), "../common/norm_data_%zu.txt", i);

        char* tmpFile = "tmp.txt";
        FILE* fp = fopen(tmpFile, "w");
        swl_type_toFile(ptMyTestArrayListType, fp, &testLists[i], &g_swl_print_json);
        fclose(fp);
        assert_true(swl_fileUtils_contentMatches(fileNameBuf, tmpFile));
        unlink(tmpFile);
    }
}

static void test_swl_arrayListIterate(void** state _UNUSED) {

    for(size_t i = 0; i < SWL_ARRAY_SIZE(testData); i++) {
        size_t index = 0;
        {swl_arrayList_forEachRef(it, swl_myTestTT_t, data, &testLists[i]) {
                assert_true(swl_type_equals(ptMyTestTupleType, data, &testData[i].data[index]));
                index++;
            }}
        assert_int_equal(index, testData[i].size);

        index = 0;

        {swl_arrayList_forEachVal(it, swl_myTestTT_t, data, &testLists[i]) {
                assert_true(swl_type_equals(ptMyTestTupleType, &data, &testData[i].data[index]));
                index++;
            }}
        assert_int_equal(index, testData[i].size);
    }
}


static int setup_suite(void** state _UNUSED) {
    printf("TYPE INIT %p\n", &tMyTestTupleType);
    for(size_t i = 0; i < SWL_ARRAY_SIZE(testData); i++) {
        testData[i].maxSize = 4;
        testData[i].type = (swl_type_t*) &tMyTestTupleType;

        swl_arrayList_initFromArray(&testLists[i], (swl_type_t*) &tMyTestTupleType, testData[i].data, testData[i].size);

    }

    return 0;
}


static int teardown_suite(void** state _UNUSED) {
    for(size_t i = 0; i < SWL_ARRAY_SIZE(testData); i++) {
        swl_arrayList_cleanup(&testLists[i]);
    }
    return 0;
}

int main(int argc _UNUSED, char* argv[] _UNUSED) {
    sahTraceOpen(__FILE__, TRACE_TYPE_STDERR);
    if(!sahTraceIsOpen()) {
        fprintf(stderr, "FAILED to open SAH TRACE\n");
    }
    sahTraceSetLevel(TRACE_LEVEL_WARNING);
    sahTraceSetTimeFormat(TRACE_TIME_APP_SECONDS);
    sahTraceAddZone(sahTraceLevel(), "swlConv");
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_swl_typeArrayToFromChar),
        cmocka_unit_test(test_swl_typeArrayCopyEquals),
        cmocka_unit_test(test_swl_arrayListToFile),
        cmocka_unit_test(test_swl_arrayListIterate),
    };

    int rc1 = cmocka_run_group_tests(tests, setup_suite, teardown_suite);

    sahTraceClose();
    return rc1;
}
