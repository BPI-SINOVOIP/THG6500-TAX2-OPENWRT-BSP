/****************************************************************************
**
** Copyright (C) 2020 SoftAtHome. All rights reserved.
**
** SoftAtHome reserves all rights not expressly granted herein.
**
** - DISCLAIMER OF WARRANTY -
**
** THIS FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
** EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
** WARRANTIES OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
** PURPOSE.
**
** THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE SOURCE
** CODE IS WITH YOU. SHOULD THE SOURCE CODE PROVE DEFECTIVE, YOU
** ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
**
** - LIMITATION OF LIABILITY -
**
** IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
** WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES
** AND/OR DISTRIBUTES THE SOURCE CODE, BE LIABLE TO YOU FOR DAMAGES,
** INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
** ARISING OUT OF THE USE OR INABILITY TO USE THE SOURCE CODE
** (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
** INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE
** OF THE SOURCE CODE TO OPERATE WITH ANY OTHER PROGRAM), EVEN IF SUCH
** HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGES.
**
****************************************************************************/

#ifndef SRC_TEST_TYPES_SWL_COLLTYPE_TESTCOMMON_SWL_COLLTYPE_H_
#define SRC_TEST_TYPES_SWL_COLLTYPE_TESTCOMMON_SWL_COLLTYPE_H_
#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <setjmp.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <cmocka.h>

#include <debug/sahtrace.h>
#include "swl/swl_common.h"
#include "swl/swl_common_type.h"
#include "swl/fileOps/swl_fileUtils.h"
#include "swl/types/swl_arrayType.h"
#include "swl/types/swl_vectorType.h"
#include "swl/types/swl_arrayListType.h"
#include "swl/types/swl_arrayBufType.h"
#include "swl/types/swl_ttaType.h"
#include "swl/swl_common_tupleType.h"
#include "swl/ttb/swl_ttb.h"

typedef struct {
    swl_collTypeFun_t* fun; //Collection Under Test
    swl_collType_t* type;   //Collection Under Test
    size_t maxSize;
    bool allowEmpty;
    size_t colSize;
    const char* printFolder; // Folder for print tests
    bool implicitSize;       // Whether the size is implicitly calculated from content
} swl_colTypeTest_t;

int testCommon_swl_collType_runTest(swl_colTypeTest_t* tut);

#define MY_COLL_TEST_TABLE_VAR(X, Y) \
    X(Y, gtSwl_type_int8, test) \
    X(Y, gtSwl_type_int64, index) \
    X(Y, gtSwl_type_charPtr, val)
SWL_TT_H(gtSwl_collTypeTestTT, swl_collTypeTestTT_t, MY_COLL_TEST_TABLE_VAR, );

#define NR_COLL_TYPE_TEST_TYPES 3

extern char* swl_colTypeTestNames[];

//Default nr values per collection
#define NR_COLL_TYPE_TEST_VALUES_DEFAULT 4


#define NR_COLL_TYPE_TEST_VALUES 18
//
extern swl_collTypeTestTT_t collTypeTestValues[];

extern void* collTypeTestArrays[];


#define NR_COLL_TYPE_MASK_VALUES (2 << NR_COLL_TYPE_TEST_TYPES)
extern swl_collTypeTestTT_t collTypeMaskValues[];


SWL_ARRAY_BUF_TYPE_H(gtSwl_collTypeTestArrayBuf, gtSwl_collTypeTestTT, 4);

#define NR_COLL_TYPE_TEST_DATA_VALUES 6
extern gtSwl_collTypeTestArrayBuf_type collTypeTestData[];




#endif /* SRC_TEST_TYPES_SWL_COLLTYPE_TESTCOMMON_SWL_COLLTYPE_H_ */
