/****************************************************************************
**
** Copyright (C) 2020 SoftAtHome. All rights reserved.
**
** SoftAtHome reserves all rights not expressly granted herein.
**
** - DISCLAIMER OF WARRANTY -
**
** THIS FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
** EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
** WARRANTIES OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
** PURPOSE.
**
** THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE SOURCE
** CODE IS WITH YOU. SHOULD THE SOURCE CODE PROVE DEFECTIVE, YOU
** ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
**
** - LIMITATION OF LIABILITY -
**
** IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
** WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES
** AND/OR DISTRIBUTES THE SOURCE CODE, BE LIABLE TO YOU FOR DAMAGES,
** INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
** ARISING OUT OF THE USE OR INABILITY TO USE THE SOURCE CODE
** (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
** INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE
** OF THE SOURCE CODE TO OPERATE WITH ANY OTHER PROGRAM), EVEN IF SUCH
** HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGES.
**
****************************************************************************/
#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <setjmp.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <cmocka.h>

#include <debug/sahtrace.h>
#include "swl/swl_common.h"
#include "swl/swl_common_type.h"
#include "swl/types/swl_ttaType.h"
#include "swl/swl_common_tupleType.h"
#include "swl/fileOps/swl_fileUtils.h"

#include "test-toolbox/ttb_assert.h"


#include "testCommon_swl_collType.h"
#include "testCommon_swl_ttCollType.h"

SWL_TTA_TYPE(tMyTestTtaType, gtSwl_collTypeTestTT, 4, false, false);
SWL_TTA_TYPE(tMyTestTtaTypeNull, gtSwl_collTypeTestTT, 4, true, false);


static swl_colTypeTest_t testCol[] = {
    {.fun = &swl_ttaCollType_fun,
        .maxSize = 4,
        .type = &tMyTestTtaType.type,
        .printFolder = "print",
        .implicitSize = true, },
    {.fun = &swl_ttaCollType_fun,
        .maxSize = 4,
        .type = &tMyTestTtaTypeNull.type,
        .allowEmpty = true,
        .printFolder = "print",
        .implicitSize = true, },
};


static swl_ttColTypeTest_t ttTestCol[] = {
    {.fun = &swl_ttaTtCollType_fun,
        .maxSize = 4,
        .type = &tMyTestTtaType.type,
        .listPrintFolder = "print",
        .mapPrintFolder = "printMap",
        .implicitSize = true, },
    {.fun = &swl_ttaTtCollType_fun,
        .maxSize = 4,
        .type = &tMyTestTtaTypeNull.type,
        .allowEmpty = true,
        .listPrintFolder = "print",
        .mapPrintFolder = "printMap",
        .implicitSize = true, },
};

int main(int argc _UNUSED, char* argv[] _UNUSED) {
    size_t start = 0;
    size_t end = SWL_ARRAY_SIZE(testCol) - 1;
    //start = end = 0; // Easy comment for partial debug

    int rc = 0;
    for(size_t i = start; i <= end; i++) {
        rc += testCommon_swl_collType_runTest(&testCol[i]);
        rc += testCommon_swl_ttCollType_runTest(&ttTestCol[i]);
    }
    return rc;
}
