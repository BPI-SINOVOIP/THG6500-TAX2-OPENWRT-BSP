# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## Release v3.26.0 - 2023-03-08(16:11:10 +0000)

### Other

- define 80211 management action wnm frame

## Release v3.25.0 - 2023-03-08(12:44:49 +0000)

## Release v3.24.1 - 2023-03-07(14:08:58 +0000)

### Other

- Add Operating Classes for United States and Japan

## Release v3.24.0 - 2023-03-07(11:25:18 +0000)

### Other

- - test issue due to uninitialized memory

## Release v3.23.0 - 2023-03-03(09:03:17 +0000)

### Other

- add api to locate IEs in 80211 management frame

## Release v3.22.2 - 2023-02-21(15:53:17 +0000)

## Release v3.22.1 - 2023-02-20(12:10:50 +0000)

### Other

- SecurityModesSupported not filled, impacting band steering in WPA2-WPA3

## Release v3.22.0 - 2023-02-13(11:26:05 +0000)

### Other

- - add radStd to Mcs & checkMatches function

## Release v3.21.3 - 2023-02-09(08:34:06 +0000)

### Other

- - add reproting detail element id

## Release v3.21.2 - 2023-02-07(09:42:34 +0000)

### Other

- : add certificate validation

## Release v3.21.1 - 2023-02-06(16:21:19 +0000)

### Other

- : add certificate validation

## Release v3.21.0 - 2023-02-03(10:39:19 +0000)

### Other

- - add more options for IEEE80211v BTM request

## Release v3.20.1 - 2023-02-01(13:52:33 +0000)

### Other

- : add RSSI from RCPI function

## Release v3.20.0 - 2023-01-31(16:10:35 +0000)

### Other

- - add more options for IEEE80211v BTM request

## Release v3.19.2 - 2023-01-31(15:56:20 +0000)

### Other

- - Fix testing dependencies

## Release v3.19.1 - 2023-01-31(09:39:50 +0000)

### Other

- Add MFP required constraint for OWE security mode

## Release v3.19.0 - 2023-01-30(10:55:55 +0000)

### Other

- add apis to check apMode type to deduce mfp mode

## Release v3.18.0 - 2023-01-30(09:07:33 +0000)

### Other

- add apis to convert mfp modes to/from string

## Release v3.17.0 - 2023-01-27(09:21:46 +0000)

### Other

- add apis to convert security modes mask to/from string

## Release v3.16.1 - 2023-01-23(11:32:43 +0000)

### Other

- - add SWL prefix to avoid redefinition

## Release v3.16.0 - 2023-01-17(14:30:45 +0000)

### Other

- add api to count differences in two strings

## Release v3.15.0 - 2023-01-12(14:00:37 +0000)

### Other

- add apis to map wps config method IDs and names

## Release v3.14.0 - 2023-01-12(13:33:07 +0000)

### Other

- - RRM request fields and report parsing

## Release v3.13.1 - 2023-01-11(08:37:43 +0000)

### Other

- : add new swl fileUtils function

## Release v3.13.0 - 2023-01-10(10:40:24 +0000)

### Other

- improve management frame IEs parsing

## Release v3.12.5 - 2023-01-09(09:02:13 +0000)

### Other

- - Add RRM Capabilties string flags

## Release v3.12.4 - 2023-01-05(11:24:26 +0000)

### Other

- - Fix swlc debug when empty type array

## Release v3.12.2 - 2023-01-04(13:35:45 +0000)

### Other

- - IEEE80211k capabilities per station

## Release v3.12.1 - 2022-12-21(13:47:41 +0000)

### Other

- Extract utils from WLD

## Release v3.12.0 - 2022-12-20(14:21:46 +0000)

### Other

- - fix circ table

## Release v3.11.0 - 2022-12-20(09:41:32 +0000)

### Other

- - add tuple type array

## Release v3.10.0 - 2022-12-16(10:49:37 +0000)

### Other

- - add zero deauth code

## Release v3.9.0 - 2022-12-16(10:25:32 +0000)

### Other

- - [nl80211] scan/scanResults commands

## Release v3.8.0 - 2022-12-09(14:39:23 +0000)

### Other

- - Add nice histogram init, and update tests

## Release v3.7.0 - 2022-12-06(17:13:56 +0000)

### Other

- - [prplMesh WHM] Adding operating_class and channel for the NonAssociatedDevice object

## Release v3.6.3 - 2022-12-06(14:42:54 +0000)

### Other

- - add assert ok, and print iso assert update

## Release v3.6.2 - 2022-12-05(09:50:57 +0000)

### Other

- - Too many logs
- remove squash commits as no needed anymore

## Release v3.6.1 - 2022-11-29(14:02:20 +0000)

### Fixes

- : Add swl_strlst_copyStringAtIndex util function

## Release v3.6.0 - 2022-11-25(13:26:00 +0000)

### New

- - Add round and multComplement functions

## Release v3.5.0 - 2022-11-25(12:40:06 +0000)

### Other

- - add file compare function

## Release v3.4.1 - 2022-11-21(15:38:55 +0000)

### Other

- - Compile issue due to FILE not known

## Release v3.4.0 - 2022-11-21(08:20:54 +0000)

### Other

- - add ref type, and initial read from file support

## Release v3.3.0 - 2022-11-17(15:20:17 +0000)

### Other

- - add annotated tuple type, and allow more than 32 fields.

## Release v3.2.1 - 2022-11-08(15:37:39 +0000)

### Other

- - Fix arrayFromCharSep with empty string

## Release v3.2.0 - 2022-11-04(09:04:44 +0000)

### Other

- - Add type for trilean

## Release v3.1.2 - 2022-11-03(12:44:00 +0000)

### Other

- Add functions to validate channel for a specific band

## Release v3.1.1 - 2022-11-03(09:48:41 +0000)

### Other

- Define default channels set

## Release v3.1.0 - 2022-11-03(09:22:57 +0000)

### Other

- - Update map type

## Release v3.0.0 - 2022-11-02(14:56:56 +0000)

### Other

- - Add collection type

## Release v2.10.12 - 2022-10-28(12:14:02 +0000)

### Other

- Add append option for WriteKVP file updating

## Release v2.10.11 - 2022-10-28(11:41:48 +0000)

### Other

- : Add encoding data function from X509 data

## Release v2.10.9 - 2022-10-06(12:57:52 +0000)

### Other

- - format security build option fails to build

## Release v2.10.8 - 2022-10-05(09:54:28 +0000)

### Other

- - Add type to tupleType

## Release v2.10.7 - 2022-10-03(15:03:21 +0000)

### Other

- update all files to BSD-2 license

## Release v2.10.6 - 2022-09-27(12:53:11 +0000)

### Other

- - add array diff

## Release v2.10.5 - 2022-09-26(07:52:49 +0000)

### Other

- [SSL] upstep to openssl 3.x.x

## Release v2.10.4 - 2022-09-21(10:06:54 +0000)


- - OUI not handled right

## Release v2.10.3 - 2022-09-20(13:49:27 +0000)

### Other

- - header wrong
- Add SSID string length definition

## Release v2.10.2 - 2022-09-20(07:36:37 +0000)

### Other

- fix compatibilty with old openssl versions (<1.1.1)

## Release v2.10.1 - 2022-09-19(09:24:31 +0000)

### Other

- - Remove need for packed

## Release v2.10.0 - 2022-09-15(14:29:07 +0000)

### Other

- - Add named tuple type

## Release v2.9.1 - 2022-09-08(10:28:35 +0000)

### Other

- Update RNR information

## Release v2.9.0 - 2022-09-02(10:38:55 +0000)

### Other

- define USP tr181 command status codes and strings

## Release v2.8.6 - 2022-09-02(09:45:15 +0000)

### Other

- : Add private key decoding using EVP_PKEY

## Release v2.8.5 - 2022-08-30(13:20:50 +0000)

### Other

- Add FortyMHz Intolerant bit in datamodel per STA

## Release v2.8.4 - 2022-08-30(12:23:04 +0000)

### Other

- - Update the deauth enum with new reason code

## Release v2.8.3 - 2022-08-30(09:03:44 +0000)

### Other

- : Add encode/decode data function using openssl

## Release v2.8.2 - 2022-08-29(08:44:37 +0000)

### Other

- : EndPoint traffic not taken into account in APRoaming

## Release v2.8.1 - 2022-08-29(08:15:09 +0000)

### Other

- : Add TWT capability per STA in the datamodel

## Release v2.8.0 - 2022-08-02(12:53:46 +0000)

### Other

- - add apis to get radio standard from mcs standard

## Release v2.7.3 - 2022-07-26(10:01:46 +0000)

### Other

- fix dep to ssl in tmssw feed

## Release v2.7.2 - 2022-07-26(07:45:29 +0000)

### Other

- - swlc v2.7.1 does not build

## Release v2.7.1 - 2022-07-25(07:59:56 +0000)

### Other

- : Add TWT capability per STA in the datamodel

## Release v2.7.0 - 2022-07-20(09:47:54 +0000)

### Other

- - Add toFile option for type

## Release v2.6.2 - 2022-07-19(09:46:31 +0000)

### Other

- - add extra support function to swl_timespec

## Release v2.6.1 - 2022-07-18(09:39:24 +0000)

### Other

- - Add tests

## Release v2.6.0 - 2022-06-29(09:36:45 +0000)

### Other

- add mapChar value formatting apis

## Release v2.5.0 - 2022-06-27(12:59:38 +0000)

### Other

- - Fix type toChar return

## Release v2.4.1 - 2022-06-24(11:59:50 +0000)

### Other

- fix link to ssl

## Release v2.4.0 - 2022-06-23(13:10:02 +0000)

### Other

- - add IEEE80211 mgmt frame defines

## Release v2.3.0 - 2022-06-21(13:49:36 +0000)

### Other

- - updating PACKED, OUI and type defines
- - Add swl_bit*_t, swl_enum_e and swl_mask_m types

## Release v2.2.2 - 2022-06-17(12:57:12 +0000)

### Other

- : Detect a probing station

## Release v2.2.1 - 2022-06-17(11:47:54 +0000)

### Other

- - [prplMesh_WHM] provide STA capabilities for STA connected BWL Event

## Release v2.2.0 - 2022-06-17(09:09:42 +0000)

### Other

- [amx] ambiorix swlc awla and wld/pwhm structure

## Release v2.1.0 - 2022-06-16(11:50:57 +0000)

### Other

- Eye's on wifi : Adding bit swapper macros and mcs flag enums/strings.

## Release v2.0.6 - 2022-06-16(09:52:42 +0000)

### Other

- : multi-ep support for ap-roaming

## Release v2.0.5 - 2022-06-14(15:30:22 +0000)

### Other

- - Add subtype constants of frame control field

## Release v2.0.4 - 2022-06-09(09:24:33 +0000)

### Other

- revert ambiorix template

## Release v2.0.3 - 2022-06-08(08:24:50 +0000)

### Other

- include ambiorix template for ambiorix components

## Release v2.0.2 - 2022-06-03(11:52:22 +0000)

### Other

- : multi-ep support for ap-roaming
- [prpl] opensource pwhm swla and swlc
