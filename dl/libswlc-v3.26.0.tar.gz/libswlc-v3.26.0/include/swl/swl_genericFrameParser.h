/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
/**
 * Defines for ieee802.11 frame information
 */

#ifndef SRC_INCLUDE_SWL_SWL_GENERIC_FRAME_PARSER_H_
#define SRC_INCLUDE_SWL_SWL_GENERIC_FRAME_PARSER_H_

#include "swl/swl_80211.h"
#include "swl/swl_common_oui.h"
#include "swl/swl_common_chanspec.h"
#include "swl/swl_security.h"
#include "swl/swl_staCap.h"
#include "swl/swl_wps.h"

typedef struct {
    swl_chanspec_t operChanInfo;
    // For AssocDevice
    swl_uniiBand_m uniiBandsCapabilities;

    // For AssocDevice Caps
    swl_oui_list_t vendorOUI;
    swl_staCap_m capabilities;
    swl_staCapHt_m htCapabilities;
    swl_staCapVht_m vhtCapabilities;
    swl_staCapHe_m heCapabilities;
    swl_staCapRrm_m rrmCapabilities;
    uint32_t rrmOnChannelMaxDuration;
    uint32_t rrmOffChannelMaxDuration;
    swl_freqBandExt_m freqCapabilities;

    // For SSID Scan
    uint8_t ssidLen;
    char ssid[SWL_80211_SSID_STR_LEN];
    swl_security_apMode_e secModeEnabled;
    swl_radioStandard_m operatingStandards;
    swl_wps_cfgMethod_m WPS_ConfigMethodsEnabled;

} swl_wirelessDevice_infoElements_t;

/*
 * @brief optional argument that may improve frame IEs parsing
 */
typedef struct {
    swl_chanspec_t seenOnChanspec; //channel on which the frame has been seen.
} swl_parsingArgs_t;


swl_rc_ne swl_80211_processInfoElementFrame(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs, uint8_t elementId, int8_t len, uint8_t* data);

/*
 * @brief Parse 80211 Info Elements buffer (including TLVs) into user data structure
 *
 * @param pWirelessDevIE: (out) pointer to device info to be filled
 * @param pParsingArgs: (in) pointer to optional parsing argument, that may be used to initialize some result values
 * @param iesLen: (in) Information Elements buffer length
 * @param iesData: (in) Information Elements buffer data
 *
 * @return number of processed bytes of the input buffer (shall be equal to iesLen when all data has been processed)
 *         or negative SWL_RC error code when major error happens.
 *         It is up to application to consider error when parsing is partial (i.e returning < iesLen)
 */
ssize_t swl_80211_parseInfoElementsBuffer(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs, size_t iesLen, uint8_t* iesData);

/*
 * @brief check frame raw data as management frame
 *
 * @param frameData: (in) Management frame binary data
 * @param frameLen: (in) Management frame binary data length
 *
 * @return pointer to management frame struct when raw data checking is successful
 *         or NULL in case of error
 */
swl_80211_mgmtFrame_t* swl_80211_getMgmtFrame(swl_bit8_t* frameData, size_t frameLen);

/*
 * @brief locate 80211 Info Elements (with TLVs) into management frame raw data
 *
 * @param pIesLen: (out) length of located IEs Information Elements Tags (TLVs)
 * @param frameData: (in) Management frame binary data
 * @param frameLen: (in) Management frame binary data length
 *
 * @return pointer to located Information Elements Tags (TLVs)
 *         or NULL in case of error:
 *         invalid frame length or unsupported management frame subType
 */
swl_bit8_t* swl_80211_getInfoElementsOfMgmtFrame(size_t* pIesLen, swl_bit8_t* frameData, size_t frameLen);

swl_rc_ne swl_80211_getDataAKMsuite(uint8_t type, swl_80211_akm_m* akmSuiteParams);
swl_rc_ne swl_80211_getDataCipherSuite(uint8_t type, swl_80211_cipher_m* cipherSuiteParams);



#endif /* SRC_INCLUDE_SWL_SWL_GENERIC_FRAME_PARSER_H_ */

