/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#define _GNU_SOURCE

#include "swl/swl_common.h"
#include "swl/swl_common_type.h"
#include "swl/types/swl_collType.h"
#include "swl/types/swl_ttaType.h"
#include "swl/types/swl_tupleTypeArray.h"
#include "swl/swl_string.h"

#define ME "swlTTAT"

/**
 * array handlers
 */
static ssize_t s_toChar_cb(swl_type_t* type, char* tgtStr, size_t tgtStrSize, const swl_typeData_t* srcData) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    return swl_tta_printLists(elementType, tgtStr, tgtStrSize, srcData, ttaType->maxNrElements, 0);
}


static bool s_equals_cb(swl_type_t* type, const swl_typeData_t* key0, const swl_typeData_t* key1) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    return swl_tta_equals(elementType, key0, ttaType->maxNrElements, key1, ttaType->maxNrElements);
}

static void s_cleanup_cb (swl_type_t* type, swl_typeEl_t* tgtData) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    swl_tta_cleanup(elementType, tgtData, ttaType->maxNrElements);
}

static swl_typeData_t* s_copy_cb (swl_type_t* type, const swl_typeData_t* src) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    swl_typeData_t* data = calloc(1, ttaType->type.type.size);

    const swl_tuple_t* srcArr = (const swl_tuple_t*) src;
    swl_tuple_t* tgtArr = (swl_tuple_t*) data;

    for(size_t i = 0; i < ttaType->maxNrElements; i++) {
        swl_type_copyTo(&elementType->type,
                        swl_tta_getTuple(elementType, tgtArr, ttaType->maxNrElements, i),
                        swl_tta_getTuple(elementType, srcArr, ttaType->maxNrElements, i));
    }

    return data;
}

static bool s_toFile_cb (swl_type_t* type, FILE* file, const swl_typeData_t* srcData, swl_print_args_t* args) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;
    return swl_tta_fprintLists(elementType, file,
                               srcData, ttaType->maxNrElements, 0, ttaType->allowEmpty, args);
}

swl_typeFun_t swl_ttaType_fun = {
    .isValue = true,
    .flag = SWL_TYPE_FLAG_LIST,
    .toChar = (swl_type_toChar_cb) s_toChar_cb,
    .equals = (swl_type_equals_cb) s_equals_cb,
    .cleanup = (swl_type_cleanup_cb) s_cleanup_cb,
    .copy = (swl_type_copy_cb) s_copy_cb,
    .toFile = (swl_type_toFile_cb) s_toFile_cb,
};

static swl_rc_ne s_col_init_cb(swl_collType_t* colType, swl_coll_t* inCollection) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    memset(inCollection, 0, ttaType->type.elementType->size * ttaType->maxNrElements);
    return SWL_RC_OK;
}

static swl_rc_ne s_col_initFromArray_cb(swl_collType_t* colType, swl_coll_t* inCollection, swl_typeEl_t* array, size_t arraySize) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    memset(inCollection, 0, ttaType->type.elementType->size * ttaType->maxNrElements);
    swl_type_t* elementType = ttaType->type.elementType;

    swl_rc_ne ret = swl_type_arrayCopy(elementType, inCollection, array, SWL_MIN(arraySize, ttaType->maxNrElements));

    if(swl_rc_isOk(ret)) {
        return arraySize <= ttaType->maxNrElements ? SWL_RC_OK : SWL_RC_NOT_AVAILABLE;
    } else {
        return ret;
    }
}

static size_t s_col_maxSize_cb(swl_collType_t* colType, swl_coll_t* inCollection _UNUSED) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    return ttaType->maxNrElements;
}

static void s_col_clear_cb(swl_collType_t* colType, swl_coll_t* inCollection) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    swl_tta_cleanup(elementType, inCollection, ttaType->maxNrElements);
}

static void s_col_cleanup_cb(swl_collType_t* colType _UNUSED, swl_coll_t* inCollection) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    swl_tta_cleanup(elementType, inCollection, ttaType->maxNrElements);
}

/**
 * If empty is allowed, size will return the number of non empty elements.
 */
static size_t s_col_size_cb(swl_collType_t* colType _UNUSED, swl_coll_t* inCollection) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    if(ttaType->allowEmpty) {
        return swl_type_arrayNotEmpty(ttaType->type.elementType, inCollection, ttaType->maxNrElements);
    } else {
        return swl_type_arraySize(ttaType->type.elementType, inCollection, ttaType->maxNrElements);
    }
}

/**
 * Adding to a full tta will result in last element being dropped and overwritten.
 */
static ssize_t s_col_add_cb(swl_collType_t* colType _UNUSED, swl_coll_t* inCollection, swl_typeData_t* data) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    ssize_t addIndex = -1;
    if(ttaType->allowEmpty) {
        addIndex = swl_type_getFirstEmpty(ttaType->type.elementType, inCollection, ttaType->maxNrElements);
    } else {
        addIndex = swl_type_arraySize(ttaType->type.elementType, inCollection, ttaType->maxNrElements);
    }
    if((addIndex < 0) || ((size_t) addIndex >= ttaType->maxNrElements)) {
        return -1;
    }

    swl_type_arrayPrepend(ttaType->type.elementType, inCollection, ttaType->maxNrElements, data, addIndex);
    return addIndex;
}

static swl_typeEl_t* s_col_alloc_cb(swl_collType_t* colType _UNUSED, swl_coll_t* inCollection) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    ssize_t addIndex = -1;
    if(ttaType->allowEmpty) {
        addIndex = swl_type_getFirstEmpty(ttaType->type.elementType, inCollection, ttaType->maxNrElements);
    } else {
        addIndex = swl_type_arraySize(ttaType->type.elementType, inCollection, ttaType->maxNrElements);
    }
    if((addIndex < 0) || ((size_t) addIndex >= ttaType->maxNrElements)) {
        return NULL;
    }
    return inCollection + addIndex * ttaType->type.elementType->size;
}

static swl_rc_ne s_col_insert_cb(swl_collType_t* colType _UNUSED, swl_coll_t* inCollection, swl_typeData_t* data, ssize_t index) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    if(ttaType->allowEmpty) {
        return swl_type_arrayPrepend(ttaType->type.elementType, inCollection, ttaType->maxNrElements, data, index);
    } else {
        size_t curSize = s_col_size_cb(colType, inCollection);
        size_t targetSize = SWL_MIN(curSize + 1, ttaType->maxNrElements);
        size_t targetIndex = SWL_ARRAY_INDEX(index, targetSize);
        return swl_type_arrayPrepend(ttaType->type.elementType, inCollection, targetSize, data, targetIndex);
    }
}

static swl_rc_ne s_col_set_cb(swl_collType_t* colType _UNUSED, swl_coll_t* inCollection, swl_typeData_t* data, ssize_t index) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    if(ttaType->allowEmpty) {
        return swl_tta_setTuple(elementType, inCollection, ttaType->maxNrElements, index, data);
    } else {
        size_t curSize = s_col_size_cb(colType, inCollection);
        return swl_tta_setTuple(elementType, inCollection, curSize, index, data);
    }
}

/**
 * For array type, delete shall always try to remove a non-empty element. Other elements do not count
 * for an array that has a fixed maxSize.
 */
static swl_rc_ne s_col_delete_cb(swl_collType_t* colType _UNUSED, swl_coll_t* inCollection, ssize_t index) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    size_t size = s_col_size_cb(colType, inCollection);
    if(size == 0) {
        return SWL_RC_NOT_AVAILABLE;
    }
    size_t targetIndex = SWL_ARRAY_INDEX(index, size);

    swl_typeEl_t* target = inCollection + targetIndex * ttaType->type.elementType->size;
    swl_type_cleanup(ttaType->type.elementType, target);
    swl_type_arrayShift(ttaType->type.elementType, target, ttaType->maxNrElements - targetIndex, -1);
    return SWL_RC_OK;
}

static ssize_t s_col_find_cb(swl_collType_t* colType _UNUSED, swl_coll_t* inCollection, swl_typeData_t* data) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    return swl_type_arrayFind(ttaType->type.elementType, inCollection, ttaType->maxNrElements, data);
}

static bool s_col_equals_cb(swl_collType_t* colType _UNUSED, swl_coll_t* inCollection1, swl_coll_t* inCollection2) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    return swl_tta_equals(elementType, inCollection1, ttaType->maxNrElements, inCollection2, ttaType->maxNrElements);
}

static swl_typeData_t* s_col_getValue_cb(swl_collType_t* colType _UNUSED, swl_coll_t* inCollection, ssize_t index) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    if(ttaType->allowEmpty) {
        return swl_tta_getTuple(elementType, inCollection, ttaType->maxNrElements, index);
    } else {
        size_t curSize = s_col_size_cb(colType, inCollection);
        return swl_tta_getTuple(elementType, inCollection, curSize, index);
    }
}

static swl_typeEl_t* s_col_getReference_cb(swl_collType_t* colType _UNUSED, swl_coll_t* inCollection, ssize_t index) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    if(ttaType->allowEmpty) {
        return swl_tta_getTuple(elementType, inCollection, ttaType->maxNrElements, index);
    } else {
        size_t curSize = s_col_size_cb(colType, inCollection);
        return swl_tta_getTuple(elementType, inCollection, curSize, index);
    }
}

static inline void s_col_setItData(swl_ttaType_t* at, swl_collIt_t* it) {
    if(it->index < at->maxNrElements) {
        it->data = it->coll + it->index * at->type.elementType->size;
        if(at->allowEmpty) {
            it->valid = true;
        } else {
            swl_typeData_t* td = SWL_TYPE_EL_TO_DATA(at->type.elementType, it->data);
            it->valid = !swl_type_isEmpty(at->type.elementType, td);
        }
    } else {
        it->valid = false;
    }
}

static swl_collIt_t s_col_getFirstIt_cb(swl_collType_t* colType _UNUSED, const swl_coll_t* inCollection) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    swl_collIt_t data;
    memset(&data, 0, sizeof(swl_collIt_t));
    data.coll = (swl_coll_t*) inCollection;
    data.typeFun = &swl_ttaCollType_fun;
    data.index = 0;
    data.dataType = colType->elementType;
    s_col_setItData(ttaType, &data);
    return data;
}
static void s_col_nextIt_cb(swl_collType_t* colType _UNUSED, swl_collIt_t* it) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    if(it->valid || ttaType->allowEmpty) {
        it->index++;
    }
    s_col_setItData(ttaType, it);
}

static void s_col_delIt_cb(swl_collType_t* colType _UNUSED, swl_collIt_t* it) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) colType;
    if(it->valid) {
        if(ttaType->allowEmpty) {
            swl_typeEl_t* target = it->coll + it->index * ttaType->type.elementType->size;
            swl_type_cleanup(ttaType->type.elementType, target);
        } else {
            s_col_delete_cb(colType, it->coll, it->index);
        }
        it->valid = false;
    }
}

swl_collTypeFun_t swl_ttaCollType_fun = {
    .name = "swl_tupleTypeArray",
    .init = s_col_init_cb,
    .initFromArray = s_col_initFromArray_cb,
    .clear = s_col_clear_cb,
    .cleanup = s_col_cleanup_cb,
    .maxSize = s_col_maxSize_cb,
    .size = s_col_size_cb,
    .add = s_col_add_cb,
    .alloc = s_col_alloc_cb,
    .insert = s_col_insert_cb,
    .set = s_col_set_cb,
    .delete = s_col_delete_cb,
    .find = s_col_find_cb,
    .equals = s_col_equals_cb,
    .getValue = s_col_getValue_cb,
    .getReference = s_col_getReference_cb,
    .firstIt = s_col_getFirstIt_cb,
    .nextIt = s_col_nextIt_cb,
    .delIt = s_col_delIt_cb,
};

static swl_typeData_t* s_getElementValue_cb(swl_ttCollType_t* type, swl_tuple_t* array,
                                            ssize_t tupleIndex, size_t typeIndex) {
    ASSERT_NOT_NULL(type, NULL, ME, "NULL");
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    return swl_tta_getElementValue(elementType, array, ttaType->maxNrElements, tupleIndex, typeIndex);
}

static swl_typeEl_t* s_getElementRef_cb(swl_ttCollType_t* type _UNUSED, swl_tuple_t* array _UNUSED,
                                        ssize_t tupleIndex _UNUSED, size_t typeIndex _UNUSED) {
    ASSERT_NOT_NULL(type, NULL, ME, "NULL");

    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    return swl_tta_getElementReference(elementType, array, ttaType->maxNrElements, tupleIndex, typeIndex);
}

static swl_rc_ne s_setElementValue_cb(swl_ttCollType_t* type, swl_tuple_t* array,
                                      ssize_t tupleIndex, size_t typeIndex, const swl_typeData_t* data) {
    ASSERT_NOT_NULL(type, SWL_RC_INVALID_PARAM, ME, "NULL");
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    return swl_tta_setElementValue(elementType, array, ttaType->maxNrElements, tupleIndex, typeIndex, data);
}


static swl_rc_ne s_columnToArrayOffset(swl_ttCollType_t* type, swl_typeEl_t* tgtArray, size_t tgtArraySize,
                                       const swl_typeEl_t* srcArray, size_t typeIndex, size_t offSet) {

    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;
    return swl_tta_columnToArrayOffset(elementType, tgtArray, tgtArraySize, srcArray, ttaType->maxNrElements, typeIndex, offSet);
}

static swl_rc_ne s_columnToArray(swl_ttCollType_t* type, swl_typeEl_t* tgtArray, size_t tgtArraySize,
                                 const swl_typeEl_t* srcArray, size_t typeIndex) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;
    return swl_tta_columnToArray(elementType, tgtArray, tgtArraySize, srcArray, ttaType->maxNrElements, typeIndex);
}

static ssize_t s_findMatchingTupleIndex(swl_ttCollType_t* type, swl_ttColl_t* array,
                                        ssize_t offset, size_t srcTypeIndex, const swl_typeData_t* srcData) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;
    return swl_tta_findMatchingTupleIndex(elementType, array, ttaType->maxNrElements, offset, srcTypeIndex, srcData);
}

static swl_tuple_t* s_getMatchingTuple(swl_ttCollType_t* type, swl_ttColl_t* array,
                                       ssize_t offset, size_t srcTypeIndex, const swl_typeData_t* srcData) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;
    return swl_tta_getMatchingTuple(elementType, array, ttaType->maxNrElements, offset, srcTypeIndex, srcData);
}

static swl_typeData_t* s_getMatchingElement(swl_ttCollType_t* type, swl_ttColl_t* array,
                                            ssize_t offset, size_t tgtTypeIndex, size_t srcTypeIndex, const swl_typeData_t* srcData) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;
    return swl_tta_getMatchingElement(elementType, array, ttaType->maxNrElements, offset, tgtTypeIndex, srcTypeIndex, srcData);
}


static ssize_t s_findMatchingTupleIndexByMask(swl_ttCollType_t* type, swl_ttColl_t* array,
                                              ssize_t offset, const swl_tuple_t* srcData, swl_mask_m mask) {

    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;
    return swl_tta_findMatchingTupleIndexByMask(elementType, array, ttaType->maxNrElements, offset,
                                                srcData, mask);
}
static swl_tuple_t* s_getMatchingTupleByMask(swl_ttCollType_t* type, swl_ttColl_t* array,
                                             ssize_t offset, const swl_tuple_t* srcData, swl_mask_m mask) {

    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    return swl_tta_getMatchingTupleByMask(elementType, array, ttaType->maxNrElements, offset,
                                          srcData, mask);
}

static swl_typeData_t* s_getMatchingElementByMask(swl_ttCollType_t* type, swl_ttColl_t* array,
                                                  ssize_t offset, size_t tgtTypeIndex, const swl_tuple_t* srcData, swl_mask_m mask) {

    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    return swl_tta_getMatchingElementByMask(elementType, array, ttaType->maxNrElements, offset,
                                            tgtTypeIndex, srcData, mask);
}

static bool s_fPrintLists(swl_ttCollType_t* type, FILE* stream, swl_ttColl_t* array, ssize_t offset, swl_print_args_t* args) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    return swl_tta_fprintLists(elementType, stream, array, ttaType->maxNrElements,
                               offset, ttaType->allowEmpty, args);

    return false;
}

static bool s_fPrintMaps(swl_ttCollType_t* type, FILE* stream, swl_ttColl_t* array, ssize_t offset,
                         swl_print_args_t* args, char** names, char* suffix) {
    swl_ttaType_t* ttaType = (swl_ttaType_t*) type;
    swl_tupleType_t* elementType = (swl_tupleType_t*) ttaType->type.elementType;

    return swl_tta_fprintMaps(elementType, stream, array, ttaType->maxNrElements,
                              offset, ttaType->allowEmpty, args, names, suffix);
    return false;
}


swl_ttCollTypeFun_t swl_ttaTtCollType_fun = {
    .collTypeFun = &swl_ttaCollType_fun,
    .getElementValue = s_getElementValue_cb,
    .getElementRef = s_getElementRef_cb,
    .setElementValue = s_setElementValue_cb,
    .columnToArrayOffset = s_columnToArrayOffset,
    .columnToArray = s_columnToArray,
    .findMatchingTupleIndex = s_findMatchingTupleIndex,
    .getMatchingTuple = s_getMatchingTuple,
    .getMatchingElement = s_getMatchingElement,
    .findMatchingTupleIndexByMask = s_findMatchingTupleIndexByMask,
    .getMatchingTupleByMask = s_getMatchingTupleByMask,
    .getMatchingElementByMask = s_getMatchingElementByMask,
    .fPrintLists = s_fPrintLists,
    .fPrintMaps = s_fPrintMaps,
};



static swl_typeExtIt_t ttaExtIt = {
    .id = SWL_TYPE_COL_FUN_UID,
    .extFun = &swl_ttaCollType_fun,
};

SWL_CONSTRUCTOR static void s_initListExt(void) {
    swl_llist_append(&swl_ttaType_fun.extensions, &ttaExtIt.it);
}
