/****************************************************************************
**
** Copyright (C) 2020 SoftAtHome. All rights reserved.
**
** SoftAtHome reserves all rights not expressly granted herein.
**
** - DISCLAIMER OF WARRANTY -
**
** THIS FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
** EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
** WARRANTIES OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
** PURPOSE.
**
** THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE SOURCE
** CODE IS WITH YOU. SHOULD THE SOURCE CODE PROVE DEFECTIVE, YOU
** ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
**
** - LIMITATION OF LIABILITY -
**
** IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
** WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES
** AND/OR DISTRIBUTES THE SOURCE CODE, BE LIABLE TO YOU FOR DAMAGES,
** INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
** ARISING OUT OF THE USE OR INABILITY TO USE THE SOURCE CODE
** (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
** INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE
** OF THE SOURCE CODE TO OPERATE WITH ANY OTHER PROGRAM), EVEN IF SUCH
** HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGES.
**
****************************************************************************/

#include <swl/swl_80211.h>
#include <swl/swl_staCap.h>
#include <swl/swl_common_table.h>

#define ME "swl802x"

SWL_TABLE_UINT32STR(s_frametype_str_List, ARR(
                        {SWL_80211_MGT_FRAME_TYPE_ASSOC_REQUEST, "AssocReq"},
                        {SWL_80211_MGT_FRAME_TYPE_ASSOC_RESPONSE, "AssocResp"},
                        {SWL_80211_MGT_FRAME_TYPE_REASSOC_REQUEST, "ReassocReq"},
                        {SWL_80211_MGT_FRAME_TYPE_REASSOC_RESPONSE, "ReassocResp"},
                        {SWL_80211_MGT_FRAME_TYPE_PROBE_REQUEST, "ProbeReq"},
                        {SWL_80211_MGT_FRAME_TYPE_PROBE_RESPONSE, "ProbeResp"},
                        {SWL_80211_MGT_FRAME_TYPE_BEACON, "Beacon"},
                        {SWL_80211_MGT_FRAME_TYPE_ATIM, "Atim"},
                        {SWL_80211_MGT_FRAME_TYPE_DISASSOCIATION, "Disassociation"},
                        {SWL_80211_MGT_FRAME_TYPE_AUTHENTICATION, "Authentication"},
                        {SWL_80211_MGT_FRAME_TYPE_DEAUTHENTICATION, "Deauthentication"},
                        {SWL_80211_MGT_FRAME_TYPE_ACTION, "Action"},
                        {SWL_80211_MGT_FRAME_TYPE_NOACKACTION, "Noackaction"},
                        )
                    );

/*
 * Sets an swl_80211_htCapIE_t structure from a ht byte frame
 */
void swl_80211_parseHtCap(swl_80211_htCapIE_t* htcap_ie, uint8_t* frm) {
    swl_80211_htCapIE_t* frame_ie = (swl_80211_htCapIE_t*) (frm + 2);
    ASSERTS_NOT_NULL(htcap_ie, , ME, "NULL");
    ASSERTS_NOT_NULL(frame_ie, , ME, "NULL");
    SAH_TRACEZ_INFO(ME, "Parsing HT Capabilities %p", frm);
    memset(htcap_ie, 0, sizeof(swl_80211_htCapIE_t));

    htcap_ie->htCapInfo = frame_ie->htCapInfo;
    htcap_ie->ampduParam = frame_ie->ampduParam;
    for(int i = 0; i < SWL_80211_MCS_SET_LEN; i++) {
        htcap_ie->supMCSSet[i] = frame_ie->supMCSSet[i];
    }
    htcap_ie->htExtCap = frame_ie->htExtCap;
    htcap_ie->txBfCap = frame_ie->txBfCap;
    htcap_ie->ASELCap = frame_ie->ASELCap;
    SAH_TRACEZ_INFO(ME, "Parsing HT Capabilities from %p to %p", frame_ie, &htcap_ie->htCapInfo);
}

/*
 * Sets an swl_80211_vhtCapIE_t structure from a vht byte frame
 */
void swl_80211_parseVhtCap(swl_80211_vhtCapIE_t* vhtCapIE, uint8_t* frm) {
    SAH_TRACEZ_INFO(ME, "swl_80211_parseVhtCap");
    ASSERT_NOT_NULL(vhtCapIE, , ME, "NULL");
    ASSERT_NOT_NULL(frm, , ME, "NULL");
    memset(vhtCapIE, 0, sizeof(swl_80211_vhtCapIE_t));

    vhtCapIE->vhtCapInfo = *(swl_80211_vhtCapInfo_m*) (frm + 2);
    vhtCapIE->rxMcsMap = *(uint16_t*) (frm + SWL_80211_VHT_MCS_OFFSET);
    vhtCapIE->rxRateMap = ((*((uint16_t*) (frm + SWL_80211_VHT_MCS_OFFSET + 2))) >> 3);
    vhtCapIE->txMcsMap = *(uint16_t*) (frm + SWL_80211_VHT_MCS_OFFSET + 4);
    vhtCapIE->txRateMap = ((*((uint16_t*) (frm + SWL_80211_VHT_MCS_OFFSET + 6))) >> 3);
}


/*
 * Sets an swl_80211_heCapIE_t structure from a he byte frame
 */
void swl_80211_parseHeCap(swl_80211_heCapIE_t* heCapIEDest, uint8_t* frm) {
    SAH_TRACEZ_INFO(ME, "Parsing HE Capabilities %p", heCapIEDest);
    ASSERT_NOT_NULL(heCapIEDest, , ME, "NULL");
    ASSERT_NOT_NULL(frm, , ME, "NULL");

    swl_80211_heCapIE_t* frameStruct = NULL;
    frameStruct = (swl_80211_heCapIE_t*) frm;
    ASSERT_NOT_NULL(frameStruct, , ME, "NULL");
    memset(heCapIEDest, 0, sizeof(swl_80211_heCapIE_t));

    heCapIEDest->heCaps = frm[0];
    heCapIEDest->macCap = frameStruct->macCap;
    heCapIEDest->phyCap = frameStruct->phyCap;

    if(SWL_BIT_IS_SET(heCapIEDest->phyCap.cap[0], 2)) {
        heCapIEDest->mcsCaps[0] = frameStruct->mcsCaps[SWL_80211_HECAP_MCS_LT80_ELM];
    }
    if(SWL_BIT_IS_SET(heCapIEDest->phyCap.cap[0], 3)) {
        heCapIEDest->mcsCaps[1] = frameStruct->mcsCaps[SWL_80211_HECAP_MCS_160_ELM];
    }
    if(SWL_BIT_IS_SET(heCapIEDest->phyCap.cap[0], 4)) {
        heCapIEDest->mcsCaps[2] = frameStruct->mcsCaps[SWL_80211_HECAP_MCS_80P80_ELM];
    }
}

const char* swl_80211_mgtFrameTypeToChar(swl_80211_mgtFrameType_ne type) {
    return swl_tableUInt32Char_toValue(&s_frametype_str_List, type);
}
