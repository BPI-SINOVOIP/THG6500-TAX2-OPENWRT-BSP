/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "swl/swl_common.h"
#include "swl/swl_crypto.h"

#define ME "swlCryp"

#define PADDING RSA_PKCS1_PADDING

X509* swl_crypto_getCertFromFilePath(const char* certPath) {
    BIO* inBio = NULL;
    X509* cert = NULL;

    inBio = BIO_new(BIO_s_file());
    if(inBio == NULL) {
        SAH_TRACEZ_INFO(ME, "Could not create BIO");
        goto end;
    }

    if(BIO_read_filename(inBio, certPath) <= 0) {
        SAH_TRACEZ_INFO(ME, "Could not read certificate file: %s", certPath);
        goto end;
    }

    cert = PEM_read_bio_X509_AUX(inBio, NULL, NULL, NULL);
    if(cert == NULL) {
        SAH_TRACEZ_INFO(ME, "Could not read X509 certificate from file: %s", certPath);
        goto end;
    }

end:
    if(inBio != NULL) {
        BIO_free(inBio);
    }
    return cert;
}

EVP_PKEY* swl_crypto_getKeyFromFilePath(const char* privKeyPath) {
    BIO* inBio;
    EVP_PKEY* pkey = NULL;

    inBio = BIO_new(BIO_s_file());
    if(inBio == NULL) {
        SAH_TRACEZ_INFO(ME, "Could not create BIO");
        goto end;
    }

    if(BIO_read_filename(inBio, privKeyPath) <= 0) {
        SAH_TRACEZ_INFO(ME, "Could not read private key file: %s", privKeyPath);
        goto end;
    }
    pkey = PEM_read_bio_PrivateKey(inBio, NULL, NULL, NULL);
    if(pkey == NULL) {
        SAH_TRACEZ_INFO(ME, "Could not interpret private key file: %s", privKeyPath);
    }
end:
    if(inBio != NULL) {
        BIO_free(inBio);
    }
    return pkey;
}

static swl_rc_ne s_publicEncodeWithCert(const unsigned char* input, unsigned char* output, int length,
                                        X509* cert, int* dataSize) {
    int rsaResult = 0;
    RSA* rsaPubkey = swl_crypto_getRsaFromCert(cert);
    if(rsaPubkey == NULL) {
        SAH_TRACEZ_INFO(ME, "Could not get RSA key from public key");
        return SWL_RC_ERROR;
    }

    rsaResult = RSA_public_encrypt(length, input, output, rsaPubkey, PADDING);
    if(rsaResult < 0) {
        SAH_TRACEZ_INFO(ME, "Openssl error during public encoding: %d", rsaResult);
        return SWL_RC_ERROR;
    }
    *dataSize = rsaResult;

    return SWL_RC_OK;
}

static swl_rc_ne s_privateDecodeWithEVP(const unsigned char* input, unsigned char* output, int length,
                                        EVP_PKEY* privkey) {
    int rsaResult = 0;
    RSA* rsaPrivkey = NULL;

    rsaPrivkey = SWL_CRYPTO_EVP_PKEY_GET_RSA(privkey);
    if(rsaPrivkey == NULL) {
        SAH_TRACEZ_ERROR(ME, "Could not get RSA key from private key");
        return SWL_RC_ERROR;
    }

    rsaResult = RSA_private_decrypt(length, input, output, rsaPrivkey, PADDING);
    if(rsaResult < 0) {
        SAH_TRACEZ_ERROR(ME, "Openssl error during private decoding: %d %s", rsaResult, ERR_error_string(ERR_get_error(), NULL));
        return SWL_RC_ERROR;
    }

    return SWL_RC_OK;
}

/**
 * Decode data using a private key path.
 */
swl_rc_ne swl_crypto_decodeDataWithKeyPath(const char* privKeyPath, const unsigned char* srcData, int dataSize, unsigned char* dataUnciphered) {
    EVP_PKEY* privKey = swl_crypto_getKeyFromFilePath(privKeyPath);
    ASSERTS_NOT_NULL(privKey, SWL_RC_ERROR, ME, "NULL");

    swl_rc_ne ret = s_privateDecodeWithEVP(srcData, dataUnciphered, dataSize, privKey);

    EVP_PKEY_free(privKey);
    return ret;
}

/**
 * Decode data using a private key.
 */
swl_rc_ne swl_crypto_decodeDataWithKey(EVP_PKEY* privKey, const unsigned char* srcData, int dataSize, unsigned char* dataUnciphered) {
    ASSERTS_NOT_NULL(privKey, SWL_RC_ERROR, ME, "NULL");
    return s_privateDecodeWithEVP(srcData, dataUnciphered, dataSize, privKey);
}

/**
 * Encode data using a certificate path.
 */
swl_rc_ne swl_crypto_encodeDataWithCertPath(const char* certPath, const unsigned char* srcData, unsigned char* dataCiphered, int* dataSize) {
    X509* cert = swl_crypto_getCertFromFilePath(certPath);
    ASSERTS_NOT_NULL(cert, SWL_RC_ERROR, ME, "NULL");

    swl_rc_ne ret = s_publicEncodeWithCert(srcData, dataCiphered, strlen((char*) srcData) + 1, cert, dataSize);

    X509_free(cert);
    return ret;
}

/**
 * Encode data using a certificate.
 */
swl_rc_ne swl_crypto_encodeDataWithCert(X509* cert, const unsigned char* srcData, unsigned char* dataCiphered, int* dataSize) {
    ASSERTS_NOT_NULL(cert, SWL_RC_ERROR, ME, "NULL");
    return s_publicEncodeWithCert(srcData, dataCiphered, strlen((char*) srcData) + 1, cert, dataSize);
}

/**
 * Get public RSA key algorithm from certificate.
 */
RSA* swl_crypto_getRsaFromCert(X509* cert) {
    ASSERTS_NOT_NULL(cert, NULL, ME, "NULL");
    EVP_PKEY* pubKey = SWL_CRYPTO_X509_GET_PUBKEY(cert);
    ASSERTS_NOT_NULL(pubKey, NULL, ME, "NULL");
    return SWL_CRYPTO_EVP_PKEY_GET_RSA(pubKey);
}

/**
 * Return if cert is valid based on the CA certificate file provided.
 */
bool ssw_crypto_isCertificateValid(X509* cert, const char* rootCAPath) {
    ASSERTS_NOT_NULL(cert, false, ME, "NULL");
    ASSERTS_NOT_NULL(rootCAPath, false, ME, "NULL");
    SWL_CRYPTO_INIT_OPENSSL();
    X509_STORE* store = X509_STORE_new();
    X509_STORE_CTX* ctx = X509_STORE_CTX_new();
    X509_STORE_load_locations(store, rootCAPath, NULL);
    X509_STORE_CTX_init(ctx, store, cert, NULL);
    int ret = X509_verify_cert(ctx);
    X509_STORE_CTX_free(ctx);
    X509_STORE_free(store);
    return (ret == 1);
}
