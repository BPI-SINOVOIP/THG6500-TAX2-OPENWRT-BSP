/****************************************************************************
**
** Copyright (C) 2020 SoftAtHome. All rights reserved.
**
** SoftAtHome reserves all rights not expressly granted herein.
**
** - DISCLAIMER OF WARRANTY -
**
** THIS FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
** EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
** WARRANTIES OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
** PURPOSE.
**
** THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE SOURCE
** CODE IS WITH YOU. SHOULD THE SOURCE CODE PROVE DEFECTIVE, YOU
** ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
**
** - LIMITATION OF LIABILITY -
**
** IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
** WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES
** AND/OR DISTRIBUTES THE SOURCE CODE, BE LIABLE TO YOU FOR DAMAGES,
** INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
** ARISING OUT OF THE USE OR INABILITY TO USE THE SOURCE CODE
** (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
** INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE
** OF THE SOURCE CODE TO OPERATE WITH ANY OTHER PROGRAM), EVEN IF SUCH
** HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGES.
**
****************************************************************************/

#include "swl/swl_genericFrameParser.h"
#include "swl/swl_common_table.h"
#include "swl/swl_common_mcs.h"
#include "swl/swl_hex.h"

#define ME "swlParser"

static void s_parseWEP40(swl_80211_cipher_m* cipherSuiteParams) {
    ASSERTS_NOT_NULL(cipherSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "M_SWL_80211_WEP_40");
    *cipherSuiteParams |= M_SWL_80211_CIPHER_WEP40;
}

static void s_parseTKIP(swl_80211_cipher_m* cipherSuiteParams) {
    ASSERTS_NOT_NULL(cipherSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "M_SWL_80211_TKIP");
    *cipherSuiteParams |= M_SWL_80211_CIPHER_TKIP;
}

static void s_parsCCMP128(swl_80211_cipher_m* cipherSuiteParams) {
    ASSERTS_NOT_NULL(cipherSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "M_SWL_80211_CCMP_128");
    *cipherSuiteParams |= M_SWL_80211_CIPHER_CCMP;
}

static void s_parseWEP104(swl_80211_cipher_m* cipherSuiteParams) {
    ASSERTS_NOT_NULL(cipherSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_WEP_104");
    *cipherSuiteParams |= M_SWL_80211_CIPHER_WEP104;
}

static void s_parseCMAC128(swl_80211_cipher_m* cipherSuiteParams) {
    ASSERTS_NOT_NULL(cipherSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_BIP_CMAC_128");
    *cipherSuiteParams |= M_SWL_80211_CIPHER_BIP_CMAC;
}

static void s_parseGCMP128(swl_80211_cipher_m* cipherSuiteParams) {
    ASSERTS_NOT_NULL(cipherSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_GCMP_128");
    *cipherSuiteParams |= M_SWL_80211_CIPHER_GCMP;
}

static void s_parseGCMP256(swl_80211_cipher_m* cipherSuiteParams) {
    ASSERTS_NOT_NULL(cipherSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_GCMP_256");
    *cipherSuiteParams |= M_SWL_80211_CIPHER_GCMP256;
}

static void s_parseCCMP256(swl_80211_cipher_m* cipherSuiteParams) {
    ASSERTS_NOT_NULL(cipherSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_CCMP_256");
    *cipherSuiteParams |= M_SWL_80211_CIPHER_CCMP256;
}

static void s_parseGMAC128(swl_80211_cipher_m* cipherSuiteParams) {
    ASSERTS_NOT_NULL(cipherSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_CIPHER_BIP_GMAC_128");
    *cipherSuiteParams |= M_SWL_80211_CIPHER_BIP_GMAC;
}

static void s_parseGMAC256(swl_80211_cipher_m* cipherSuiteParams) {
    ASSERTS_NOT_NULL(cipherSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_BIP_GMAC_256");
    *cipherSuiteParams |= M_SWL_80211_CIPHER_BIP_GMAC256;
}

static void s_parseCMAC256(swl_80211_cipher_m* cipherSuiteParams) {
    ASSERTS_NOT_NULL(cipherSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_BIP_CMAC_256");
    *cipherSuiteParams |= M_SWL_80211_CIPHER_BIP_CMAC256;
}

SWL_TABLE(dataCipherSuiteTable,
          ARR(uint8_t index; void* val; ),
          ARR(swl_type_uint8, swl_type_voidPtr),
          ARR({SWL_80211_CIPHER_SUITE_WEP_40, (void*) s_parseWEP40},
              {SWL_80211_CIPHER_SUITE_TKIP, (void*) s_parseTKIP},
              {SWL_80211_CIPHER_SUITE_CCMP_128, (void*) s_parsCCMP128},
              {SWL_80211_CIPHER_SUITE_WEP_104, (void*) s_parseWEP104},
              {SWL_80211_CIPHER_SUITE_BIP_CMAC_128, (void*) s_parseCMAC128},
              {SWL_80211_CIPHER_SUITE_GCMP_128, (void*) s_parseGCMP128},
              {SWL_80211_CIPHER_SUITE_GCMP_256, (void*) s_parseGCMP256},
              {SWL_80211_CIPHER_SUITE_CCMP_256, (void*) s_parseCCMP256},
              {SWL_80211_CIPHER_SUITE_BIP_GMAC_128, (void*) s_parseGMAC128},
              {SWL_80211_CIPHER_SUITE_BIP_GMAC_256, (void*) s_parseGMAC256},
              {SWL_80211_CIPHER_SUITE_BIP_CMAC_256, (void*) s_parseCMAC256}, )
          );
typedef void (* cipherParseFun_f) (swl_80211_cipher_m* cipherSuiteParams);


swl_rc_ne swl_80211_getDataCipherSuite(uint8_t type, swl_80211_cipher_m* cipherSuiteParams) {
    ASSERT_NOT_NULL(cipherSuiteParams, SWL_RC_INVALID_PARAM, ME, "NULL");

    void** func = (void**) swl_table_getMatchingValue(&dataCipherSuiteTable, 1, 0, (swl_80211_elId_ne*) &type);
    if(func != NULL) {
        cipherParseFun_f parseFunc = (cipherParseFun_f) (*func);
        parseFunc(cipherSuiteParams);
    } else {
        SAH_TRACEZ_INFO(ME, "Unsupported data cipher type %d", type);
    }

    return SWL_RC_OK;
}

static void s_parseIEEE_802_1X(swl_80211_akm_m* akmSuiteParams) {
    ASSERTS_NOT_NULL(akmSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_IEEE_802_1X");
    *akmSuiteParams |= M_SWL_80211_AKM_IEEE_802_1X;
}

static void s_parsePSK(swl_80211_akm_m* akmSuiteParams) {
    ASSERTS_NOT_NULL(akmSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_PSK");
    *akmSuiteParams |= M_SWL_80211_AKM_PSK;
}

static void s_parseFT_IEEE_802_1X(swl_80211_akm_m* akmSuiteParams) {
    ASSERTS_NOT_NULL(akmSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_FT_IEEE_802_1X");
    *akmSuiteParams |= M_SWL_80211_AKM_FT_IEEE_802_1X;
}

static void s_parseFT_PSK(swl_80211_akm_m* akmSuiteParams) {
    ASSERTS_NOT_NULL(akmSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_FT_PSK");
    *akmSuiteParams |= M_SWL_80211_AKM_FT_PSK;
}

static void s_parseIEEE_802_1X_SHA_256(swl_80211_akm_m* akmSuiteParams) {
    ASSERTS_NOT_NULL(akmSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_IEEE_802_1X_SHA_256");
    *akmSuiteParams |= M_SWL_80211_AKM_IEEE_802_1X_SHA_256;
}

static void s_parsePSK_SHA_256(swl_80211_akm_m* akmSuiteParams) {
    ASSERTS_NOT_NULL(akmSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_PSK_SHA_256");
    *akmSuiteParams |= M_SWL_80211_AKM_PSK_SHA_256;
}

static void s_parseTDLS_TPK(swl_80211_akm_m* akmSuiteParams) {
    ASSERTS_NOT_NULL(akmSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_TDLS_TPK");
    *akmSuiteParams |= M_SWL_80211_AKM_TDLS_TPK;
}

static void s_parseSAE(swl_80211_akm_m* akmSuiteParams) {
    ASSERTS_NOT_NULL(akmSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_SAE");
    *akmSuiteParams |= M_SWL_80211_AKM_SAE;
}

static void s_parseFT_SAE(swl_80211_akm_m* akmSuiteParams) {
    ASSERTS_NOT_NULL(akmSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_FT_SAE");
    *akmSuiteParams |= M_SWL_80211_AKM_FT_SAE;
}

static void s_parseAES_256(swl_80211_akm_m* akmSuiteParams) {
    ASSERTS_NOT_NULL(akmSuiteParams, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_AES_256");
    *akmSuiteParams |= M_SWL_80211_AKM_AES_256;
}

SWL_TABLE(dataAKMsuite,
          ARR(uint8_t index; void* val; ),
          ARR(swl_type_uint8, swl_type_voidPtr),
          ARR({SWL_80211_AKM_SUITES_IEEE_802_1X, (void*) s_parseIEEE_802_1X},
              {SWL_80211_AKM_SUITES_PSK, (void*) s_parsePSK},
              {SWL_80211_AKM_SUITES_FT_IEEE_802_1X, (void*) s_parseFT_IEEE_802_1X},
              {SWL_80211_AKM_SUITES_FT_PSK, (void*) s_parseFT_PSK},
              {SWL_80211_AKM_SUITES_IEEE_802_1X_SHA_256, (void*) s_parseIEEE_802_1X_SHA_256},
              {SWL_80211_AKM_SUITES_PSK_SHA_256, (void*) s_parsePSK_SHA_256},
              {SWL_80211_AKM_SUITES_TDLS_TPK, (void*) s_parseTDLS_TPK},
              {SWL_80211_AKM_SUITES_SAE, (void*) s_parseSAE},
              {SWL_80211_AKM_SUITES_FT_SAE, (void*) s_parseFT_SAE},
              {SWL_80211_AKM_SUITES_AES_256, (void*) s_parseAES_256}, )
          );
typedef void (* akmParseFun_f) (swl_80211_akm_m* akmSuiteParams);


swl_rc_ne swl_80211_getDataAKMsuite(uint8_t type, swl_80211_akm_m* akmSuiteParams) {
    ASSERT_NOT_NULL(akmSuiteParams, SWL_RC_INVALID_PARAM, ME, "NULL");

    void** func = (void**) swl_table_getMatchingValue(&dataAKMsuite, 1, 0, (swl_80211_elId_ne*) &type);
    if(func != NULL) {
        akmParseFun_f parseFunc = (akmParseFun_f) (*func);
        parseFunc(akmSuiteParams);
    } else {
        SAH_TRACEZ_INFO(ME, "Unsupported akm type %d", type);
    }

    return SWL_RC_OK;
}


static void s_parseHtCap(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len _UNUSED, uint8_t* frm) {
    swl_80211_htCapIE_t* htCap = (swl_80211_htCapIE_t*) (frm);
    ASSERTS_NOT_NULL(htCap, , ME, "NULL");
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");
    if(htCap->htCapInfo & M_SWL_80211_HTCAPINFO_CAP_40) {
        pWirelessDevIE->htCapabilities |= M_SWL_STACAP_HT_40MHZ;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_HT_40MHZ cap");
    }
    if(htCap->htCapInfo & M_SWL_80211_HTCAPINFO_SGI_20) {
        pWirelessDevIE->htCapabilities |= M_SWL_STACAP_HT_SGI20;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_HT_SGI20 cap");
    }
    if(htCap->htCapInfo & M_SWL_80211_HTCAPINFO_SGI_40) {
        pWirelessDevIE->htCapabilities |= M_SWL_STACAP_HT_SGI40;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_HT_SGI40 cap");
    }
    if(htCap->htCapInfo & M_SWL_80211_HTCAPINFO_INTOL_40) {
        pWirelessDevIE->htCapabilities |= M_SWL_STACAP_HT_40MHZ_INTOL;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_HT_40MHZ_INTOL cap");
    }
    SAH_TRACEZ_INFO(ME, "Parsing HT Capabilities from %02x to %x", htCap->htCapInfo, pWirelessDevIE->htCapabilities);
}


static void s_parseVhtCap(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len _UNUSED, uint8_t* frm) {
    swl_80211_vhtCapIE_t* vhtCap = (swl_80211_vhtCapIE_t*) (frm);
    ASSERTS_NOT_NULL(vhtCap, , ME, "NULL");
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");
    if(vhtCap->vhtCapInfo & M_SWL_80211_VHTCAPINFO_SGI_80) {
        pWirelessDevIE->vhtCapabilities |= M_SWL_STACAP_VHT_SGI80;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_VHT_SGI80 cap");
    }
    if(vhtCap->vhtCapInfo & M_SWL_80211_VHTCAPINFO_SGI_160) {
        pWirelessDevIE->vhtCapabilities |= M_SWL_STACAP_VHT_SGI160;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_VHT_SGI160 cap");
    }
    if(vhtCap->vhtCapInfo & M_SWL_80211_VHTCAPINFO_SU_BFR) {
        pWirelessDevIE->vhtCapabilities |= M_SWL_STACAP_VHT_SU_BFR;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_VHT_SU_BFR cap");
    }
    if(vhtCap->vhtCapInfo & M_SWL_80211_VHTCAPINFO_SU_BFE) {
        pWirelessDevIE->vhtCapabilities |= M_SWL_STACAP_VHT_SU_BFE;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_VHT_SU_BFE cap");
    }
    if(vhtCap->vhtCapInfo & M_SWL_80211_VHTCAPINFO_MU_BFR) {
        pWirelessDevIE->vhtCapabilities |= M_SWL_STACAP_VHT_MU_BFR;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_VHT_MU_BFR cap");
    }
    if(vhtCap->vhtCapInfo & M_SWL_80211_VHTCAPINFO_MU_BFE) {
        pWirelessDevIE->vhtCapabilities |= M_SWL_STACAP_VHT_MU_BFE;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_VHT_MU_BFE cap");
    }
    SAH_TRACEZ_INFO(ME, "Parsing VHT Capabilities from %04x to %x", vhtCap->vhtCapInfo, pWirelessDevIE->vhtCapabilities);
}

static void s_saveFreqBand(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_freqBandExt_e freqBandExt) {
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");
    ASSERTS_TRUE(swl_chanspec_isValidBandExt(freqBandExt), , ME, "Invalid");
    pWirelessDevIE->operChanInfo.band = freqBandExt;
    pWirelessDevIE->freqCapabilities |= SWL_BIT_SHIFT(freqBandExt);
    pWirelessDevIE->operatingStandards |= SWL_BIT_SHIFT(swl_mcs_radStdFromMcsStd(SWL_MCS_STANDARD_LEGACY, freqBandExt));
}

static void s_parseHtOp(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len _UNUSED, uint8_t* frm) {
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");
    pWirelessDevIE->operatingStandards |= M_SWL_RADSTD_N;
    swl_80211_htOpIE_t* htOp = (swl_80211_htOpIE_t*) frm;
    ASSERTS_NOT_NULL(htOp, , ME, "NULL");
    pWirelessDevIE->operChanInfo.channel = htOp->primChan;
    swl_freqBandExt_e freqBandExt = swl_chanspec_freqBandExtFromBaseChannel(pWirelessDevIE->operChanInfo.channel);
    s_saveFreqBand(pWirelessDevIE, freqBandExt);

    if((htOp->secChanOffset == SWL_80211_HT_OPER_SEC_CHAN_NONE) ||
       (htOp->staChanWidth == SWL_80211_HT_OPER_STA_CHAN_WIDTH_20_ONLY)) {
        pWirelessDevIE->operChanInfo.bandwidth = SWL_BW_20MHZ;
    } else if((htOp->staChanWidth == SWL_80211_HT_OPER_STA_CHAN_WIDTH_ANY) &&
              ((htOp->secChanOffset == SWL_80211_HT_OPER_SEC_CHAN_ABOVE) ||
               (htOp->secChanOffset == SWL_80211_HT_OPER_SEC_CHAN_BELOW))) {
        ASSERTS_EQUALS(pWirelessDevIE->operChanInfo.bandwidth, SWL_BW_AUTO, , ME, "bw already filled");
        pWirelessDevIE->operChanInfo.bandwidth = SWL_BW_40MHZ;
    }
}

static void s_parseVhtOp(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len _UNUSED, uint8_t* frm) {
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");
    pWirelessDevIE->operatingStandards |= M_SWL_RADSTD_AC;
    swl_80211_vhtOpIE_t* vhtOp = (swl_80211_vhtOpIE_t*) frm;
    ASSERTS_NOT_NULL(vhtOp, , ME, "NULL");
    if(vhtOp->chanWidth == SWL_80211_VHT_OPER_CHAN_WIDTH_20_40) {
        if(!vhtOp->chanCenterSeg0) {
            pWirelessDevIE->operChanInfo.bandwidth = SWL_BW_20MHZ;
        } else {
            pWirelessDevIE->operChanInfo.bandwidth = SWL_BW_40MHZ;
        }
    } else if(vhtOp->chanWidth == SWL_80211_VHT_OPER_CHAN_WIDTH_80_160_8080) {
        if(!vhtOp->chanCenterSeg1) {
            pWirelessDevIE->operChanInfo.bandwidth = SWL_BW_80MHZ;
        } else {
            pWirelessDevIE->operChanInfo.bandwidth = SWL_BW_160MHZ;
        }
    } else if(vhtOp->chanWidth == SWL_80211_VHT_OPER_CHAN_WIDTH_160) {
        pWirelessDevIE->operChanInfo.bandwidth = SWL_BW_160MHZ;
    }
}

static void s_parseExtHeOp(swl_wirelessDevice_infoElements_t* pWirelessDevIE _UNUSED, swl_80211_elIdExt_ne elIdExt _UNUSED, uint8_t len _UNUSED, uint8_t* frm) {
    swl_80211_heOpIE_t* heopcap = (swl_80211_heOpIE_t*) &frm[1];
    ASSERTS_NOT_NULL(heopcap, , ME, "NULL");
}

static void s_parseExtHeCap(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_80211_elIdExt_ne elIdExt _UNUSED, uint8_t len _UNUSED, uint8_t* frm) {
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");
    pWirelessDevIE->operatingStandards |= M_SWL_RADSTD_AX;
    ASSERTS_NOT_NULL(frm, , ME, "NULL");
    swl_80211_heCapIE_t hecap;
    swl_80211_parseHeCap(&hecap, frm);

    char phy_cap_hex[(SWL_80211_HECAP_PHY_CAP_INFO_SIZE * 2) + 1] = {'\0'};
    for(uint8_t i = 0; i < SWL_80211_HECAP_PHY_CAP_INFO_SIZE; i++) {
        swl_str_catFormat(phy_cap_hex, sizeof(phy_cap_hex), "%02x", hecap.phyCap.cap[i]);
    }
    if(hecap.phyCap.cap[3] & 0x80) {
        pWirelessDevIE->heCapabilities |= M_SWL_STACAP_HE_SU_BFR;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_HE_SU_BFR cap");
    }
    if(hecap.phyCap.cap[4] & 0x01) {
        pWirelessDevIE->heCapabilities |= M_SWL_STACAP_HE_SU_AND_MU_BFE;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_HE_SU_AND_MU_BFE cap");
    }
    if((hecap.phyCap.cap[4] & 0x02) >> 1) {
        pWirelessDevIE->heCapabilities |= M_SWL_STACAP_HE_MU_BFR;
        SAH_TRACEZ_INFO(ME, "Adding M_SWL_STACAP_HE_MU_BFR cap");
    }
    SAH_TRACEZ_INFO(ME, "Parsing HE Capabilities from %s to %x", phy_cap_hex, pWirelessDevIE->heCapabilities);
}


SWL_TABLE(ieParseExtTable,
          ARR(uint8_t index; void* val; ),
          ARR(swl_type_uint8, swl_type_voidPtr),
          ARR({SWL_80211_EL_IDEXT_HE_OP, (void*) s_parseExtHeOp},
              {SWL_80211_EL_IDEXT_HE_CAP, (void*) s_parseExtHeCap}, )
          );
typedef void (* elementParseExtFun_f) (swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_80211_elIdExt_ne elId, uint8_t len, swl_bit8_t* frm);


static void s_parseExt(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len, uint8_t* frm) {
    ASSERTS_NOT_NULL(frm, , ME, "NULL");
    ASSERT_TRUE(len != 0, , ME, "ZERO LEN");

    swl_80211_elIdExt_ne elIdExt = frm[0];


    void** func = (void**) swl_table_getMatchingValue(&ieParseExtTable, 1, 0, &elIdExt);
    if(func != NULL) {
        elementParseExtFun_f myFun = (elementParseExtFun_f) (*func);
        myFun(pWirelessDevIE, elIdExt, len, frm);
    } else {
        SAH_TRACEZ_INFO(ME, "Unsupported element id ext %d", elIdExt);
    }

}

static void s_parseExtCap(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len _UNUSED, uint8_t* frm) {
    ASSERTS_NOT_NULL(frm, , ME, "NULL");
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");
    SAH_TRACEZ_INFO(ME, "Parsing Extra Capabilities %p %d", frm, (int) frm[1]);
    if(frm[4] & 0x01) { // Just check if QoS MAP is set.
        pWirelessDevIE->capabilities |= M_SWL_STACAP_QOS_MAP;
    }
}

// TODO: see later how to modify
static void s_parseVendor(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len _UNUSED, uint8_t* frm) {
    swl_80211_vendorIdEl_t* vendor = (swl_80211_vendorIdEl_t*) frm;
    ASSERTS_NOT_NULL(vendor, , ME, "NULL");
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "Parse associated STA IEs");
    swl_oui_list_t* vendorOUI = &pWirelessDevIE->vendorOUI;
    ASSERTS_NOT_NULL(vendorOUI, , ME, "NULL");

    swl_oui_t newOui;
    memcpy(newOui.ouiBytes, vendor->oui, SWL_OUI_BYTE_LEN);
    if(swl_typeOui_arrayContains(vendorOUI->oui, vendorOUI->count, newOui)) {
        return;
    }

    ASSERTS_TRUE(vendorOUI->count < SWL_OUI_MAX_NUM, , ME, "Max number of OUI reached");

    memcpy(vendorOUI->oui[vendorOUI->count].ouiBytes, newOui.ouiBytes, SWL_OUI_BYTE_LEN);
    SAH_TRACEZ_INFO(ME, "Parsing Vendor ID=%d OUI=%s", elId, swl_typeOui_toBuf32(newOui).buf);
    vendorOUI->count++;

    // Extract security mode
    uint32_t oui = SWL_OUI_GET(frm);
    if((len >= 4) && (oui == SWL_OUI_MS)) {

        SAH_TRACEZ_INFO(ME, "Vendor specific: Microsoft WPS, OUI type = %x", frm[3]);
        // OUI Type == 4 (WPS Supported)
        if(frm[3] == 4) {
            /* code */

            // Shift data pointer by 4 bytes (OUI + Type)
            frm += 4;
            len -= 4;

            /* The following Data is code as multiple TLV with:
             * Type:   2 bytes
             * Length: 2 bytes
             * Value:  x bytes
             */
            while(len >= 4 && (uint16_t) len >= (frm[3] | (frm[2] << 8))) {
                uint16_t taglen = (uint16_t) (frm[3] | (frm[2] << 8));
                uint8_t* tagData = (uint8_t*) (frm + 4);

                /* The tag type is on two bytes
                 * they all respect this format: 0x10xx (with xx the changing byte)
                 * So we juste need to test the second byte value
                 */
                switch(frm[1]) {
                case 0x53: // Selected Registrar Config Methods
                    SAH_TRACEZ_INFO(ME, "Selected Registrar Config Methods: (%x)", (tagData[1] | (tagData[0] << 8)));
                    pWirelessDevIE->WPS_ConfigMethodsEnabled = (tagData[1] | (tagData[0] << 8));
                    break;

                default:
                    SAH_TRACEZ_INFO(ME, "Case not theated !");
                    break;
                }

                // Shift data pointer by 5 bytes
                frm += (taglen + 4);
                len -= (taglen + 4);
            }
        }
    } else if((len >= 4) && (oui == SWL_OUI_WFA)) {
        SAH_TRACEZ_INFO(ME, "WFA_OUI (not coded yet)");
    }
}


static void s_parseMobDom(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len _UNUSED, uint8_t* frm) {
    swl_80211_mobDomEl_t* mdie = (swl_80211_mobDomEl_t*) frm;
    ASSERTS_NOT_NULL(mdie, , ME, "NULL");
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");
    if((mdie->cap & SWL_80211_MOB_DOM_CAP_FBSS_TRANS_DS) == SWL_80211_MOB_DOM_CAP_FBSS_TRANS_DS) {
        pWirelessDevIE->capabilities |= M_SWL_STACAP_FBT;
    }
}

static void s_parseRegClass(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len, uint8_t* frm) {
    ASSERTS_NOT_NULL(frm, , ME, "NULL");
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");
    swl_freqBandExt_e freqBandExt;
    for(uint8_t i = 0; i < len; i++) {
        freqBandExt = swl_chanspec_operClassToFreq(frm[i]);
        if(freqBandExt == SWL_FREQ_BAND_EXT_NONE) {
            continue;
        }
        //0: current operating class
        //1..: alternate operating classes, including the current one
        pWirelessDevIE->uniiBandsCapabilities |= swl_chanspec_operClassToUniiMask(frm[i]);
        if(i == 0) {
            s_saveFreqBand(pWirelessDevIE, freqBandExt);
            pWirelessDevIE->operChanInfo.bandwidth = swl_chanspec_operClassToBandwidth(frm[i]);
            continue;
        }
        pWirelessDevIE->freqCapabilities |= SWL_BIT_SHIFT(freqBandExt);
    }
}

static void s_parseSupChan(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len, uint8_t* frm) {
    ASSERTS_NOT_NULL(frm, , ME, "NULL");
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");

    swl_chanspec_t chanspec = SWL_CHANSPEC_EMPTY;
    if(pWirelessDevIE->freqCapabilities) {
        chanspec.band = pWirelessDevIE->operChanInfo.band;
    }

    uint8_t nrTuples = len / 2;
    //start from last tuple (easier deduction of freq band)
    for(int i = (nrTuples - 1); i >= 0; i--) {
        //take channel byte and skip subBand id byte
        chanspec.channel = frm[i * 2];
        /*
         * (80211 sec 9.4.2.17 Supported Channels element)
         * The Supported Channels element is included in Association Request frame
         *
         * so assume current band on which pairing occurred
         * so try to deduce band from channel number (when possible).
         * Otherwise, skip the channel tuple
         */
        if(!swl_chanspec_isValidBandExt(chanspec.band)) {
            chanspec.band = swl_chanspec_freqBandExtFromBaseChannel(chanspec.channel);
            if(!swl_chanspec_isValidBandExt(chanspec.band)) {
                continue;
            }
            s_saveFreqBand(pWirelessDevIE, chanspec.band);
        }
        pWirelessDevIE->uniiBandsCapabilities |= swl_chanspec_toUniiMask(&chanspec);
    }
}

static void s_parseSSID(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len, uint8_t* frm) {
    ASSERTS_NOT_NULL(frm, , ME, "NULL");
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "SWL_80211_EL_ID_SSID");
    if(len > SWL_80211_SSID_STR_LEN - 1) {
        SAH_TRACEZ_ERROR(ME, "SSID length incorrect");
        return;
    }
    memcpy(pWirelessDevIE->ssid, frm, len);
    pWirelessDevIE->ssidLen = len;
}

static void s_parseRsn(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len, uint8_t* frm) {
    ASSERTS_NOT_NULL(frm, , ME, "NULL");
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");

    SAH_TRACEZ_INFO(ME, "Parsing RSN IE len %d", len);
    ASSERT_TRUE(len >= 8, , ME, "RSN too short");
    ASSERT_TRUE(frm[0] == 1, , ME, "RSN version not supported");
    /* skip len + version */
    frm += 2;
    len -= 2;

    swl_80211_cipher_m cipherSuiteParams = SWL_80211_USE_GRP_CIPHER_SUITE;
    swl_80211_akm_m akmSuiteParams = SWL_80211_AKM_SUITES_RESERVED;
    /* groupDataCipher == (00 0F AC xx) with xx the only changing byte.
     * See Table 9-149 in nl80211 standard for mor information
     */
    uint8_t groupDataCipher = frm[3];
    SAH_TRACEZ_INFO(ME, "groupDataCipher 00 0F AC %X", frm[3]);
    swl_80211_getDataCipherSuite(groupDataCipher, &cipherSuiteParams);
    frm += 4;
    len -= 4;

    /* skip pairwise cipher suite */
    uint8_t n_uciphers = *frm;
    uint32_t size_ciphers = n_uciphers * 4 + 2;
    ASSERT_TRUE(len >= size_ciphers, , ME, "ucast cipher data too short");

    /* skip pairwise cipher counter */
    frm += 2;
    len -= 2;

    // Get Pairwise Cipher suite list (4*counter bytes)
    for(int i = 0; i < n_uciphers; i++) {
        uint8_t pairwiseCipher = frm[3 + (i * 4)];
        swl_80211_getDataCipherSuite(pairwiseCipher, &cipherSuiteParams);
    }
    frm += (size_ciphers - 2);
    len -= (size_ciphers - 2);

    /* skip authentication key mgt suite*/
    uint8_t n_keymgmt = *frm;
    uint32_t size_keymgmt = n_keymgmt * 4 + 2;
    ASSERT_TRUE(len >= size_keymgmt, , ME, "keygmt data too short");

    /* skip AKM Suite counter */
    frm += 2;
    len -= 2;

    /* Get AKM Suitelist (4*counter bytes) */
    for(int i = 0; i < n_keymgmt; i++) {
        uint8_t akmSuiteList = frm[3 + (i * 4)];
        swl_80211_getDataAKMsuite(akmSuiteList, &akmSuiteParams);
    }
    frm += (size_keymgmt - 2);
    len -= (size_keymgmt - 2);

    /* rsn capabilities */
    ASSERT_TRUE(len >= 2, , ME, "RSN capabilities  data too short %d", len);
    SAH_TRACEZ_INFO(ME, "BCM RSN Capabilites (0x%02x): \n", frm[0]);
    /* PMF capability 1... ....*/
    if(SWL_BIT_IS_SET(frm[0], 7)) {
        pWirelessDevIE->capabilities |= M_SWL_STACAP_PMF;
    }

    /* Get Security mods */
    swl_security_getMode(&pWirelessDevIE->secModeEnabled, &cipherSuiteParams, &akmSuiteParams);

}

static void s_parseRmCap(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs _UNUSED, swl_80211_elId_ne elId _UNUSED, uint8_t len _UNUSED, uint8_t* frm) {
    ASSERTS_NOT_NULL(frm, , ME, "NULL");
    ASSERTS_NOT_NULL(pWirelessDevIE, , ME, "NULL");
    ASSERT_FALSE(len < SWL_80211_EL_RM_ENAB_CAP_LEN, , ME, "short IE payload size");

    /* RM Enable Capabilities bits */
    swl_staCapRrmCap_e capBit[] = {
        SWL_STACAP_RRM_LINK_ME,                   /* bit0 */
        SWL_STACAP_RRM_NEIGHBOR_RE,               /* bit1 */
        SWL_STACAP_RRM_PRALLAL_ME,                /* bit2 */
        SWL_STACAP_RRM_REPEATED_ME,               /* bit3 */
        SWL_STACAP_RRM_BEACON_PASSIVE_ME,         /* bit4 */
        SWL_STACAP_RRM_BEACON_ACTIVE_ME,          /* bit5 */
        SWL_STACAP_RRM_BEACON_TABLE_ME,           /* bit6 */
        SWL_STACAP_RRM_BEACON_ME_RE_COND,         /* bit7 */
        SWL_STACAP_RRM_FRAME_ME,                  /* bit8 */
        SWL_STACAP_RRM_CHAN_LOAD_ME,              /* bit9 */
        SWL_STACAP_RRM_NOISE_HISTOGRAM_ME,        /* bit10 */
        SWL_STACAP_RRM_STATS_ME,                  /* bit11 */
        SWL_STACAP_RRM_LCI_ME,                    /* bit12 */
        SWL_STACAP_RRM_LCI_AZIMUTH_ME,            /* bit13 */
        SWL_STACAP_RRM_TRANS_SC_ME,               /* bit14 */
        SWL_STACAP_RRM_TRIG_SC_ME,                /* bit15 */
        SWL_STACAP_RRM_AP_CHAN_RE,                /* bit16 */
        0,                                        /* bit17 */
        /* bit 18-20 On-Channel Max Duration */
        0,                                        /* bit18 */
        0,                                        /* bit19 */
        0,                                        /* bit20 */
        /* bit 21-23 Off-Channel Max Duration */
        0,                                        /* bit21 */
        0,                                        /* bit22 */
        0,                                        /* bit23 */
        /* POLT */
        0,                                        /* bit24 */
        0,                                        /* bit25 */
        0,                                        /* bit26 */
        0,                                        /* bit27 */
        SWL_STACAP_RRM_NEIG_RE_TSF_OFFSET,        /* bit28 */
        SWL_STACAP_RRM_RCPI_ME,                   /* bit29 */
        SWL_STACAP_RRM_RSNI_ME,                   /* bit30 */
        SWL_STACAP_RRM_BSS_AVG_ACCESS_DELAY,      /* bit31 */
        SWL_STACAP_RRM_BSS_AVAIL_ADMISS_CAPACITY, /* bit32 */
        SWL_STACAP_RRM_ANTENNA,                   /* bit33 */
        SWL_STACAP_RRM_FTM_RANGE_RE,              /* bit34 */
        SWL_STACAP_RRM_CIVIC_LOCATION_ME,         /* bit35 */
        SWL_STACAP_RRM_IDENT_LOCATION_ME,         /* bit36 (extension) */
        /* bit 37-39 reserved */
    };

    SAH_TRACEZ_INFO(ME, "Parsing RM Enable Capabilities %p", frm);
    swl_bit8_t* rmCapabilities = frm;

    /* Set detected capabilities */
    for(uint32_t i = 0; i < SWL_ARRAY_SIZE(capBit); i++) {
        if(SWL_BIT_IS_SET(rmCapabilities[i / 8], (i % 8))) {
            W_SWL_BIT_SET(pWirelessDevIE->rrmCapabilities, capBit[i]);
        }
    }

    /* On-Channel Max Duration, in Time Unit (TU) */
    pWirelessDevIE->rrmOnChannelMaxDuration = ((rmCapabilities[2] & 0x1c) >> 2);


    /* Off-Channel Max Duration in Time Unit (TU)
     * 11.10.4 Measurement duration @ IEEE Std 802.11-2020
     * If this attribute is 0, the STA does not support RM measurements on nonoperating channels */
    pWirelessDevIE->rrmOffChannelMaxDuration = ((rmCapabilities[2] & 0xe0) >> 5);

    if(pWirelessDevIE->rrmCapabilities != 0) {
        W_SWL_BIT_SET(pWirelessDevIE->capabilities, SWL_STACAP_RRM);
    }
}


SWL_TABLE(ieParseTable,
          ARR(uint8_t index; void* val; ),
          ARR(swl_type_uint8, swl_type_voidPtr),
          ARR({SWL_80211_EL_ID_SSID, (void*) s_parseSSID},
              {SWL_80211_EL_ID_SUP_CHAN, (void*) s_parseSupChan},
              {SWL_80211_EL_ID_HT_CAP, (void*) s_parseHtCap},
              {SWL_80211_EL_ID_RSN, (void*) s_parseRsn},
              {SWL_80211_EL_ID_MOB_DOM, (void*) s_parseMobDom},
              {SWL_80211_EL_ID_SUP_OP_CLASS, (void*) s_parseRegClass},
              {SWL_80211_EL_ID_HT_OP, (void*) s_parseHtOp},
              {SWL_80211_EL_ID_RM_ENAB_CAP, (void*) s_parseRmCap},
              {SWL_80211_EL_ID_EXT_CAP, (void*) s_parseExtCap},
              {SWL_80211_EL_ID_VHT_CAP, (void*) s_parseVhtCap},
              {SWL_80211_EL_ID_VHT_OP, (void*) s_parseVhtOp},
              {SWL_80211_EL_ID_VENDOR_SPECIFIC, (void*) s_parseVendor},
              {SWL_80211_EL_ID_EXT, (void*) s_parseExt},
              )
          );
typedef void (* elementParseFun_f) (swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs, swl_80211_elId_ne elId, uint8_t len, uint8_t* frm);


swl_rc_ne swl_80211_processInfoElementFrame(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs, uint8_t elementId, int8_t len, uint8_t* data) {
    ASSERT_NOT_NULL(pWirelessDevIE, SWL_RC_INVALID_PARAM, ME, "NULL");
    ASSERT_NOT_NULL(data, SWL_RC_INVALID_PARAM, ME, "NULL");

    swl_rc_ne rc = SWL_RC_OK;

    void** func = (void**) swl_table_getMatchingValue(&ieParseTable, 1, 0, &elementId);
    if(func != NULL) {
        elementParseFun_f myFun = (elementParseFun_f) (*func);
        myFun(pWirelessDevIE, pParsingArgs, elementId, len, data);
    } else {
        SAH_TRACEZ_INFO(ME, "Unsupported element id %d", elementId);
        rc = SWL_RC_INVALID_PARAM;
    }

    return rc;
}

/*
 * @brief Parse 80211 Info Elements buffer (including TLVs) into user data structure
 *
 * @param pWirelessDevIE: (out) pointer to device info to be filled
 * @param pParsingArgs: (in) pointer to optional parsing argument, that may be used to initialize some result values
 * @param iesLen: (in) Information Elements buffer length
 * @param iesData: (in) Information Elements buffer data
 *
 * @return number of processed bytes of the input buffer (shall be equal to iesLen when all data has been processed)
 *         or negative SWL_RC error code when major error happens.
 *         It is up to application to consider error when parsing is partial (i.e returning < iesLen)
 */
ssize_t swl_80211_parseInfoElementsBuffer(swl_wirelessDevice_infoElements_t* pWirelessDevIE, swl_parsingArgs_t* pParsingArgs, size_t iesLen, uint8_t* iesData) {
    ASSERT_NOT_NULL(pWirelessDevIE, SWL_RC_INVALID_PARAM, ME, "NULL");
    memset(pWirelessDevIE, 0, sizeof(*pWirelessDevIE));
    pWirelessDevIE->operChanInfo.band = SWL_FREQ_BAND_EXT_NONE;
    ASSERTI_TRUE(iesLen > 0, 0, ME, "No data");
    ASSERT_NOT_NULL(iesData, SWL_RC_INVALID_PARAM, ME, "NULL");

    if(pParsingArgs != NULL) {
        if(swl_channel_isInChanspec(&pParsingArgs->seenOnChanspec, pParsingArgs->seenOnChanspec.channel)) {
            pWirelessDevIE->operChanInfo.channel = pParsingArgs->seenOnChanspec.channel;
            s_saveFreqBand(pWirelessDevIE, pParsingArgs->seenOnChanspec.band);
        }
    }

    size_t index = 0;
    swl_80211_elId_ne elementId;
    swl_bit8_t elementLen = 0;
    const swl_bit8_t* elementData = NULL;
    //assume all IEs are TLVs: so at least "Type" and "Length" byte fields
    while((index + 2) < iesLen) {
        elementId = iesData[index];
        index++;
        elementLen = iesData[index];
        index++;
        if((index + elementLen) > iesLen) {
            SAH_TRACEZ_WARNING(ME, "Too short: abort parsing IE(ID:%u,Len:%u) at index %zu (/%zu)",
                               elementId, elementLen, index, iesLen);
            break;
        }
        elementData = &iesData[index];
        swl_80211_processInfoElementFrame(pWirelessDevIE, pParsingArgs, elementId, elementLen, (swl_bit8_t*) elementData);
        index += elementLen;
    }

    return index;
}

swl_80211_mgmtFrame_t* swl_80211_getMgmtFrame(swl_bit8_t* frameData, size_t frameLen) {
    ASSERT_NOT_NULL(frameData, NULL, ME, "NULL");
    ASSERT_FALSE(frameLen < SWL_80211_MGMT_FRAME_HEADER_LEN, NULL, ME, "frame shorter that header size");
    swl_80211_mgmtFrame_t* frame = (swl_80211_mgmtFrame_t*) frameData;
    ASSERT_EQUALS(frame->fc.type, 0, NULL, ME, "not mgmt frame");
    return frame;
}

#define GET_IES(iesOffset, iesData, frame, frameBodyType) \
    { \
        iesOffset += offsetof(frameBodyType, ies); \
        frameBodyType* frmBody = (frameBodyType*) frame->body; \
        iesData = frmBody->ies; \
    }
swl_bit8_t* swl_80211_getInfoElementsOfMgmtFrame(size_t* pIesLen, swl_bit8_t* frameData, size_t frameLen) {
    if(pIesLen != NULL) {
        *pIesLen = 0;
    }
    swl_80211_mgmtFrame_t* frame = swl_80211_getMgmtFrame(frameData, frameLen);
    swl_bit8_t* iesData = NULL;
    ASSERT_NOT_NULL(frame, iesData, ME, "NULL");
    size_t iesOffset = SWL_80211_MGMT_FRAME_HEADER_LEN;
    uint8_t mgtFrameType = (frame->fc.subType << 4);
    if(mgtFrameType == SWL_80211_MGT_FRAME_TYPE_ASSOC_REQUEST) {
        GET_IES(iesOffset, iesData, frame, swl_80211_assocReqFrameBody_t);
    } else if(mgtFrameType == SWL_80211_MGT_FRAME_TYPE_REASSOC_REQUEST) {
        GET_IES(iesOffset, iesData, frame, swl_80211_reassocReqFrameBody_t);
    } else if(mgtFrameType == SWL_80211_MGT_FRAME_TYPE_PROBE_REQUEST) {
        GET_IES(iesOffset, iesData, frame, swl_80211_probeReqFrameBody_t);
    } else if(mgtFrameType == SWL_80211_MGT_FRAME_TYPE_PROBE_RESPONSE) {
        GET_IES(iesOffset, iesData, frame, swl_80211_probeRespFrameBody_t);
    } else if(mgtFrameType == SWL_80211_MGT_FRAME_TYPE_BEACON) {
        GET_IES(iesOffset, iesData, frame, swl_80211_beaconFrameBody_t);
    }
    ASSERTW_NOT_NULL(iesData, iesData, ME, "unsupported parse of mgmt frame type (0x%x) ", mgtFrameType);
    ASSERT_FALSE(frameLen < iesOffset, NULL, ME, "frame too short to be parsed");
    if(pIesLen != NULL) {
        *pIesLen = frameLen - iesOffset;
    }
    return iesData;
}

