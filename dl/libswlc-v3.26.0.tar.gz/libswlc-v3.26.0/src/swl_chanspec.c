/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <errno.h>
#include "swl/swl_common_chanspec.h"
#include "swl/swl_assert.h"
#include "swl/swl_common_table.h"
#include "swl/swl_common.h"
#include "swl/swl_common_type.h"

#define ME "swlChan"

const char* swl_bandwidth_unknown_str[] = {"Unknown", "20MHz", "40MHz", "80MHz", "160MHz", "10MHz", "5MHz", "2MHz"};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_bandwidth_unknown_str) == SWL_BW_MAX, "swl_bandwidth_unknown_str not correctly defined");

const char* swl_bandwidth_str[] = {"Auto", "20MHz", "40MHz", "80MHz", "160MHz", "10MHz", "5MHz", "2MHz"};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_bandwidth_str) == SWL_BW_MAX, "swl_bandwidth_str not correctly defined");

const char* swl_bandwidth_intStr[SWL_BW_MAX] = {"0", "20", "40", "80", "160", "10", "5", "2"};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_bandwidth_intStr) == SWL_BW_MAX, "swl_bandwidth_intStr not correctly defined");

const uint32_t swl_bandwidth_int[] = {0, 20, 40, 80, 160, 10, 5, 2};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_bandwidth_int) == SWL_BW_MAX, "swl_bandwidth_int not correctly defined");

SWL_TYPE_ENUM_C(gtSwl_type_bandwidthUnknown, swl_bandwidth_e, SWL_BW_AUTO, SWL_BW_MAX, swl_bandwidth_unknown_str);
SWL_TYPE_ENUM_C(gtSwl_type_bandwidth, swl_bandwidth_e, SWL_BW_AUTO, SWL_BW_MAX, swl_bandwidth_str);

const char* swl_freqBand_str[] = {"2.4GHz", "5GHz", "6GHz"};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_freqBand_str) == SWL_FREQ_BAND_MAX, "swl_freqBand_str not correctly defined");
const char* swl_freqBandShort_str[] = {"2g", "5g", "6g"};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_freqBandShort_str) == SWL_FREQ_BAND_MAX, "swl_freqBandShort_str not correctly defined");
const char* swl_freqBandNumberOnly_str[] = {"2.4", "5", "6"};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_freqBandNumberOnly_str) == SWL_FREQ_BAND_MAX, "swl_freqBandNumberOnly_str not correctly defined");
const char* swl_freqBandExt_unknown_str[] = {"2.4GHz", "5GHz", "6GHz", "Unknown", "Auto"};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_freqBandExt_unknown_str) == SWL_FREQ_BAND_EXT_MAX, "swl_freqBand_unknown_str not correctly defined");
const char* swl_freqBandExt_str[] = {"2.4GHz", "5GHz", "6GHz", "None", "Auto"};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_freqBandExt_str) == SWL_FREQ_BAND_EXT_MAX, "swl_freqBandExt_str not correctly defined");
const uint32_t swl_freqBandExt_int[] = {2, 5, 6, 0, -1};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_freqBandExt_int) == SWL_FREQ_BAND_EXT_MAX, "swl_freqBandExt_str not correctly defined");

const swl_channel_t swl_channel_defaults[SWL_FREQ_BAND_MAX] = {1, 36, 1};

const swl_radioStandard_m swl_freqBand_radStd[] =
{
    M_SWL_RADSTD_B | M_SWL_RADSTD_G | M_SWL_RADSTD_N | M_SWL_RADSTD_AX,  // #SWL_FREQ_BAND_2_4GHZ
    M_SWL_RADSTD_A | M_SWL_RADSTD_N | M_SWL_RADSTD_AC | M_SWL_RADSTD_AX, // #SWL_FREQ_BAND_5GHZ
    M_SWL_RADSTD_AX,                                                     // #SWL_FREQ_BAND_6GHZ
};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_freqBand_radStd) == SWL_FREQ_BAND_MAX,
                  "update 'swl_radStd_supportedInFreqBand' when adding frequency bands");

const swl_radStd_e swl_freqBand_legacyRadStd[] =
{
    SWL_RADSTD_G,  // #SWL_FREQ_BAND_2_4GHZ
    SWL_RADSTD_A,  // #SWL_FREQ_BAND_5GHZ
    SWL_RADSTD_AX, // #SWL_FREQ_BAND_6GHZ
};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_freqBand_legacyRadStd) == SWL_FREQ_BAND_MAX,
                  "update 'swl_freqBand_legacyRadStd' when adding frequency bands");

const char* swl_uniiBand_str[] = {"Unknown", "U-NII-1", "U-NII-2A", "U-NII-2B", "U-NII-2C", "U-NII-3", "U-NII-4", "U-NII-5", "U-NII-6", "U-NII-7", "U-NII-8"};
SWL_ASSERT_STATIC(SWL_ARRAY_SIZE(swl_uniiBand_str) == SWL_BAND_MAX, "swl_uniiBand_str not correctly defined");

SWL_TYPE_ENUM_C(gtSwl_type_freqBand, swl_freqBand_e, SWL_FREQ_BAND_2_4GHZ, SWL_FREQ_BAND_MAX, swl_freqBand_str);
SWL_TYPE_ENUM_C(gtSwl_type_freqBandExt, swl_freqBandExt_e, SWL_FREQ_BAND_EXT_NONE, SWL_FREQ_BAND_EXT_MAX, swl_freqBandExt_str);
SWL_TYPE_ENUM_C(gtSwl_type_freqBandExtUnknown, swl_freqBandExt_e, SWL_FREQ_BAND_EXT_NONE, SWL_FREQ_BAND_EXT_MAX, swl_freqBandExt_unknown_str);
SWL_TYPE_ENUM_C(swl_type_uniiBand_impl, swl_uniiBand_e, SWL_BAND_UNII_UNKNOWN, SWL_BAND_MAX, swl_uniiBand_str);

/* Annex E: Table E-4—Global operating classes */
static struct {
    swl_operatingClass_t operClass;
    swl_bandwidth_e bandwidth;
    swl_freqBandExt_e band;
    swl_channel_t* channels;
} sSwl_operatingClassInfoGlobal[] = {
    {81, SWL_BW_20MHZ, SWL_FREQ_BAND_EXT_2_4GHZ, (swl_channel_t[]) {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0}},
    {82, SWL_BW_20MHZ, SWL_FREQ_BAND_EXT_2_4GHZ, (swl_channel_t[]) {14, 0}},
    {83, SWL_BW_40MHZ, SWL_FREQ_BAND_EXT_2_4GHZ, (swl_channel_t[]) {1, 2, 3, 4, 5, 6, 7, 8, 9, 0}},
    {84, SWL_BW_40MHZ, SWL_FREQ_BAND_EXT_2_4GHZ, (swl_channel_t[]) {5, 6, 7, 8, 9, 10, 11, 12, 13, 0}},
    {115, SWL_BW_20MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {36, 40, 44, 48, 0}},
    {116, SWL_BW_40MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {36, 44, 0}},
    {117, SWL_BW_40MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {40, 48, 0}},
    {118, SWL_BW_20MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {52, 56, 60, 64, 0}},
    {119, SWL_BW_40MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {52, 60, 0}},
    {120, SWL_BW_40MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {56, 64, 0}},
    {121, SWL_BW_20MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144, 0}},
    {122, SWL_BW_40MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {100, 108, 116, 124, 132, 140, 0}},
    {123, SWL_BW_40MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {104, 112, 120, 128, 136, 144, 0}},
    {124, SWL_BW_20MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {149, 153, 157, 161, 0}},
    {125, SWL_BW_20MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {149, 153, 157, 161, 165, 169, 173, 177, 0}},
    {126, SWL_BW_40MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {149, 157, 165, 173, 0}},
    {127, SWL_BW_40MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {153, 161, 169, 177, 0}},
    {128, SWL_BW_80MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {42, 58, 106, 122, 138, 155, 171, 0}},
    {129, SWL_BW_160MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {50, 114, 163, 0}},
    /* {130, SWL_BW_160MHZ, SWL_FREQ_BAND_EXT_5GHZ, (swl_channel_t[]) {42, 58, 106, 122, 138, 155, 171, 0}}, */ /* 80+80 MHz ! */
    {131, SWL_BW_20MHZ, SWL_FREQ_BAND_EXT_6GHZ, (swl_channel_t[]) {1, 5, 9, 13, 17, 21, 25, 29, 33, 37, 41, 45, 49, 53, 57, 61, 65, 69, 73, 77, 81, 85, 89, 93, 97, 101, 105, 109, 113, 117, 121, 125, 129, 133, 137, 141, 145, 149, 153, 157, 161, 165, 169, 173, 177, 181, 185, 189, 193, 197, 201, 205, 209, 213, 217, 221, 225, 229, 233, 0}},
    {132, SWL_BW_40MHZ, SWL_FREQ_BAND_EXT_6GHZ, (swl_channel_t[]) {3, 11, 19, 27, 35, 43, 51, 59, 67, 75, 83, 91, 99, 107, 115, 123, 131, 139, 147, 155, 163, 171, 179, 187, 195, 203, 211, 219, 227, 0}},
    {133, SWL_BW_80MHZ, SWL_FREQ_BAND_EXT_6GHZ, (swl_channel_t[]) {7, 23, 39, 55, 71, 87, 103, 119, 135, 151, 167, 183, 199, 215, 0}},
    {134, SWL_BW_160MHZ, SWL_FREQ_BAND_EXT_6GHZ, (swl_channel_t[]) {15, 47, 79, 111, 143, 175, 207, 0}},
    /* {135, SWL_BW_160MHZ, SWL_FREQ_BAND_EXT_6GHZ, (swl_channel_t[]) {7, 23, 39, 55, 71, 87, 103, 119, 135, 151, 167, 183, 199, 215, 0}}, */ /* 80+80 MHz ! */
    {136, SWL_BW_20MHZ, SWL_FREQ_BAND_EXT_6GHZ, (swl_channel_t[]) {2, 0}},
};

/*
 * unii groups
 */
static swl_chanspec_uniiBandGroupInfo_t swl_chanspec_uniiBandGroups[] = {
    {.mask = M_SWL_BAND_UNII_1, .name = "UNII1"},
    {.mask = M_SWL_BAND_UNII_2A, .name = "UNII2A"},
    {.mask = M_SWL_BAND_UNII_2B, .name = "UNII2B"},
    {.mask = M_SWL_BAND_UNII_2C, .name = "UNII2C"},
    {.mask = M_SWL_BAND_UNII_3, .name = "UNII3"},
    {.mask = M_SWL_BAND_UNII_2, .name = "UNII2"},         //combination of UNII2A and UNII2C
    {.mask = M_SWL_BAND_UNII_1_2, .name = "UNII2-INC"},   //combination of UNII1 and UNII2
    {.mask = M_SWL_BAND_UNII_1_2A, .name = "UNII2A-INC"}, //combination of UNII1 and UNII2A
    {.mask = M_SWL_BAND_UNII_4, .name = "UNII4"},
    {.mask = M_SWL_BAND_UNII_5, .name = "UNII5"},
    {.mask = M_SWL_BAND_UNII_6, .name = "UNII6"},
    {.mask = M_SWL_BAND_UNII_7, .name = "UNII7"},
    {.mask = M_SWL_BAND_UNII_8, .name = "UNII8"},
    {.mask = M_SWL_BAND_UNII_ALL_5G, .name = "UNII_ALL_5G"},
    {.mask = M_SWL_BAND_UNII_ALL_6G, .name = "UNII_ALL_6G"},
};

//Operating  classes in Japan  802.11-2020.pdf E-3
static swl_operatingClassTranslation_t s_operClassTranslationTable [] = {
    {81, {12, 4, 30, 7}},
    {82, {0, 0, 31, 0}},
    {83, {32, 11, 56, 8}},
    {84, {33, 12, 57, 9}},
    {115, {1, 1, 1, 1}},
    {116, {22, 5, 36, 4}},
    {117, {27, 8, 41, 0}},
    {118, {2, 2, 32, 2}},
    {119, {23, 6, 37, 5}},
    {120, {28, 9, 42, 0 }},
    {121, {4, 3, 34, 0}},
    {122, {24, 7, 39, 0}},
    {123, {29, 10, 44, 0}},
    {124, {3, 0, 0, 0}},
    {125, {5, 17, 0, 3}},
    {126, {25, 0, 0, 6}},
    {127, {30, 0, 0, 0}},
    {128, {128, 128, 128, 128}},
    {129, {129, 129, 129, 129}},
    {131, {131, 131, 131, 131}},
    {132, {132, 132, 132, 132}},
    {133, {133, 133, 133, 133}},
    {134, {134, 134, 134, 134}},
    {136, {136, 136, 136, 136}},
};

/**
 * @param swlLocalOpertingClass: swl_operatingClass_t local operating class for the given country
 * @param countryIndex: swl_opClassCountry_e index of the given country
 * @return global operating class in swl_operatingClass_t
 */
static swl_operatingClass_t swl_chanspec_getGlobalOperClassfromLocal(swl_operatingClass_t localOpertingClass, swl_opClassCountry_e countryIndex) {
    if((countryIndex < SWL_OP_CLASS_COUNTRY_MAX) && (localOpertingClass > 0)) {
        for(uint32_t i = 0; i < SWL_ARRAY_SIZE(s_operClassTranslationTable); i++) {
            if(s_operClassTranslationTable[i].local_set[countryIndex] == localOpertingClass) {
                return s_operClassTranslationTable[i].global;
            }
        }
    }
    SAH_TRACEZ_ERROR(ME, "no global operatingclass found for local value (%d)", localOpertingClass);
    return 0;

}

/* Operating classes per region are now supported */
swl_freqBandExt_e swl_chanspec_localOperClassToFreq(swl_operatingClass_t operclass, swl_opClassCountry_e countryIndex) {
    swl_operatingClass_t GlobalOperatingClass = swl_chanspec_getGlobalOperClassfromLocal(operclass, countryIndex);
    return swl_chanspec_operClassToFreq(GlobalOperatingClass);
}

swl_phymode_ne swl_chanspec_localOperClassToPhyMode(swl_operatingClass_t operclass, swl_opClassCountry_e countryIndex) {
    swl_operatingClass_t GlobalOperatingClass = swl_chanspec_getGlobalOperClassfromLocal(operclass, countryIndex);
    return swl_chanspec_operClassToPhyMode(GlobalOperatingClass);
}

/* See 802.11ax-2021 Table E-* Global operating classes */
swl_uniiBand_m swl_chanspec_localOperClassToUniiMask(swl_operatingClass_t operclass, swl_opClassCountry_e countryIndex) {
    swl_operatingClass_t GlobalOperatingClass = swl_chanspec_getGlobalOperClassfromLocal(operclass, countryIndex);
    return swl_chanspec_operClassToUniiMask(GlobalOperatingClass);
}

/* See 802.11-2020 / 802.11ax-2021 Table E-* Global operating classes */
swl_bandwidth_e swl_chanspec_localOperClassToBandwidth(swl_operatingClass_t operclass, swl_opClassCountry_e countryIndex) {
    swl_operatingClass_t GlobalOperatingClass = swl_chanspec_getGlobalOperClassfromLocal(operclass, countryIndex);
    return swl_chanspec_operClassToBandwidth(GlobalOperatingClass);
}

/**
 * @param swlBw: swl_bandwidth_e type of bandwidth
 * @return bandwidth in Integer value (MHz)
 */
int32_t swl_chanspec_bwToInt(swl_bandwidth_e swlBw) {
    return swl_bandwidth_int[swlBw];

}
/**
 * @param intBw: Integer value of bandwidth in MHz
 * @return swl_bandwidth_e type
 */
swl_bandwidth_e swl_chanspec_intToBw(uint32_t intBw) {
    for(int i = 0; i < SWL_BW_MAX; i++) {
        if(swl_bandwidth_int[i] == intBw) {
            return i;
        }
    }
    return SWL_BW_AUTO;
}


/**
 * @param swlBand: swl_freqBandExt_e type of band
 * @return band in Integer value (MHz)
 */
int32_t swl_chanspec_freqBandExtToInt(swl_freqBandExt_e swlBand) {
    return swl_freqBandExt_int[swlBand];

}
/**
 * @param intBand: Integer value of band in GHz
 * @return swl_freqBandExt_e type
 *         SWL_FREQ_BAND_EXT_MAX is a value that is preferred not to be returned,
 *         as it does not have a matching value.
 */
swl_freqBandExt_e swl_chanspec_intTofreqBandExt(uint32_t intBand) {
    for(int i = 0; i < SWL_FREQ_BAND_EXT_MAX; i++) {
        if(swl_freqBandExt_int[i] == intBand) {
            return i;
        }
    }
    return SWL_FREQ_BAND_EXT_NONE;
}

bool s_chanspec_compare_cb(swl_type_t* type _UNUSED, const swl_chanspec_t* src, const swl_chanspec_t* key) {
    ASSERTS_NOT_NULL(src, false, ME, "NULL");
    ASSERTS_NOT_NULL(key, false, ME, "NULL");

    if((src->channel == key->channel) && (src->bandwidth == key->bandwidth)) {
        return true;
    } else {
        return false;
    }
}

static ssize_t s_chanspec_toChar_cb(swl_type_t* type _UNUSED, char* tgtStr, size_t tgtStrSize, const void* srcData) {
    ASSERT_NOT_NULL(tgtStr, -EINVAL, ME, "NULL");
    ASSERT_NOT_NULL(srcData, -EINVAL, ME, "NULL");
    return snprintf(tgtStr, tgtStrSize, "%d/%d", (*(swl_chanspec_t*) srcData).channel, swl_chanspec_bwToInt((*(swl_chanspec_t*) srcData).bandwidth));
}

/**
 * converts a src string to an swl_chanspec, ignoring frequencyBand.
 * This function will NOT touch the frequency band in any way, so freqBand will remain as set.
 */
static bool s_chanspec_fromChar_cb(swl_type_t* type _UNUSED, swl_chanspec_t* tgtData, const char* srcStr) {
    ASSERTS_NOT_NULL(srcStr, false, ME, "NULL");
    ASSERTS_NOT_NULL(tgtData, false, ME, "NULL");
    char token1[32] = {0};
    char token2[32] = {0};
    char* ptr = NULL;
    int len = 0;

    if(srcStr == NULL) {
        return true;
    }

    ptr = strchr(srcStr, '/');
    ASSERTS_NOT_NULL(ptr, false, ME, "Syntax Error");
    size_t printLen = snprintf(token2, sizeof(token2), "%s", ptr + 1);
    ASSERT_TRUE(printLen < 4, false, ME, "SIZE");
    len = strcspn(srcStr, "/");
    printLen = snprintf(token1, sizeof(token1), "%.*s", (int) len, srcStr);
    ASSERT_TRUE(printLen < 4, false, ME, "SIZE");

    if(atoi(token1) && swl_chanspec_intToBw(atoi(token2))) {
        tgtData->channel = atoi(token1);
        tgtData->bandwidth = swl_chanspec_intToBw(atoi(token2));
        return true;
    }
    return false;
}

/**
 * Chanspec encodes a channel/band combination. It does NOT encode the frequencyBand, although it
 * is part of the structure that it operates on.
 * Reading and writing will ignore frequencyBand. Copy will copy entire structure including freqBand.
 */
swl_typeFun_t swl_type_chanspec_fun = {
    .isValue = true,
    .toChar = (swl_type_toChar_cb) s_chanspec_toChar_cb,
    .fromChar = (swl_type_fromChar_cb) s_chanspec_fromChar_cb,
    .equals = (swl_type_equals_cb) s_chanspec_compare_cb
};
swl_type_t gtSwl_type_chanspec = {
    .typeFun = &swl_type_chanspec_fun,
    .size = sizeof(swl_chanspec_t),
};

static ssize_t s_chanspecExt_toChar_cb(swl_type_t* type _UNUSED, char* tgtStr, size_t tgtStrSize, const void* srcData) {
    ASSERT_NOT_NULL(tgtStr, -EINVAL, ME, "NULL");
    ASSERT_NOT_NULL(srcData, -EINVAL, ME, "NULL");

    swl_chanspec_t chanspec = *(swl_chanspec_t*) srcData;
    ssize_t ret = snprintf(tgtStr, tgtStrSize, "%d_%d/%d",
                           swl_chanspec_freqBandExtToInt(chanspec.band),
                           chanspec.channel,
                           swl_chanspec_bwToInt(chanspec.bandwidth));
    return ret;
}

static bool s_chanspecExt_fromChar_cb(swl_type_t* type _UNUSED, swl_chanspec_t* tgtData, const char* srcStr) {
    ASSERTS_NOT_NULL(srcStr, false, ME, "NULL");
    ASSERTS_NOT_NULL(tgtData, false, ME, "NULL");
    char token1[32] = {0};
    char token2[32] = {0};
    char token3[32] = {0};
    char* ptr = NULL;
    int len = 0;

    if(srcStr == NULL) {
        return true;
    }

    ptr = strchr(srcStr, '_');
    ASSERTS_NOT_NULL(ptr, false, ME, "Syntax Error");

    size_t printLen = snprintf(token2, sizeof(token2), "%s", ptr + 1);
    ASSERT_TRUE(printLen < 8, false, ME, "SIZE");
    len = strcspn(srcStr, "_");
    printLen = snprintf(token1, sizeof(token1), "%.*s", (int) len, srcStr);
    ASSERT_TRUE(printLen < 4, false, ME, "SIZE");
    ptr = NULL;
    ptr = strchr(srcStr, '/');
    ASSERTS_NOT_NULL(ptr, false, ME, "Syntax Error");
    printLen = snprintf(token3, sizeof(token3), "%s", ptr + 1);
    ASSERT_TRUE(printLen < 4, false, ME, "SIZE");


    swl_freqBandExt_e freqBandExt = swl_chanspec_intTofreqBandExt(atoi(token1));
    bool isFreqBandExt = (freqBandExt != SWL_FREQ_BAND_EXT_MAX);
    if(isFreqBandExt && atoi(token2) && swl_chanspec_intToBw(atoi(token3))) {
        tgtData->band = freqBandExt;
        tgtData->channel = atoi(token2);
        tgtData->bandwidth = swl_chanspec_intToBw(atoi(token3));
        return true;
    }
    return false;
}

/**
 * Compare two swl_chanspec_t entirely.
 * Note that we can NOT do a memcmp, because channel is only 8 bit. If we do a memcmp, and allocate
 * a chanspec on the stack with the SWL_CHANSPEC_NEW function, the 3 bytes that occur after channel
 * will potentially contain garbage, meaning memcmp may fail unexpectedly.
 * Setting channel last also does not work, as compiler auto alligns. Setting to packed will work, but
 * that may reduce access time.
 */
bool s_chanspecExt_compare_cb(swl_type_t* type _UNUSED, const swl_chanspec_t* src, const swl_chanspec_t* key) {
    ASSERTS_NOT_NULL(src, false, ME, "NULL");
    ASSERTS_NOT_NULL(key, false, ME, "NULL");

    if((src->channel == key->channel) && (src->bandwidth == key->bandwidth) && (src->band == key->band)) {
        return true;
    } else {
        return false;
    }
}

swl_typeFun_t swl_type_chanspecExt_fun = {
    .isValue = true,
    .toChar = (swl_type_toChar_cb) s_chanspecExt_toChar_cb,
    .fromChar = (swl_type_fromChar_cb) s_chanspecExt_fromChar_cb,
    .equals = (swl_type_equals_cb) s_chanspecExt_compare_cb
};
swl_type_t gtSwl_type_chanspecExt = {
    .typeFun = &swl_type_chanspecExt_fun,
    .size = sizeof(swl_chanspec_t)
};


/**
 * Function used to parse the comma seperated channels spec list and returns the swl_chanspec_t
 * @param srcStrList: comma separated channel spec list in the format of <channel>/<(int)bandwidth>
 * @param count: Maximum size of the List
 * @param chanSpec: Type of swl_chanspec_t to get the items and values as an integer
 */
int32_t swl_chanspec_arrayFromChar(swl_chanspec_t* chanSpec, uint8_t count, const char* srcStrList) {
    ASSERT_NOT_NULL(srcStrList, -1, ME, "NULL");
    ASSERT_NOT_NULL(chanSpec, -1, ME, "NULL");
    ASSERT_TRUE(count > 0, -1, ME, "null List");

    int len = 0;
    unsigned int i = 0;
    char* mainstr = strdup(srcStrList);
    char* strPtr = NULL;
    char substr[32] = {0};
    ASSERT_NOT_NULL(mainstr, -1, ME, "Alloc Failed");
    strPtr = mainstr;
    do {
        if(i >= count) {
            SAH_TRACEZ_ERROR(ME, "Source Str List is too large(%d,%d)", i, count);
            free(strPtr);
            return -1;
        }
        len = strcspn(mainstr, ",");
        snprintf(substr, sizeof(substr), "%.*s", (int) len, mainstr);
        if(s_chanspec_fromChar_cb(swl_type_chanspec, &chanSpec[i], substr) == false) {
            SAH_TRACEZ_ERROR(ME, "Syntax Error");
            free(strPtr);
            return -2;
        }
        i++;
        mainstr += len;
    } while(*mainstr++);

    free(strPtr);
    return i;

}

/**
 * Function used to get the Array of swl_chanspec_t and provide comma seperated channel spec list
 * @param srcData: swl_chanspec_t type of elements
 * @param srcDataSize: Number of elements available in srcData
 * @param tgtStrSize: buffer size of tgtStr
 * @param tgtStr: Output contains the comma seperated list
 */
bool swl_chanspec_arrayToChar(char* tgtStr, uint32_t tgtStrSize, swl_chanspec_t* srcData, size_t srcDataSize) {
    ASSERT_NOT_NULL(tgtStr, false, ME, "NULL");
    uint32_t i = 0;
    uint32_t index = 0;
    int printed = 0;
    tgtStr[0] = '\0';

    for(i = 0; i < srcDataSize; i++) {
        if(index) {
            printed = snprintf(&tgtStr[index], tgtStrSize - index, ",%d/%d", srcData[i].channel, swl_chanspec_bwToInt(srcData[i].bandwidth));
        } else {
            printed = snprintf(&tgtStr[index], tgtStrSize - index, "%d/%d", srcData[i].channel, swl_chanspec_bwToInt(srcData[i].bandwidth));
        }
        index += printed;
        ASSERT_TRUE(index < tgtStrSize, false, ME, "Buff too small");
    }
    return true;
}

swl_uniiBand_e swl_chanspec_toUnii(const swl_chanspec_t* chanspec) {
    ASSERTS_NOT_NULL(chanspec, 0, ME, "NULL");
    if(chanspec->band == SWL_FREQ_BAND_EXT_2_4GHZ) {
        return SWL_BAND_UNII_UNKNOWN;
    } else if(chanspec->band == SWL_FREQ_BAND_EXT_5GHZ) {
        if((chanspec->channel >= 36) && (chanspec->channel <= 48)) {
            return SWL_BAND_UNII_1;
        } else if((chanspec->channel >= 52) && (chanspec->channel <= 68)) {
            return SWL_BAND_UNII_2A;
        } else if((chanspec->channel >= 70) && (chanspec->channel <= 96)) {
            return SWL_BAND_UNII_2B;
        } else if((chanspec->channel >= 100) && (chanspec->channel <= 144)) {
            return SWL_BAND_UNII_2C;
        } else if((chanspec->channel >= 149) && (chanspec->channel <= 165)) {
            return SWL_BAND_UNII_3;
        } else if((chanspec->channel >= 167) && (chanspec->channel <= 181)) {
            return SWL_BAND_UNII_4;
        }
    } else if(chanspec->band == SWL_FREQ_BAND_EXT_6GHZ) {
        if((chanspec->channel >= 1) && (chanspec->channel <= 93)) {
            return SWL_BAND_UNII_5;
        } else if((chanspec->channel >= 97) && (chanspec->channel <= 113)) {
            return SWL_BAND_UNII_6;
        } else if((chanspec->channel >= 117) && (chanspec->channel <= 185)) {
            return SWL_BAND_UNII_7;
        } else if((chanspec->channel >= 189) && (chanspec->channel <= 233)) {
            return SWL_BAND_UNII_8;
        }
    }
    SAH_TRACEZ_INFO(ME, "Unsupported channel/band %d/%d", chanspec->channel, chanspec->band);
    return SWL_BAND_UNII_UNKNOWN;
}

/* Only global operating classes are supported for now, operating classes per region are not yet listed */
swl_freqBandExt_e swl_chanspec_operClassToFreq(swl_operatingClass_t operclass) {
    if((operclass >= 81) && (operclass <= 84)) {
        return SWL_FREQ_BAND_EXT_2_4GHZ;
    } else if((operclass >= 115) && (operclass <= 130)) {
        return SWL_FREQ_BAND_EXT_5GHZ;
    } else if((operclass >= 131) && (operclass <= 136)) {
        return SWL_FREQ_BAND_EXT_6GHZ;
    }
    SAH_TRACEZ_INFO(ME, "Unsupported operating class %d", operclass);
    return SWL_FREQ_BAND_EXT_NONE;
}

swl_phymode_ne swl_chanspec_operClassToPhyMode(swl_operatingClass_t operclass) {
    if((operclass >= 81) && (operclass <= 84)) {
        return SWL_PHYMODE_HT;
    } else if((operclass >= 115) && (operclass <= 130)) {
        return SWL_PHYMODE_VHT;
    } else if((operclass >= 131) && (operclass <= 136)) {
        return SWL_PHYMODE_HE;
    }
    SAH_TRACEZ_INFO(ME, "Unsupported operating class %d", operclass);
    return SWL_PHYMODE_UNKNOWN;
}

/* See 802.11ax-2021 Table E-4 Global operating classes */
swl_uniiBand_m swl_chanspec_operClassToUniiMask(swl_operatingClass_t operclass) {
    if((operclass >= 115) && (operclass <= 117)) {
        return M_SWL_BAND_UNII_1;
    } else if((operclass >= 118) && (operclass <= 120)) {
        return M_SWL_BAND_UNII_2A;
    } else if((operclass >= 121) && (operclass <= 123)) {
        return M_SWL_BAND_UNII_2C;
    } else if(operclass == 124) {
        return M_SWL_BAND_UNII_3;
    } else if((operclass >= 125) && (operclass <= 127)) {
        return M_SWL_BAND_UNII_3 | M_SWL_BAND_UNII_4;
    } else if((operclass >= 128) && (operclass <= 130)) {
        return M_SWL_BAND_UNII_ALL_5G;
    } else if((operclass >= 131) && (operclass <= 135)) {
        return M_SWL_BAND_UNII_ALL_6G;
    } else if(operclass == 136) {
        return M_SWL_BAND_UNII_5;
    }
    SAH_TRACEZ_INFO(ME, "Unsupported operating class %d", operclass);
    return 0;
}

/* See 802.11-2020 / 802.11ax-2021 Table E-4 Global operating classes */
swl_bandwidth_e swl_chanspec_operClassToBandwidth(swl_operatingClass_t operclass) {
    swl_operatingClass_t sOperClassBandwidthMaps[SWL_BW_MAX][CHAN_MAX_VALUE] = {
        {0},                                                          /* BW AUTO */
        {81, 82, 115, 118, 121, 124, 125, 131, 0},                    /* BW 20MHz */
        {83, 84, 116, 117, 119, 120, 122, 123, 126, 127, 132, 0},     /* BW 40MHz */
        {128, 130, 133, 135, 0},                                      /* BW 80MHz */
        {129, 134, 0},                                                /* BW 160MHz */
        {0},                                                          /* BW 10MHz */
        {0},                                                          /* BW 5MHz */
        {0},                                                          /* BW 2MHz */
    };
    for(uint32_t i = 0; i < SWL_BW_MAX; i++) {
        for(uint8_t j = 0; (j < CHAN_MAX_VALUE) && (sOperClassBandwidthMaps[i][j] > 0); j++) {
            if(sOperClassBandwidthMaps[i][j] == operclass) {
                return i;
            }
        }
    }
    SAH_TRACEZ_WARNING(ME, "Unsupported operating class %d", operclass);
    return SWL_BW_AUTO;
}

swl_freqBandExt_e swl_chanspec_uniiToFreq(swl_uniiBand_m uniiBands) {
    if(uniiBands & M_SWL_BAND_UNII_1
       || uniiBands & M_SWL_BAND_UNII_2
       || uniiBands & M_SWL_BAND_UNII_3
       || uniiBands & M_SWL_BAND_UNII_4) {
        return SWL_FREQ_BAND_EXT_5GHZ;
    }
    if(uniiBands & M_SWL_BAND_UNII_5
       || uniiBands & M_SWL_BAND_UNII_6
       || uniiBands & M_SWL_BAND_UNII_7
       || uniiBands & M_SWL_BAND_UNII_8) {
        return SWL_FREQ_BAND_EXT_6GHZ;
    }
    return SWL_FREQ_BAND_EXT_NONE;
}

swl_uniiBand_m swl_chanspec_toUniiMask(const swl_chanspec_t* chanspec) {
    ASSERTS_NOT_NULL(chanspec, M_SWL_BAND_UNII_UNKNOWN, ME, "NULL");
    return (1 << swl_chanspec_toUnii(chanspec));
}

swl_uniiBand_m swl_chanspec_getUniiBandGroupMaskWithName(const char* groupName) {
    ASSERTS_NOT_NULL(groupName, M_SWL_BAND_UNII_UNKNOWN, ME, "NULL");
    uint32_t i;
    for(i = 0; i < SWL_ARRAY_SIZE(swl_chanspec_uniiBandGroups); i++) {
        if(!strcmp(groupName, swl_chanspec_uniiBandGroups[i].name)) {
            return swl_chanspec_uniiBandGroups[i].mask;
        }
    }
    return M_SWL_BAND_UNII_UNKNOWN;
}

const char* swl_chanspec_getUniiBandGroupNameWithMask(swl_uniiBand_m groupMask) {
    uint32_t i;
    for(i = 0; i < SWL_ARRAY_SIZE(swl_chanspec_uniiBandGroups); i++) {
        if(swl_chanspec_uniiBandGroups[i].mask == groupMask) {
            return swl_chanspec_uniiBandGroups[i].name;
        }
    }
    return NULL;
}

/**
 * Function checks whether freqBand has a valid frequency band value (2.4GHz, 5GHz, 6GHz)
 * @param freqBand: frequency Band
 * @return true if frequency Band is in [SWL_FREQ_BAND_2_4GHZ, SWL_FREQ_BAND_5GHZ, SWL_FREQ_BAND_6GHZ] else false
 */
bool swl_chanspec_isValidBand(swl_freqBand_e freqBand) {
    if((freqBand != SWL_FREQ_BAND_2_4GHZ) && (freqBand != SWL_FREQ_BAND_5GHZ)
       && (freqBand != SWL_FREQ_BAND_6GHZ)) {
        return false;
    }
    return true;
}

/**
 * Function checks whether freqBandExt has a valid frequency band value (2.4GHz, 5GHz, 6GHz)
 * @param freqBand: frequency Band
 * @return true if frequency Band is in [SWL_FREQ_BAND_EXT_2_4GHZ, SWL_FREQ_BAND_EXT_5GHZ, SWL_FREQ_BAND_EXT_6GHZ] else false
 */
bool swl_chanspec_isValidBandExt(swl_freqBandExt_e freqBandExt) {
    return swl_chanspec_isValidBand(swl_chanspec_freqBandExtToFreqBand(freqBandExt, SWL_FREQ_BAND_MAX, NULL));
}

/**
 * Returns a valid swl_freqBand_e extracted from the swl_chanspec_t parameter.
 * swl_chanspec_t->band's type is swl_freqBandExt_e, which is a longer enum than swl_freqBand_e
 *
 * @param chanSpec: channel specification
 * @param defaultFreqBand: the default swl_freqBand_e to return when chanSpec->band does not fit in swl_freqBand_e
 * @param hasMatch: optional, considered only if not NULL; set to true or false,depending on successful fit
 * @return: the matching swl_freqBand_e, else the default parameter value
 */
swl_freqBand_e swl_chanspec_getFreq(swl_chanspec_t* chanSpec, swl_freqBand_e defaultFreqBand, bool* hasMatch) {
    if(hasMatch != NULL) {     // when chanspec is NULL
        *hasMatch = false;
    }
    ASSERTS_NOT_NULL(chanSpec, defaultFreqBand, ME, "null chanSpec, default returned");
    return swl_chanspec_freqBandExtToFreqBand(chanSpec->band, defaultFreqBand, hasMatch);
}

/**
 * Deduces a valid frequency band when the base channel argument matches only one frequency band channel list.
 *
 * @param baseChannel: base (primary) channel
 * @return: the matching swl_freqBandExt_e,
 *          SWL_FREQ_BAND_EXT_AUTO value when channel has multiple matches,
 *          or SWL_FREQ_BAND_EXT_NONE when channel has no matches
 */
swl_freqBandExt_e swl_chanspec_freqBandExtFromBaseChannel(swl_channel_t baseChannel) {
    if(swl_channel_is6g(baseChannel)) {
        //Freq Band 6GHz has few shared channels index, with freq band 2.4GHz and 5GHz
        if(swl_channel_is2g(baseChannel) || swl_channel_is5g(baseChannel)) {
            return SWL_FREQ_BAND_EXT_AUTO;
        }
        return SWL_FREQ_BAND_EXT_6GHZ;
    }
    if(swl_channel_is5g(baseChannel)) {
        return SWL_FREQ_BAND_EXT_5GHZ;
    }
    if(swl_channel_is2g(baseChannel)) {
        return SWL_FREQ_BAND_EXT_2_4GHZ;
    }
    return SWL_FREQ_BAND_EXT_NONE;
}

/**
 * Converts a valid swl_freqBandExt_e into an swl_freqBand_e value.
 * swl_freqBandExt_e is a longer enum like swl_freqBand_e, only values fitting in swl_freqBand_e are considered.
 *
 * @param chanSpec: freqBandExt the extended freqBand enum
 * @param defaultFreqBand: returned when conversion is impossible
 * @param hasMatch: optional, considered only if not NULL; set to true or false, depending on conversion success
 * @return: the converted swl_freqBand_e, if any, else the default parameter value
 */
swl_freqBand_e swl_chanspec_freqBandExtToFreqBand(swl_freqBandExt_e freqBandExt, swl_freqBand_e defaultFreqBand, bool* hasMatch) {
    bool match = false;
    swl_freqBand_e matchedBand = defaultFreqBand;

    if(freqBandExt < (swl_freqBandExt_e) SWL_FREQ_BAND_MAX) {
        match = true;
        matchedBand = (swl_freqBand_e) freqBandExt;
    }

    if(hasMatch != NULL) {
        *hasMatch = match;
    }

    return matchedBand;
}

/**
 * Get the operating classe that encompass a given primary channel and that identify its location.
 *
 * @param channel: the channel number (primary or center)
 * @param band: the frequecy band where to look for the channel
 * @param bandwidth: the bandwidth of operating class
 * @return swl_operatingClass_t value, 0 if not found
 */
swl_operatingClass_t swl_chanspec_getOperClassDirect(swl_channel_t channel, swl_freqBandExt_e band, swl_bandwidth_e bandwidth) {

    swl_chanspec_t chanSpec;
    memset(&chanSpec, 0, sizeof(swl_chanspec_t));
    chanSpec.channel = channel;
    chanSpec.bandwidth = bandwidth;
    chanSpec.band = band;
    swl_channel_t channelToUse = ((bandwidth == SWL_BW_80MHZ || bandwidth == SWL_BW_160MHZ ) ? swl_chanspec_getCentreChannel(&chanSpec) : channel);
    for(uint32_t i = 0; i < SWL_ARRAY_SIZE(sSwl_operatingClassInfoGlobal); i++) {
        if((sSwl_operatingClassInfoGlobal[i].bandwidth == bandwidth) &&
           (sSwl_operatingClassInfoGlobal[i].band == band)) {
            swl_channel_t* channels = sSwl_operatingClassInfoGlobal[i].channels;
            if(channels == NULL) {
                continue;
            }

            for(uint8_t c = 0; channels[c] != 0; c++) {
                if(channels[c] == channelToUse) {
                    return sSwl_operatingClassInfoGlobal[i].operClass;
                }
            }
        }
    }

    return 0;
}

/**
 * Get the operating classe that encompass a given primary channel and that identify its location.
 *
 * @param chanSpec
 * @return the global operating class
 */
swl_operatingClass_t swl_chanspec_getOperClass(swl_chanspec_t* chanSpec) {
    return swl_chanspec_getOperClassDirect(chanSpec->channel, chanSpec->band, chanSpec->bandwidth);
}
/**
 * Get the operating classe that encompass a given primary channel and that identify its location.
 *
 * @param chanSpec
 * @param countryIndex: the country index,USA=0,EU=1,JP=2,CN=3
 * @return the local operating class for the given country index value, the global operting class if not found
 */
swl_operatingClass_t swl_chanspec_getLocalOperClass(swl_chanspec_t* chanSpec, swl_opClassCountry_e countryIndex) {
    swl_operatingClass_t globalOperClass = swl_chanspec_getOperClassDirect(chanSpec->channel, chanSpec->band, chanSpec->bandwidth);
    if((globalOperClass > 0) && (countryIndex < SWL_OP_CLASS_COUNTRY_MAX)) {
        for(uint32_t i = 0; i < SWL_ARRAY_SIZE(s_operClassTranslationTable); i++) {
            if(s_operClassTranslationTable[i].global == globalOperClass) {
                return s_operClassTranslationTable[i].local_set[countryIndex];
            }
        }
    }
    SAH_TRACEZ_ERROR(ME, "no local operatingclass found for global value (%d)", globalOperClass);
    return 0;
}

SWL_TABLE(swl_bwToNbOfChans,
          ARR(swl_bandwidth_e bandwidth; uint8_t nbChans; ),
          ARR(&gtSwl_type_bandwidth.enumType, swl_type_uint8),
          ARR({SWL_BW_AUTO, 1},
              {SWL_BW_20MHZ, 1},
              {SWL_BW_40MHZ, 2},
              {SWL_BW_80MHZ, 4},
              {SWL_BW_160MHZ, 8})
          );

/**
 * Return the amount of 20MHz channels in a given band.
 */
uint8_t swl_chanspec_getNrChannelsInBand(const swl_chanspec_t* chanspec) {
    if(chanspec->band != SWL_FREQ_BAND_EXT_2_4GHZ) {
        uint8_t* val = (uint8_t*) swl_table_getMatchingValue(&swl_bwToNbOfChans, 1, 0, &chanspec->bandwidth);
        return val != NULL ? *val : 0;
    } else {
        if((chanspec->bandwidth == SWL_BW_20MHZ) || (chanspec->bandwidth == SWL_BW_AUTO)) {
            return 1;
        } else if(chanspec->bandwidth == SWL_BW_40MHZ) {
            return 5;
        }
    }
    SAH_TRACEZ_ERROR(ME, "Unknown frequency band (%d)", chanspec->band);
    return 0;
}

/**
 * @brief return the "base channel" of a given chanspec
 * If unable to convert the chanspec, SWL_CHANNEL_INVALID is returned.
 */
swl_channel_t swl_chanspec_getBaseChannel(const swl_chanspec_t* chanspec) {
    swl_channel_t channel = chanspec->channel;
    if(chanspec->band == SWL_FREQ_BAND_EXT_6GHZ) {
        uint32_t nrChans = swl_chanspec_getNrChannelsInBand(chanspec);
        if(nrChans == 0) {
            SAH_TRACEZ_ERROR(ME, "can't get base %u %u", channel, chanspec->bandwidth);
            return SWL_CHANNEL_INVALID;
        }

        return channel - ((channel - 1) % (nrChans * SWL_CHANNEL_INCREMENT));

    } else if(chanspec->band == SWL_FREQ_BAND_EXT_5GHZ) {
        uint32_t nrChans = swl_chanspec_getNrChannelsInBand(chanspec);
        if(nrChans == 0) {
            SAH_TRACEZ_ERROR(ME, "can't get base %u %u", chanspec->channel, chanspec->bandwidth);
            return channel;
        }
        if(channel >= 149) {
            return channel - ((channel - 149) % (nrChans * SWL_CHANNEL_INCREMENT));
        } else {
            return channel - ((channel - 36) % (nrChans * SWL_CHANNEL_INCREMENT));
        }
    } else {
        //2.4GHz
        if((chanspec->bandwidth == SWL_BW_40MHZ) && (chanspec->channel > 6)) {
            return channel - 4;
        } else {
            return channel;
        }
    }
}

swl_channel_t swl_chanspec_getCentreChannel(const swl_chanspec_t* chanspec) {
    swl_channel_t centerChannel;
    swl_channel_t baseChannel = swl_chanspec_getBaseChannel(chanspec);
    uint32_t nrChannelsInBand = swl_chanspec_getNrChannelsInBand(chanspec);
    if(chanspec->band != SWL_FREQ_BAND_EXT_2_4GHZ) {
        if(nrChannelsInBand > 1) {
            centerChannel = baseChannel + (nrChannelsInBand / 2 * 4) - 2;
        } else {
            centerChannel = baseChannel;
        }
    } else {
        if(chanspec->bandwidth == SWL_BW_40MHZ) {
            centerChannel = baseChannel + 2;
        } else {
            centerChannel = baseChannel;
        }
    }
    return centerChannel;
}

/*
 * @brief fill a list with channels which are present in a chanspec
 *
 * @param chanspec: chanspec to retrieve channels
 * @param channelsList: channels in chanspec is added in the list
 * @param listSize : size of channelsList
 *
 * @return the number of channel added in channelsList
 */
uint8_t swl_chanspec_getChannelsInChanspec(const swl_chanspec_t* chanspec, swl_channel_t* channelsList, uint8_t listSize) {
    uint32_t nbChans = swl_chanspec_getNrChannelsInBand(chanspec);
    ASSERT_TRUE(nbChans <= listSize, 0, ME, "List size too small %u < %u", listSize, nbChans);
    if(chanspec->band != SWL_FREQ_BAND_EXT_2_4GHZ) {
        swl_channel_t baseChannel = swl_chanspec_getBaseChannel(chanspec);
        for(uint32_t i = 0; i < nbChans; i++) {
            channelsList[i] = baseChannel + i * 4;
        }
    } else {
        swl_channel_t channel = chanspec->channel;
        if((chanspec->bandwidth == SWL_BW_40MHZ) && (channel > 6)) {
            channel -= 4;
        }
        for(uint32_t i = 0; i < nbChans; i++) {
            channelsList[i] = channel + i;
        }
    }
    return nbChans;
}

/**
 * Returns true if the testChannel is in the band determing by the input channel and bandwidth.
 * Returns false otherwise.
 */
bool swl_channel_isInChanspec(const swl_chanspec_t* chanspec, const swl_channel_t testChannel) {
    swl_channel_t chanList[SWL_BW_CHANNELS_MAX];
    uint8_t nrChannels = swl_chanspec_getChannelsInChanspec(chanspec, chanList, SWL_ARRAY_SIZE(chanList));
    for(uint8_t i = 0; i < nrChannels; i++) {
        if(testChannel == chanList[i]) {
            return true;
        }
    }
    return false;
}

/*
 * @brief return the first channel of the complementary sub-band of a band
 * For 40MHz, return the first channel of the secondary 20MHz band (eg. 44/40, ret 48, or 1/40 ret 5 (2.4G))
 * For 80MHz, return the first channel of the secondary 40MHz band (eg. 48/80, ret 36 or 36/80 ret 44)
 * For 160MHz, return the first channel of the secondary 80MHz band (eg. 100/160, ret 116)
 *
 * @param chanspec to get the complementary base channel
 *
 * @return the complementary base channel or -1 if does not exist
 */
swl_channel_t swl_channel_getComplementaryBaseChannel(const swl_chanspec_t* chanspec) {
    if((chanspec->band == SWL_FREQ_BAND_EXT_2_4GHZ) || (chanspec->bandwidth <= SWL_BW_20MHZ)) {
        return -1;
    }
    swl_chanspec_t baseChanspec = SWL_CHANSPEC_NEW(swl_chanspec_getBaseChannel(chanspec), chanspec->bandwidth - 1, chanspec->band);
    if(swl_channel_isInChanspec(&baseChanspec, chanspec->channel)) {
        uint32_t nrChannels = swl_chanspec_getNrChannelsInBand(&baseChanspec);
        return baseChanspec.channel + nrChannels * SWL_CHANNEL_INCREMENT;
    } else {
        return baseChanspec.channel;
    }
}

/*
 * @brief Get the channel spec (band, channel number) from central frequency (in Mega Hertz).
 * Note that this will always return a chanspec with "auto" bandwidth, and just provides
 * The centre channel value. Starting at 5955MHz we start at 6GHz, while technically it could also be a 5GHz channel
 *
 * @param freq central frequency (in Mega Hertz)
 * @param pChanSpec pointer to chanspec struct to be filled.
 *
 * @return SWL_RC_OK in case success
 *         <= SWL_RC_ERROR otherwise
 */
swl_rc_ne swl_chanspec_channelFromMHz(swl_chanspec_t* pChanSpec, uint32_t freqMHz) {
    ASSERTS_NOT_NULL(pChanSpec, SWL_RC_INVALID_PARAM, ME, "NULL");
    swl_chanspec_t chanspec = {
        .channel = 0,
        .band = SWL_FREQ_BAND_EXT_AUTO,
        .bandwidth = SWL_BW_AUTO,
    };
    uint32_t rem = 0;
    /* see 802.11 17.3.8.3.2 and Annex J */
    if(freqMHz == SWL_CHANNEL_2G_FREQ_END) {
        chanspec.band = SWL_FREQ_BAND_EXT_2_4GHZ;
        chanspec.channel = SWL_CHANNEL_2G_END;
    } else if((freqMHz >= SWL_CHANNEL_2G_FREQ_START) && (freqMHz < SWL_CHANNEL_2G_FREQ_END)) {
        chanspec.band = SWL_FREQ_BAND_EXT_2_4GHZ;
        chanspec.channel = (freqMHz - SWL_CHANNEL_2G_FREQ_START) / SWL_CHANNEL_INTER_FREQ_5MHZ;
        rem = (freqMHz - SWL_CHANNEL_2G_FREQ_START) % SWL_CHANNEL_INTER_FREQ_5MHZ;
    } else if((freqMHz > SWL_CHANNEL_5G_FREQ_START) && (freqMHz < SWL_CHANNEL_6G_FREQ_START)) {
        chanspec.band = SWL_FREQ_BAND_EXT_5GHZ;
        chanspec.channel = (freqMHz - SWL_CHANNEL_5G_FREQ_START) / SWL_CHANNEL_INTER_FREQ_5MHZ;
        rem = (freqMHz - SWL_CHANNEL_5G_FREQ_START) % SWL_CHANNEL_INTER_FREQ_5MHZ;
    } else if((freqMHz >= (SWL_CHANNEL_6G_FREQ_START + SWL_CHANNEL_INTER_FREQ_5MHZ)) && (freqMHz <= SWL_CHANNEL_6G_FREQ_END)) {
        /* see 802.11ax D6.1 27.3.22.2 */
        chanspec.band = SWL_FREQ_BAND_EXT_6GHZ;
        chanspec.channel = (freqMHz - SWL_CHANNEL_6G_FREQ_START) / SWL_CHANNEL_INTER_FREQ_5MHZ;
        rem = (freqMHz - SWL_CHANNEL_6G_FREQ_START) % SWL_CHANNEL_INTER_FREQ_5MHZ;
    }
    ASSERTS_EQUALS(rem, 0, SWL_RC_ERROR, ME, "not matching any channel");
    ASSERTS_NOT_EQUALS(chanspec.channel, 0, SWL_RC_ERROR, ME, "not matching any channel");
    *pChanSpec = chanspec;
    return SWL_RC_OK;
}

/**
 * @brief convert the channel / band to freqHz. Note that the bandwidth is
 * NOT taken into account.
 *
 * Legal values taken from IEEE standard. Note that for 5GHz channels 191 and above, this
 * function will provide a frequency as stated in standard, while reverse function will return a 6GHz channel.
 *
 * @param pChanSpec: the chanspec to convert
 * @param freqHz: the output parameter to which the result will be written.
 *
 */
swl_rc_ne swl_chanspec_channelToMHz(const swl_chanspec_t* pChanSpec, uint32_t* freqMHz) {
    ASSERTS_NOT_NULL(pChanSpec, SWL_RC_INVALID_PARAM, ME, "NULL");
    ASSERTS_NOT_NULL(freqMHz, SWL_RC_INVALID_PARAM, ME, "NULL");

    if(pChanSpec->band == SWL_FREQ_BAND_EXT_2_4GHZ) {
        ASSERT_TRUE(pChanSpec->channel > SWL_CHANNEL_INVALID && pChanSpec->channel <= SWL_CHANNEL_2G_END, SWL_RC_INVALID_PARAM, ME, "Invalid channel %u in band %u", pChanSpec->channel, pChanSpec->band);
        if(pChanSpec->channel == SWL_CHANNEL_2G_END) {
            *freqMHz = SWL_CHANNEL_2G_FREQ_END;
            return SWL_RC_OK;
        } else {
            *freqMHz = SWL_CHANNEL_2G_FREQ_START + (SWL_CHANNEL_INTER_FREQ_5MHZ * pChanSpec->channel);
            return SWL_RC_OK;
        }
    } else if(pChanSpec->band == SWL_FREQ_BAND_EXT_5GHZ) {
        ASSERT_TRUE(pChanSpec->channel > SWL_CHANNEL_INVALID && pChanSpec->channel <= 200, SWL_RC_INVALID_PARAM, ME, "Invalid channel %u in band %u", pChanSpec->channel, pChanSpec->band);
        *freqMHz = SWL_CHANNEL_5G_FREQ_START + (SWL_CHANNEL_INTER_FREQ_5MHZ * pChanSpec->channel);
        return SWL_RC_OK;
    } else if(pChanSpec->band == SWL_FREQ_BAND_EXT_6GHZ) {
        ASSERT_TRUE(pChanSpec->channel > SWL_CHANNEL_INVALID && pChanSpec->channel <= SWL_CHANNEL_6G_END, SWL_RC_INVALID_PARAM, ME, "Invalid channel %u in band %u", pChanSpec->channel, pChanSpec->band);
        *freqMHz = SWL_CHANNEL_6G_FREQ_START + (pChanSpec->channel * SWL_CHANNEL_INTER_FREQ_5MHZ);
        return SWL_RC_OK;
    }

    SAH_TRACEZ_ERROR(ME, "Invalid band %u", pChanSpec->band);
    return SWL_RC_INVALID_PARAM;
}

/**
 * @brief provide the center frequency of the provided channel / band. In this function the bandwidth is
 * NOT taken into account. If conversion fails, then the default frequency is returned.
 *
 * Legal values taken from IEEE standard. Note that for 5GHz channels 191 and above, this
 * function will provide a frequency as stated in standard, while reverse function will return a 6GHz channel.
 *
 * @param pChanSpec: the chanspec to convert
 * @param defFreqMHz: if conversion of chanspec fails, this value is returned.
 *
 */
uint32_t swl_chanspec_channelToMHzDef(const swl_chanspec_t* pChanSpec, uint32_t defFreqMHz) {
    uint32_t freq = 0;
    swl_rc_ne retVal = swl_chanspec_channelToMHz(pChanSpec, &freq);
    if(retVal < 0) {
        return defFreqMHz;
    } else {
        return freq;
    }
}

/**
 * @brief provide the center frequency of the provided chanspec, including bandwidth.
 *
 * Legal values taken from IEEE standard. Note that for 5GHz channels 191 and above, this
 * function will provide a frequency as stated in standard, while reverse function will return a 6GHz channel.
 *
 * @param pChanSpec: the chanspec to convert
 * @param freqHz: the output parameter to which the result will be written.
 *
 */
swl_rc_ne swl_chanspec_toMHz(const swl_chanspec_t* pChanSpec, uint32_t* freqMHz) {
    ASSERTS_NOT_NULL(pChanSpec, SWL_RC_INVALID_PARAM, ME, "NULL");
    ASSERTS_NOT_NULL(freqMHz, SWL_RC_INVALID_PARAM, ME, "NULL");

    swl_chanspec_t tmpChanspec = *pChanSpec;
    tmpChanspec.channel = swl_chanspec_getCentreChannel(pChanSpec);
    return swl_chanspec_channelToMHz(&tmpChanspec, freqMHz);
}

/**
 * @brief provide the center frequency of the provided chanspec, including bandwidth.
 *
 * Legal values taken from IEEE standard. Note that for 5GHz channels 191 and above, this
 * function will provide a frequency as stated in standard, while reverse function will return a 6GHz channel.
 *
 * @param pChanSpec: the chanspec to convert
 * @param defFreqMHz: if conversion of chanspec fails, this value is returned.
 *
 */
uint32_t swl_chanspec_toMHzDef(const swl_chanspec_t* pChanSpec, uint32_t defFreqMHz) {
    ASSERT_NOT_NULL(pChanSpec, defFreqMHz, ME, "NULL");

    uint32_t freq = 0;
    swl_rc_ne retVal = swl_chanspec_toMHz(pChanSpec, &freq);
    if(retVal < 0) {
        return defFreqMHz;
    } else {
        return freq;
    }
}

typedef struct {
    uint32_t offset;
    uint32_t modulo;
    swl_bandwidth_e bw;
} swl_chanspec_offsetBw;

const swl_chanspec_offsetBw bwTable[SWL_BW_RAD_MAX] = {
    {0, 2, SWL_BW_20MHZ},
    {1, 4, SWL_BW_40MHZ},
    {3, 8, SWL_BW_80MHZ},
    {7, 16, SWL_BW_160MHZ},
};

/**
 * returns the bandwidth estimate based on the offset of the center channel from the base channel
 */
swl_bandwidth_e s_getBwFromOffset(uint32_t offset) {
    offset = offset / 2;

    for(uint32_t i = 0; i < SWL_BW_RAD_MAX; i++) {
        if((offset % bwTable[i].modulo) == bwTable[i].offset) {
            return bwTable[i].bw;
        }
    }
    return SWL_BW_AUTO;
}

/**
 * Returns the channel offset between the center channel and base channel, based on bandwidth.
 */
uint32_t s_getOffsetFromBw(swl_bandwidth_e bw) {
    for(uint32_t i = 0; i < SWL_ARRAY_SIZE(bwTable); i++) {
        if(bw == bwTable[i].bw) {
            return bwTable[i].offset * 2;
        }
    }
    return 0;
}

/**
 * Attempts to convert a frequency to a chanspec, including bandwidth.
 * As channel it will set the "first" primary channel.
 *
 * For 2.4GHz, this will assume 20MHz, as all channels can be 20MHz,
 * and all channels between 3 and 11 can be 40
 *
 * For 5 and 6GHz, this function will work by assuming that "middle channel frequency" actually
 * means the base channel + operatingChannelBandwidth. Note that this will then NOT provide a
 * primary channel.
 *
 * For 5GHz, this function will work for the "generally established" frequencies between:
 * * 36 and 64
 * * 100 and 144
 * * 149 and 177
 *
 */
swl_rc_ne swl_chanspec_fromMHz(swl_chanspec_t* pChanSpec, uint32_t freqMHz) {
    ASSERTS_NOT_NULL(pChanSpec, SWL_RC_INVALID_PARAM, ME, "NULL");

    swl_chanspec_t tmpChanspec;
    swl_rc_ne retVal = swl_chanspec_channelFromMHz(&tmpChanspec, freqMHz);
    ASSERTS_TRUE(retVal >= 0, retVal, ME, "ERROR");

    if(tmpChanspec.band == SWL_FREQ_BAND_EXT_2_4GHZ) {
        tmpChanspec.bandwidth = SWL_BW_20MHZ;


    } else if(tmpChanspec.band == SWL_FREQ_BAND_EXT_5GHZ) {
        if((tmpChanspec.channel >= 36) && (tmpChanspec.channel <= 64)) {
            uint32_t diff = tmpChanspec.channel - 36;
            tmpChanspec.bandwidth = s_getBwFromOffset(diff);
        } else if((tmpChanspec.channel >= 100) && (tmpChanspec.channel <= 144)) {
            uint32_t diff = tmpChanspec.channel - 100;
            tmpChanspec.bandwidth = s_getBwFromOffset(diff);
        } else if((tmpChanspec.channel >= 149) && (tmpChanspec.channel <= 177)) {
            uint32_t diff = tmpChanspec.channel - 149;
            tmpChanspec.bandwidth = s_getBwFromOffset(diff);
        } else {
            return SWL_RC_INVALID_PARAM;
        }
    } else if(tmpChanspec.band == SWL_FREQ_BAND_EXT_6GHZ) {
        tmpChanspec.bandwidth = s_getBwFromOffset(tmpChanspec.channel - 1);
    }
    ASSERTS_TRUE(tmpChanspec.bandwidth != SWL_BW_AUTO, SWL_RC_INVALID_PARAM, ME, "ERROR");
    tmpChanspec.channel = tmpChanspec.channel - (s_getOffsetFromBw(tmpChanspec.bandwidth));
    *pChanSpec = tmpChanspec;

    return SWL_RC_OK;
}

bool swl_channel_is2g(const swl_channel_t channel) {
    return ((channel >= SWL_CHANNEL_2G_START) && (channel <= SWL_CHANNEL_2G_END));
}

bool swl_channel_is5g(const swl_channel_t channel) {
    return (((((channel >= SWL_CHANNEL_5G_UNII_1_START) && (channel <= SWL_CHANNEL_5G_UNII_2A_END)) ||
              ((channel >= SWL_CHANNEL_5G_UNII_2C_START) && (channel <= SWL_CHANNEL_5G_UNII_2C_END))) && ((channel % 4) == 0))) ||
           (((channel >= SWL_CHANNEL_5G_UNII_3_START) && (channel <= SWL_CHANNEL_5G_UNII_4_END)) && ((channel % 4) == 1));
}

bool swl_channel_is6g(const swl_channel_t channel) {
    return (((channel >= SWL_CHANNEL_6G_START) && (channel <= SWL_CHANNEL_6G_END)) &&
            (channel % 4) == 1);
}

bool swl_channel_isDfs(const swl_channel_t channel) {
    ASSERTS_TRUE(swl_channel_is5g(channel), false, ME, "Not 5GHz channel");
    return (channel >= SWL_CHANNEL_5G_DFS_START) && (channel <= SWL_CHANNEL_5G_DFS_END);
}

bool swl_chanspec_isDfs(const swl_chanspec_t chanspec) {
    ASSERTS_TRUE(chanspec.band == SWL_FREQ_BAND_EXT_5GHZ, false, ME, "Not 5GHz chanspec");
    if((chanspec.bandwidth == SWL_BW_160MHZ) && (chanspec.channel <= SWL_CHANNEL_5G_DFS_END)) {
        return true;
    }
    return swl_channel_isDfs(chanspec.channel);
}

bool swl_channel_isWeather(const swl_channel_t channel) {
    ASSERTS_TRUE(swl_channel_is5g(channel), false, ME, "Not 5GHz channel");
    return (channel >= SWL_CHANNEL_5G_WEATHER_START) && (channel <= SWL_CHANNEL_5G_WEATHER_END);
}

bool swl_chanspec_isWeather(const swl_chanspec_t chanspec) {
    ASSERTS_TRUE(chanspec.band == SWL_FREQ_BAND_EXT_5GHZ, false, ME, "Not 5GHz chanspec");
    swl_channel_t channelsList[SWL_BW_CHANNELS_MAX];
    uint8_t nrChannels = swl_chanspec_getChannelsInChanspec(&chanspec, channelsList, SWL_BW_CHANNELS_MAX);
    for(uint8_t i = 0; i < nrChannels; i++) {
        if(swl_channel_isWeather(channelsList[i])) {
            return true;
        }
    }
    return false;
}

bool swl_channel_isHighPower(const swl_channel_t channel) {
    ASSERTS_TRUE(swl_channel_is5g(channel), false, ME, "Not 5GHz channel");
    return (channel >= SWL_CHANNEL_5G_UNII_2C_START) && (channel <= SWL_CHANNEL_5G_UNII_4_END);
}

bool swl_chanspec_isHighPower(const swl_chanspec_t chanspec) {
    ASSERTS_TRUE(chanspec.band == SWL_FREQ_BAND_EXT_5GHZ, false, ME, "Not 5GHz chanspec");
    return swl_channel_isHighPower(chanspec.channel);
}

