#include <stdint.h>

extern const int32_t cmTestArea;

int32_t cmTestFunc(void)
{
    return cmTestArea;
}
