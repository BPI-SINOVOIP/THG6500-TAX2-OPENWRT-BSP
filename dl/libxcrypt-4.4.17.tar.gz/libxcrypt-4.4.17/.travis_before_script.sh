#!/bin/bash
set -e

./autogen.sh
