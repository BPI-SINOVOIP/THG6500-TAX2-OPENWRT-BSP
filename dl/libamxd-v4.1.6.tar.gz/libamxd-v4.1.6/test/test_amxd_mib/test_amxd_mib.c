/****************************************************************************
**
** Copyright (c) 2020 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <cmocka.h>
#include <string.h>

#include <amxc/amxc.h>
#include <amxp/amxp_signal.h>
#include <amxp/amxp_slot.h>

#include <amxd/amxd_common.h>
#include <amxd/amxd_dm.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_parameter.h>
#include <amxd/amxd_function.h>
#include <amxd/amxd_action.h>
#include <amxd/amxd_mib.h>

#include <amxd_priv.h>

#include "test_amxd_mib.h"

#include <amxc/amxc_macros.h>
static amxd_dm_t dm;

static void test_event_handler(const char* const sig_name,
                               UNUSED const amxc_var_t* const data,
                               void* const priv) {
    int* counter = (int*) priv;

    if(strcmp(sig_name, "dm:mib-added") == 0) {
        (*counter)++;
    }

    if(strcmp(sig_name, "dm:mib-removed") == 0) {
        (*counter)--;
    }
}

static amxd_object_t* test_build_dm(void) {
    amxd_object_t* object = NULL;
    amxd_param_t* param = NULL;
    amxd_function_t* func = NULL;
    amxd_object_t* templ_obj = NULL;

    assert_int_equal(amxd_dm_init(&dm), 0);

    assert_int_equal(amxd_object_new(&object, amxd_object_singleton, "TestObject"), 0);
    assert_int_equal(amxd_dm_add_root_object(&dm, object), 0);

    assert_int_equal(amxd_param_new(&param, "Param1", AMXC_VAR_ID_CSTRING), 0);
    assert_int_equal(amxd_object_add_param(object, param), 0);
    assert_int_equal(amxd_param_new(&param, "Param2", AMXC_VAR_ID_BOOL), 0);
    assert_int_equal(amxd_object_add_param(object, param), 0);
    amxd_function_new(&func, "Func1", AMXC_VAR_ID_CSTRING, NULL);
    assert_int_equal(amxd_object_add_function(object, func), 0);

    assert_int_equal(amxd_object_new(&templ_obj, amxd_object_template, "TemplObject"), 0);
    assert_int_equal(amxd_param_new(&param, "Param1", AMXC_VAR_ID_CSTRING), 0);
    assert_int_equal(amxd_object_add_param(templ_obj, param), 0);
    amxd_function_new(&func, "Func1", AMXC_VAR_ID_CSTRING, NULL);
    assert_int_equal(amxd_object_add_function(templ_obj, func), 0);
    assert_int_equal(amxd_object_add_object(object, templ_obj), 0);

    return object;
}

void test_can_define_and_store_mib(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* fetch_mib = NULL;
    amxd_object_t* object = NULL;
    amxd_param_t* param = NULL;

    test_build_dm();

    assert_int_equal(amxd_mib_new(&mib, "TestMib"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);
    fetch_mib = amxd_dm_get_mib(&dm, "TestMib");
    assert_ptr_not_equal(fetch_mib, NULL);
    assert_ptr_equal(fetch_mib, mib);

    assert_int_equal(amxd_mib_new(&mib, "TestMib"), 0);
    assert_int_not_equal(amxd_dm_store_mib(&dm, mib), 0);
    amxd_mib_delete(&mib);

    assert_int_equal(amxd_mib_new(&mib, "TestMib2"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);

    assert_int_not_equal(amxd_dm_store_mib(NULL, mib), 0);
    assert_int_not_equal(amxd_dm_store_mib(&dm, NULL), 0);
    assert_int_equal(amxd_object_new(&object, amxd_object_singleton, "NotAMib"), 0);
    assert_int_not_equal(amxd_dm_store_mib(&dm, object), 0);

    assert_ptr_equal(amxd_dm_get_mib(&dm, "NotStoredMib"), NULL);
    assert_ptr_equal(amxd_dm_get_mib(NULL, "TestMib"), NULL);
    assert_ptr_equal(amxd_dm_get_mib(&dm, ""), NULL);
    assert_ptr_equal(amxd_dm_get_mib(&dm, NULL), NULL);

    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);
    fetch_mib = amxd_dm_get_mib(&dm, "TestMib2");
    assert_ptr_not_equal(fetch_mib, NULL);
    assert_ptr_equal(fetch_mib, mib);

    amxd_object_delete(&mib);
    amxd_object_delete(&object);
    amxd_dm_clean(&dm);
}

void test_can_add_remove_mib_to_from_object(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* object = NULL;
    amxd_object_t* child = NULL;
    amxd_param_t* param = NULL;
    amxd_function_t* func = NULL;

    object = test_build_dm();

    assert_int_equal(amxd_mib_new(&mib, "TestMib"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_function_new(&func, "MibFunc1", AMXC_VAR_ID_NULL, NULL), 0);
    assert_int_equal(amxd_object_add_function(mib, func), 0);
    assert_int_equal(amxd_object_new(&child, amxd_object_singleton, "MibObject"), 0);
    assert_int_equal(amxd_object_add_object(mib, child), 0);

    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_equal(amxd_object_add_mib(object, "TestMib"), 0);
    assert_true(amxd_object_has_mib(object, "TestMib"));
    assert_ptr_not_equal(amxd_object_get_param_def(object, "MibParam1"), NULL);
    assert_ptr_not_equal(amxd_object_get_function(object, "MibFunc1"), NULL);
    assert_ptr_not_equal(amxd_object_get_child(object, "MibObject"), NULL);
    assert_int_not_equal(amxd_object_add_mib(object, "TestMib"), 0);
    assert_true(amxd_object_has_mib(object, "TestMib"));

    assert_int_equal(amxd_object_remove_mib(object, "TestMib"), 0);
    assert_false(amxd_object_has_mib(object, "TestMib"));
    assert_ptr_equal(amxd_object_get_param_def(object, "MibParam1"), NULL);
    assert_ptr_equal(amxd_object_get_function(object, "MibFunc1"), NULL);
    assert_ptr_equal(amxd_object_get_child(object, "MibObject"), NULL);
    assert_int_equal(amxd_object_remove_mib(object, "TestMib"), 0);

    assert_int_equal(amxd_object_add_mib(object, "TestMib"), 0);
    assert_int_not_equal(amxd_object_add_mib(object, "TestMib"), 0);

    amxd_dm_clean(&dm);
}

void test_can_add_multiple_mibs(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* object = NULL;
    amxd_param_t* param = NULL;

    object = test_build_dm();

    assert_int_equal(amxd_mib_new(&mib, "TestMib1"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_equal(amxd_mib_new(&mib, "TestMib2"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam2", AMXC_VAR_ID_CSTRING), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_equal(amxd_object_add_mib(object, "TestMib1"), 0);
    assert_int_equal(amxd_object_add_mib(object, "TestMib2"), 0);
    assert_true(amxd_object_has_mib(object, "TestMib1"));
    assert_true(amxd_object_has_mib(object, "TestMib2"));
    assert_false(amxd_object_has_mib(object, "NotExisting"));
    assert_ptr_not_equal(amxd_object_get_param_def(object, "MibParam1"), NULL);
    assert_ptr_not_equal(amxd_object_get_param_def(object, "MibParam2"), NULL);

    assert_int_equal(amxd_object_remove_mib(object, "TestMib1"), 0);
    assert_false(amxd_object_has_mib(object, "TestMib1"));
    assert_true(amxd_object_has_mib(object, "TestMib2"));
    assert_false(amxd_object_has_mib(object, "NotExisting"));
    assert_ptr_equal(amxd_object_get_param_def(object, "MibParam1"), NULL);
    assert_ptr_not_equal(amxd_object_get_param_def(object, "MibParam2"), NULL);

    assert_int_equal(amxd_object_add_mib(object, "TestMib1"), 0);
    assert_true(amxd_object_has_mib(object, "TestMib1"));
    assert_true(amxd_object_has_mib(object, "TestMib2"));
    assert_false(amxd_object_has_mib(object, "NotExisting"));
    assert_ptr_not_equal(amxd_object_get_param_def(object, "MibParam1"), NULL);
    assert_ptr_not_equal(amxd_object_get_param_def(object, "MibParam2"), NULL);

    assert_int_equal(amxd_object_remove_mib(object, "TestMib2"), 0);
    assert_true(amxd_object_has_mib(object, "TestMib1"));
    assert_false(amxd_object_has_mib(object, "TestMib2"));
    assert_false(amxd_object_has_mib(object, "NotExisting"));
    assert_ptr_not_equal(amxd_object_get_param_def(object, "MibParam1"), NULL);
    assert_ptr_equal(amxd_object_get_param_def(object, "MibParam2"), NULL);

    assert_int_not_equal(amxd_object_add_mib(object, "NotExisting"), 0);

    amxd_dm_clean(&dm);
}

void test_add_mib_fails_when_duplicates(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* object = NULL;
    amxd_param_t* param = NULL;

    object = test_build_dm();

    assert_int_equal(amxd_mib_new(&mib, "TestMib1"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "Param1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_not_equal(amxd_object_add_mib(object, "TestMib1"), 0);
    assert_false(amxd_object_has_mib(object, "TestMib1"));
    assert_ptr_not_equal(amxd_object_get_param_def(object, "Param1"), NULL);

    amxd_dm_clean(&dm);
}

void test_add_mib_fails_when_object_not_in_dm(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* object = NULL;
    amxd_param_t* param = NULL;

    assert_int_equal(amxd_dm_init(&dm), 0);

    assert_int_equal(amxd_object_new(&object, amxd_object_singleton, "TestObject"), 0);

    assert_int_equal(amxd_mib_new(&mib, "TestMib1"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "Param1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_not_equal(amxd_object_add_mib(object, "TestMib1"), 0);
    assert_false(amxd_object_has_mib(object, "TestMib1"));
    assert_ptr_equal(amxd_object_get_param_def(object, "Param1"), NULL);

    amxd_object_delete(&object);
    amxd_dm_clean(&dm);
}

void test_functions_check_input_args(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* object = NULL;

    assert_int_not_equal(amxd_mib_new(NULL, "TestMib1"), 0);
    assert_int_not_equal(amxd_mib_new(&mib, ""), 0);
    assert_int_not_equal(amxd_mib_new(&mib, "12345"), 0);
    assert_int_not_equal(amxd_mib_new(&mib, "A.b,%t"), 0);
    assert_int_not_equal(amxd_mib_new(&mib, NULL), 0);

    object = test_build_dm();
    assert_false(amxd_object_has_mib(NULL, "TestMib1"));
    assert_false(amxd_object_has_mib(object, ""));
    assert_false(amxd_object_has_mib(object, NULL));

    assert_int_not_equal(amxd_object_add_mib(object, NULL), 0);
    assert_int_not_equal(amxd_object_add_mib(object, ""), 0);
    assert_int_not_equal(amxd_object_add_mib(NULL, ""), 0);

    assert_int_not_equal(amxd_object_remove_mib(object, NULL), 0);
    assert_int_not_equal(amxd_object_remove_mib(object, ""), 0);
    assert_int_not_equal(amxd_object_remove_mib(NULL, ""), 0);

    amxd_dm_clean(&dm);
}

void test_get_root_of_mib_is_null(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* mib_object = NULL;
    amxd_param_t* param = NULL;

    test_build_dm();

    assert_int_equal(amxd_mib_new(&mib, "TestMib"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_object_new(&mib_object, amxd_object_singleton, "MibChild"), 0);
    assert_int_equal(amxd_object_add_object(mib, mib_object), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_ptr_equal(amxd_object_get_root(mib), NULL);

    amxd_dm_clean(&dm);
}

void test_set_attrs_on_mib_fails(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* mib_object = NULL;
    amxd_param_t* param = NULL;

    test_build_dm();

    assert_int_equal(amxd_mib_new(&mib, "TestMib"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_object_new(&mib_object, amxd_object_singleton, "MibChild"), 0);
    assert_int_equal(amxd_object_add_object(mib, mib_object), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_not_equal(amxd_object_set_attr(mib, amxd_oattr_read_only, true), 0);
    assert_int_equal(amxd_object_set_attr(mib_object, amxd_oattr_read_only, true), 0);

    amxd_dm_clean(&dm);
}

void test_add_mib_to_object_fails_when_leads_to_function_duplicate(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* mib_object = NULL;
    amxd_object_t* object = NULL;
    amxd_param_t* param = NULL;
    amxd_function_t* func = NULL;

    object = test_build_dm();

    assert_int_equal(amxd_mib_new(&mib, "TestMib"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_object_new(&mib_object, amxd_object_singleton, "MibChild"), 0);
    assert_int_equal(amxd_object_add_object(mib, mib_object), 0);
    amxd_function_new(&func, "Func1", AMXC_VAR_ID_CSTRING, NULL);
    assert_int_equal(amxd_object_add_function(mib, func), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_not_equal(amxd_object_add_mib(object, "TestMib"), 0);

    amxd_dm_clean(&dm);
}

void test_add_mib_can_override_function(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* object = NULL;
    amxd_object_t* instance = NULL;
    amxd_function_t* func = NULL;

    test_build_dm();

    object = amxd_dm_findf(&dm, "TestObject.TemplObject");
    assert_ptr_not_equal(object, NULL);
    assert_int_equal(amxd_object_new_instance(&instance, object, NULL, 0, NULL), 0);

    assert_int_equal(amxd_mib_new(&mib, "TestMib"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    amxd_function_new(&func, "Func1", AMXC_VAR_ID_CSTRING, NULL);
    assert_int_equal(amxd_object_add_function(mib, func), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_equal(amxd_object_add_mib(instance, "TestMib"), 0);

    amxd_dm_clean(&dm);
}

void test_add_mib_to_instance(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* object = NULL;
    amxd_object_t* instance = NULL;
    amxd_param_t* param = NULL;

    test_build_dm();

    object = amxd_dm_findf(&dm, "TestObject.TemplObject");
    assert_ptr_not_equal(object, NULL);
    assert_int_equal(amxd_object_new_instance(&instance, object, NULL, 0, NULL), 0);

    assert_int_equal(amxd_mib_new(&mib, "TestMib1"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_equal(amxd_mib_new(&mib, "TestMib2"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam2", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_param_set_attr(param, amxd_pattr_template, true), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_equal(amxd_object_add_mib(instance, "TestMib1"), 0);
    param = amxd_object_get_param_def(instance, "MibParam1");
    assert_non_null(param);

    assert_int_equal(amxd_object_add_mib(instance, "TestMib2"), 0);
    param = amxd_object_get_param_def(instance, "MibParam2");
    assert_null(param);

    amxd_dm_clean(&dm);
}

void test_mib_not_removed_when_not_added(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* object = NULL;
    amxd_param_t* param = NULL;

    object = test_build_dm();

    assert_int_equal(amxd_mib_new(&mib, "TestMib"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_equal(amxd_mib_new(&mib, "TestMib2"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_equal(amxd_object_add_mib(object, "TestMib"), 0);
    assert_true(amxd_object_has_mib(object, "TestMib"));
    assert_ptr_not_equal(amxd_object_get_param_def(object, "MibParam1"), NULL);

    assert_false(amxd_object_has_mib(object, "TestMib2"));
    assert_int_equal(amxd_object_remove_mib(object, "TestMib2"), 0);
    assert_ptr_not_equal(amxd_object_get_param_def(object, "MibParam1"), NULL);

    amxd_dm_clean(&dm);
}

void test_mib_events(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* object = NULL;
    amxd_object_t* instance = NULL;
    amxd_param_t* param = NULL;
    int counter = 0;

    test_build_dm();

    amxp_slot_connect_filtered(&dm.sigmngr, "dm:mib-*", NULL, test_event_handler, &counter);

    object = amxd_dm_findf(&dm, "TestObject.TemplObject");
    assert_ptr_not_equal(object, NULL);
    assert_int_equal(amxd_object_new_instance(&instance, object, NULL, 0, NULL), 0);

    assert_int_equal(amxd_mib_new(&mib, "TestMib1"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MibParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_equal(amxd_object_add_mib(instance, "TestMib1"), 0);
    while(amxp_signal_read() == 0) {
    }
    assert_int_equal(counter, 1);

    assert_int_equal(amxd_object_remove_mib(instance, "TestMib1"), 0);
    while(amxp_signal_read() == 0) {
    }
    assert_int_equal(counter, 0);

    amxd_dm_clean(&dm);
}

void test_add_mib_object_can_be_read_using_name_path(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* object = NULL;
    amxd_param_t* param = NULL;
    amxd_object_t* instance = NULL;
    amxc_var_t ret;
    amxc_var_t args;

    amxc_var_init(&ret);
    amxc_var_init(&args);

    object = test_build_dm();

    assert_int_equal(amxd_mib_new(&mib, "TestMib1"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_param_new(&param, "MParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(mib, param), 0);
    assert_int_equal(amxd_object_new(&object, amxd_object_singleton, "TestObj"), 0);
    assert_int_equal(amxd_param_new(&param, "MParam1", AMXC_VAR_ID_UINT32), 0);
    assert_int_equal(amxd_object_add_param(object, param), 0);
    assert_int_equal(amxd_object_add_object(mib, object), 0);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    object = amxd_dm_findf(&dm, "TestObject.TemplObject");
    assert_ptr_not_equal(object, NULL);
    assert_int_equal(amxd_object_new_instance(&instance, object, "TestInstance", 0, NULL), 0);
    assert_int_equal(amxd_object_add_mib(instance, "TestMib1"), 0);
    assert_true(amxd_object_has_mib(instance, "TestMib1"));
    assert_ptr_not_equal(amxd_object_get_param_def(object, "Param1"), NULL);

    object = amxd_dm_findf(&dm, "TestObject.");
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "rel_path", "TemplObject.TestInstance.TestObj.");
    assert_int_equal(amxd_object_invoke_function(object, "_get", &args, &ret), 0);

    amxd_dm_clean(&dm);

    amxc_var_clean(&ret);
    amxc_var_clean(&args);
}

void test_object_get_mibs(UNUSED void** state) {
    amxd_object_t* mib = NULL;
    amxd_object_t* object = NULL;
    char* mib_names = NULL;

    object = test_build_dm();

    assert_int_equal(amxd_mib_new(&mib, "TestMib"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    assert_int_equal(amxd_mib_new(&mib, "TestMib2"), 0);
    assert_ptr_not_equal(mib, NULL);
    assert_int_equal(amxd_object_get_type(mib), amxd_object_mib);
    assert_int_equal(amxd_dm_store_mib(&dm, mib), 0);

    mib_names = amxd_object_get_mibs(object);
    assert_null(mib_names);

    assert_int_equal(amxd_object_add_mib(object, "TestMib"), 0);
    assert_true(amxd_object_has_mib(object, "TestMib"));

    mib_names = amxd_object_get_mibs(object);
    assert_non_null(mib_names);
    assert_string_equal(mib_names, "TestMib");
    free(mib_names);

    assert_int_equal(amxd_object_add_mib(object, "TestMib2"), 0);
    assert_true(amxd_object_has_mib(object, "TestMib2"));

    mib_names = amxd_object_get_mibs(object);
    assert_non_null(mib_names);
    assert_string_equal(mib_names, "TestMib TestMib2");
    free(mib_names);

    assert_int_equal(amxd_object_remove_mib(object, "TestMib"), 0);
    assert_false(amxd_object_has_mib(object, "TestMib"));

    mib_names = amxd_object_get_mibs(object);
    assert_non_null(mib_names);
    assert_string_equal(mib_names, "TestMib2");
    free(mib_names);

    assert_int_equal(amxd_object_remove_mib(object, "TestMib2"), 0);
    assert_false(amxd_object_has_mib(object, "TestMib2"));

    mib_names = amxd_object_get_mibs(object);
    assert_null(mib_names);

    amxd_dm_clean(&dm);
}
