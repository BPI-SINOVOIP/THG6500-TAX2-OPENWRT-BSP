#if !defined(__AMXM_PRIV_H__)
#define __AMXM_PRIV_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <string.h>

#include <amxc/amxc_macros.h>

#ifndef when_str_too_big
#define when_str_too_big(x, s, l) if(strlen(x) > s) { goto l; }
#endif

int PRIVATE amxm_add_so(amxm_shared_object_t* const so);
void PRIVATE amxm_so_remove_all_mods(amxm_shared_object_t* so);
bool PRIVATE amxm_contains_so(const amxm_shared_object_t* const so);
int PRIVATE amxm_so_close_internal(amxm_shared_object_t** so);

#ifdef __cplusplus
}
#endif

#endif // __AMXM_PRIV_H__
