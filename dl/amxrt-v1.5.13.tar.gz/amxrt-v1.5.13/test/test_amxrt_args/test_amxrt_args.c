/****************************************************************************
**
** Copyright (c) 2020 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>

#include "test_amxrt_args.h"
#include "args.h"
#include "config.h"

static amxo_parser_t parser;
static amxrt_state_t amxrt_state;

amxrt_state_t amxrt_get_state(void) {
    return amxrt_state;
}

void amxrt_set_state(amxrt_state_t s) {
    amxrt_state = s;
}

amxo_parser_t* amxrt_get_parser(void) {
    return &parser;
}

amxd_dm_t* amxrt_get_dm(void) {
    return NULL;
}

void test_can_print_help(UNUSED void** state) {
    char* argv[] = { "amxrt", "-h" };

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv) / sizeof(argv[0]), argv), -1);

    config_clean();
    amxo_parser_clean(&parser);
}

void test_can_print_extended_help(UNUSED void** state) {
    char* argv[] = { "amxrt", "-H" };

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv) / sizeof(argv[0]), argv), -1);

    config_clean();
    amxo_parser_clean(&parser);
}

void test_can_enable_dm_events(UNUSED void** state) {
    char* argv[] = { "amxrt", "-E", "" };

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv) / sizeof(argv[0]), argv), 2);
    assert_true(GET_BOOL(&parser.config, COPT_EVENT));
    config_clean();
    amxo_parser_clean(&parser);
}

void test_can_overwrite_option(UNUSED void** state) {
    char* argv2[] = {"amxrt", "-o cfg-dir=my_cfg_dir", "-o", "daemon=no"};

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 4);
    assert_string_equal(GET_CHAR(&parser.config, COPT_CFG_DIR), "my_cfg_dir");
    assert_string_equal(GET_CHAR(&parser.config, COPT_DAEMON), "no");

    config_clean();
    amxo_parser_clean(&parser);
}

void test_can_accept_option(UNUSED void** state) {
    char* argv2[] = {"amxrt", "-o option=new_option", "-o", "text=hallo", "-D"};

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 5);
    assert_string_equal(GET_CHAR(&parser.config, "option"), "new_option");
    assert_string_equal(GET_CHAR(&parser.config, "text"), "hallo");

    config_clean();
    amxo_parser_clean(&parser);
}

void test_ignores_invalid_options(UNUSED void** state) {
    char* argv[] = {"amxrt", "-o", "-D"};
    char* argv2[] = {"amxrt", "-o option"};

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv) / sizeof(argv[0]), argv2), 2);
    assert_null(GET_CHAR(&parser.config, "option"));

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 2);
    assert_null(GET_CHAR(&parser.config, "option"));

    args_parser_option(&parser.config, "", false);

    config_clean();
    amxo_parser_clean(&parser);
}

void test_can_add_include_dir(UNUSED void** state) {
    char* argv2[] = {"amxrt", "-I/home/me/somedir", "-I", "/tmp/sub_dir"};
    const amxc_llist_t* inc_dirs = NULL;
    amxc_var_t* dir = NULL;

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 4);
    inc_dirs = amxc_var_constcast(amxc_llist_t, GET_ARG(&parser.config, COPT_INCDIRS));
    assert_non_null(inc_dirs);
    amxc_var_dump(&parser.config, STDOUT_FILENO);
    assert_int_equal(amxc_llist_size(inc_dirs), 3);
    dir = amxc_var_from_llist_it(amxc_llist_it_get_next(amxc_llist_get_first(inc_dirs)));
    assert_non_null(dir);
    assert_string_equal(amxc_var_constcast(cstring_t, dir), "/home/me/somedir");
    dir = amxc_var_from_llist_it(amxc_llist_get_last(inc_dirs));
    assert_non_null(dir);
    assert_string_equal(amxc_var_constcast(cstring_t, dir), "/tmp/sub_dir");

    config_clean();
    amxo_parser_clean(&parser);
}

void test_can_add_import_dir(UNUSED void** state) {
    char* argv2[] = {"amxrt", "-L/home/me/somedir", "-L", "/tmp/sub_dir"};
    const amxc_llist_t* imp_dirs = NULL;
    amxc_var_t* dir = NULL;

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 4);
    imp_dirs = amxc_var_constcast(amxc_llist_t, GET_ARG(&parser.config, COPT_LIBDIRS));
    assert_non_null(imp_dirs);
    amxc_var_dump(&parser.config, STDOUT_FILENO);
    assert_int_equal(amxc_llist_size(imp_dirs), 3);
    dir = amxc_var_from_llist_it(amxc_llist_it_get_next(amxc_llist_get_first(imp_dirs)));
    assert_non_null(dir);
    assert_string_equal(amxc_var_constcast(cstring_t, dir), "/home/me/somedir");
    dir = amxc_var_from_llist_it(amxc_llist_get_last(imp_dirs));
    assert_non_null(dir);
    assert_string_equal(amxc_var_constcast(cstring_t, dir), "/tmp/sub_dir");

    config_clean();
    amxo_parser_clean(&parser);
}

void test_can_load_shared_object(UNUSED void** state) {
    char* argv2[] = {"amxrt", "-Bmyfile1.so", "-B", "myfile2.so"};
    const amxc_llist_t* backends = NULL;
    amxc_var_t* backend = NULL;

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 4);
    backends = amxc_var_constcast(amxc_llist_t, GET_ARG(&parser.config, COPT_BACKENDS));
    assert_non_null(backends);
    assert_int_equal(amxc_llist_size(backends), 2);
    backend = amxc_var_from_llist_it(amxc_llist_get_first(backends));
    assert_non_null(backend);
    assert_string_equal(amxc_var_constcast(cstring_t, backend), "myfile1.so");
    backend = amxc_var_from_llist_it(amxc_llist_get_last(backends));
    assert_non_null(backend);
    assert_string_equal(amxc_var_constcast(cstring_t, backend), "myfile2.so");

    config_clean();
    amxo_parser_clean(&parser);
}

void test_can_add_uri(UNUSED void** state) {
    char* argv2[] = {"amxrt", "-upcb:/var/run/pcb_sys", "-u", "/var/run/ubus/ubus.sock"};
    const amxc_llist_t* backends = NULL;
    amxc_var_t* backend = NULL;

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 4);
    backends = amxc_var_constcast(amxc_llist_t, GET_ARG(&parser.config, COPT_URIS));
    assert_non_null(backends);
    assert_int_equal(amxc_llist_size(backends), 2);
    backend = amxc_var_from_llist_it(amxc_llist_get_first(backends));
    assert_non_null(backend);
    assert_string_equal(amxc_var_constcast(cstring_t, backend), "pcb:/var/run/pcb_sys");
    backend = amxc_var_from_llist_it(amxc_llist_get_last(backends));
    assert_non_null(backend);
    assert_string_equal(amxc_var_constcast(cstring_t, backend), "/var/run/ubus/ubus.sock");

    config_clean();
    amxo_parser_clean(&parser);
}

void test_can_parse_no_arguments(UNUSED void** state) {
    char* argv2[] = {"amxrt", "-A", "-C", "-D", "-N"};

    bool no_detect = NULL;
    bool no_connect = NULL;
    bool daemon = NULL;
    bool pid_file = NULL;

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 5);

    no_detect = amxc_var_constcast(bool, GET_ARG(&parser.config, COPT_AUTO_DETECT));
    assert_false(no_detect);
    no_connect = amxc_var_constcast(bool, GET_ARG(&parser.config, COPT_AUTO_CONNECT));
    assert_false(no_connect);
    daemon = amxc_var_constcast(bool, GET_ARG(&parser.config, COPT_DAEMON));
    assert_true(daemon);
    pid_file = amxc_var_constcast(bool, GET_ARG(&parser.config, COPT_PID_FILE));
    assert_false(pid_file);

    config_clean();
    amxo_parser_clean(&parser);
}

void test_can_set_priority_level(UNUSED void** state) {
    char* argv2[] = {"amxrt", "-p1"};
    char* argv3[] = {"amxrt", "-p", "2"};

    uint32_t priority = 0;

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 2);

    priority = amxc_var_constcast(uint32_t, GET_ARG(&parser.config, COPT_PRIORITY));
    assert_int_equal(priority, 1);

    config_clean();
    amxo_parser_clean(&parser);

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv3) / sizeof(argv3[0]), argv3), 3);

    priority = amxc_var_constcast(uint32_t, GET_ARG(&parser.config, COPT_PRIORITY));
    assert_int_equal(priority, 2);

    config_clean();
    amxo_parser_clean(&parser);
}

void test_can_set_odl(UNUSED void** state) {
    char* argv2[] = {"amxrt", "-OMyODL"};
    char* argv3[] = {"amxrt", "-O", "MyODL"};

    const cstring_t ODL = 0;

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 2);

    ODL = amxc_var_constcast(cstring_t, GET_ARG(&parser.config, COPT_ODL));
    assert_string_equal(ODL, "MyODL");

    config_clean();
    amxo_parser_clean(&parser);

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv3) / sizeof(argv3[0]), argv3), 3);

    ODL = amxc_var_constcast(cstring_t, GET_ARG(&parser.config, COPT_ODL));
    assert_string_equal(ODL, "MyODL");

    config_clean();
    amxo_parser_clean(&parser);
}

void test_wrong_argument(UNUSED void** state) {
    char* argv2[] = {"amxrt", "-Z"};

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 2);

    amxc_var_clean(&parser.config);
    config_clean();
    amxo_parser_clean(&parser);
}

void test_read_env(UNUSED void** state) {
    const amxc_llist_t* list = NULL;
    amxc_var_t* var = NULL;
    const cstring_t prefix_path;

    amxo_parser_init(&parser);
    config_init(&parser);

    args_read_env_var(&parser.config, "THIS_ENV_VARIABLE_DOES_NOT_EXISTS", COPT_BACKENDS, AMXC_VAR_ID_LIST);

    putenv("AMXB_BACKENDS=myfile.so");

    args_read_env_var(&parser.config, "AMXB_BACKENDS", COPT_BACKENDS, AMXC_VAR_ID_LIST);

    list = amxc_var_constcast(amxc_llist_t, GET_ARG(&parser.config, COPT_BACKENDS));
    assert_non_null(list);
    assert_int_equal(amxc_llist_size(list), 1);
    var = amxc_var_from_llist_it(amxc_llist_get_first(list));
    assert_non_null(var);
    assert_string_equal(amxc_var_constcast(cstring_t, var), "myfile.so");

    putenv("AMXRT_PREFIX_PATH=/my/prefix/path");

    args_read_env_var(&parser.config, "AMXRT_PREFIX_PATH", COPT_PREFIX_PATH, AMXC_VAR_ID_CSTRING);

    prefix_path = amxc_var_constcast(cstring_t, GET_ARG(&parser.config, COPT_PREFIX_PATH));
    assert_string_equal(prefix_path, "/my/prefix/path");

    config_clean();
    amxo_parser_clean(&parser);
}

void test_read_env_non_existing_config_option(UNUSED void** state) {
    const amxc_llist_t* list = NULL;
    amxc_var_t* var = NULL;

    amxo_parser_init(&parser);
    config_init(&parser);

    putenv("AMXB_BACKENDS=myfile.so");

    args_read_env_var(&parser.config, "AMXB_BACKENDS", "NEW_OPTION", AMXC_VAR_ID_LIST);

    list = amxc_var_constcast(amxc_llist_t, GET_ARG(&parser.config, "NEW_OPTION"));
    assert_non_null(list);
    assert_int_equal(amxc_llist_size(list), 1);
    var = amxc_var_from_llist_it(amxc_llist_get_first(list));
    assert_non_null(var);
    assert_string_equal(amxc_var_constcast(cstring_t, var), "myfile.so");

    config_clean();
    amxo_parser_clean(&parser);
}

void test_read_env_new_config_option(UNUSED void** state) {
    const amxc_llist_t* list = NULL;
    amxc_var_t* var = NULL;

    amxo_parser_init(&parser);
    config_init(&parser);

    putenv("AMXB_BACKENDS=myfile.so");

    args_read_env_var(&parser.config, "AMXB_BACKENDS", "NEW_OPTION", AMXC_VAR_ID_LIST);

    list = amxc_var_constcast(amxc_llist_t, GET_ARG(&parser.config, "NEW_OPTION"));
    assert_non_null(list);
    assert_int_equal(amxc_llist_size(list), 1);
    var = amxc_var_from_llist_it(amxc_llist_get_first(list));
    assert_non_null(var);
    assert_string_equal(amxc_var_constcast(cstring_t, var), "myfile.so");

    config_clean();
    amxo_parser_clean(&parser);
}

void test_requires_objects_are_added_to_list(UNUSED void** state) {
    char* argv2[] = {"amxrt", "-R", "NetDev.", "-R", "NeMo."};
    const amxc_llist_t* required = NULL;

    amxo_parser_init(&parser);
    config_init(&parser);

    optind = 1;
    assert_int_equal(args_parse_cmd(&parser.config, sizeof(argv2) / sizeof(argv2[0]), argv2), 5);

    required = amxc_var_constcast(amxc_llist_t, GET_ARG(&parser.config, COPT_REQUIRES));
    assert_non_null(required);
    assert_false(amxc_llist_is_empty(required));
    assert_int_equal(amxc_llist_size(required), 2);

    amxc_var_clean(&parser.config);
    config_clean();
    amxo_parser_clean(&parser);
}