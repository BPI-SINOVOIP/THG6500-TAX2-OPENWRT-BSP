/****************************************************************************
**
** Copyright (c) 2020 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdlib.h>
#include <string.h>

#include <amxp/amxp_dir.h>

#include "main.h"

static amxc_var_t cmd_options;

static void config_read_env_vars(amxc_var_t* config) {
    args_read_env_var(config,
                      "AMXB_BACKENDS",
                      COPT_BACKENDS,
                      AMXC_VAR_ID_LIST);

    args_read_env_var(config,
                      "AMXRT_PREFIX_PATH",
                      COPT_PREFIX_PATH,
                      AMXC_VAR_ID_CSTRING);

    args_read_env_var(config,
                      "AMXRT_PLUGIN_DIR",
                      COPT_PLUGIN_DIR,
                      AMXC_VAR_ID_CSTRING);

    args_read_env_var(config,
                      "AMXRT_CFG_DIR",
                      COPT_CFG_DIR,
                      AMXC_VAR_ID_CSTRING);
}

static void config_add_dir(amxc_var_t* var_dirs, const char* dir) {
    bool found = false;
    const amxc_llist_t* dirs = amxc_var_constcast(amxc_llist_t, var_dirs);

    amxc_llist_for_each(it, dirs) {
        amxc_var_t* var_dir = amxc_var_from_llist_it(it);
        const char* stored_dir = amxc_var_constcast(cstring_t, var_dir);
        if((stored_dir != NULL) && (strcmp(dir, stored_dir) == 0)) {
            found = true;
            break;
        }
    }

    if(!found) {
        amxc_var_add(cstring_t, var_dirs, dir);
    }
}

static void config_set_default_dirs(amxo_parser_t* parser) {
    amxc_var_t* inc_dirs = amxo_parser_claim_config(parser, COPT_INCDIRS);
    amxc_var_t* lib_dirs = amxo_parser_claim_config(parser, COPT_LIBDIRS);
    amxc_var_t* mib_dirs = amxo_parser_claim_config(parser, COPT_MIBDIRS);

    config_add_dir(inc_dirs, ".");
    config_add_dir(inc_dirs, "${prefix}${cfg-dir}/${name}");
    config_add_dir(inc_dirs, "${prefix}${cfg-dir}/modules");

    config_add_dir(lib_dirs, "${prefix}${plugin-dir}/${name}");
    config_add_dir(lib_dirs, "${prefix}${plugin-dir}/modules");
    config_add_dir(lib_dirs, "${prefix}/usr/local/lib/amx/${name}");
    config_add_dir(lib_dirs, "${prefix}/usr/local/lib/amx/modules");

    config_add_dir(mib_dirs, "${prefix}${cfg-dir}/${name}/mibs");
}

// Config options are scoped within the odl file, so when an include is done,
// it is possible the config options are back to the original value
static void config_include_end(amxo_parser_t* parser,
                               UNUSED const char* file) {
    amxd_dm_t* dm = amxrt_get_dm();
    amxp_sigmngr_enable(&dm->sigmngr, GET_BOOL(&parser->config, COPT_EVENT));
}

// When a config section is done, check if any settings must be applied
static void config_section_end(amxo_parser_t* parser,
                               int section_id) {
    amxd_dm_t* dm = amxrt_get_dm();
    if(section_id == 0) {
        amxp_sigmngr_enable(&dm->sigmngr, GET_BOOL(&parser->config, COPT_EVENT));
    }
}

static void config_option_changed(amxo_parser_t* parser,
                                  UNUSED const char* option,
                                  UNUSED amxc_var_t* value) {
    amxc_var_for_each(cmd, &cmd_options) {
        const char* path = amxc_var_key(cmd);
        amxc_var_set_path(&parser->config, path, cmd, AMXC_VAR_FLAG_UPDATE | AMXC_VAR_FLAG_COPY);
    }
}

static amxo_hooks_t amxrt_hooks = {
    .it = { .next = NULL, .prev = NULL, .llist = NULL },
    .comment = NULL,
    .start = NULL,
    .end = NULL,
    .start_include = NULL,
    .end_include = config_include_end,
    .set_config = config_option_changed,
    .start_section = NULL,
    .end_section = config_section_end,
    .create_object = NULL,
    .add_instance = NULL,
    .select_object = NULL,
    .end_object = NULL,
    .add_param = NULL,
    .set_param = NULL,
    .end_param = NULL,
    .add_func = NULL,
    .add_func_arg = NULL,
    .end_func = NULL,
    .add_mib = NULL,
    .set_counter = NULL,
};

static int config_add_backend(const char* name, void* priv) {
    amxc_var_t* backends = (amxc_var_t*) priv;
    amxc_var_add(cstring_t, backends, name);

    return 0;
}

void config_init(amxo_parser_t* parser) {
    amxc_var_t* config = &parser->config;
    amxc_var_add_key(amxc_llist_t, config, COPT_BACKENDS, NULL);
    amxc_var_add_key(amxc_llist_t, config, COPT_URIS, NULL);
    amxc_var_add_key(bool, config, COPT_AUTO_DETECT, true);
    amxc_var_add_key(bool, config, COPT_AUTO_CONNECT, true);
    amxc_var_add_key(bool, config, COPT_DAEMON, false);
    amxc_var_add_key(uint32_t, config, COPT_PRIORITY, 0);
    amxc_var_add_key(bool, config, COPT_PID_FILE, true);
    amxc_var_add_key(cstring_t, config, COPT_PREFIX_PATH, "");
    amxc_var_add_key(cstring_t, config, COPT_PLUGIN_DIR, PLUGIN_DIR);
    amxc_var_add_key(cstring_t, config, COPT_CFG_DIR, CFG_DIR);
    amxc_var_add_key(amxc_llist_t, config, COPT_LIBDIRS, NULL);
    amxc_var_add_key(amxc_llist_t, config, COPT_INCDIRS, NULL);
    amxc_var_add_key(amxc_llist_t, config, COPT_MIBDIRS, NULL);
    amxc_var_add_key(amxc_llist_t, config, COPT_LISTEN, NULL);
    amxc_var_add_key(bool, config, COPT_EVENT, false);
    amxc_var_add_key(bool, config, COPT_DUMP_CONFIG, false);
    amxc_var_add_key(cstring_t, config, COPT_BACKENDS_DIR, BACKEND_DIR);
    amxc_var_add_key(cstring_t, config, COPT_STORAGE_TYPE, STORAGE_TYPE);
    amxc_var_add_key(bool, config, COPT_LOG, false);
    amxc_var_add_key(cstring_t, config, COPT_RW_DATA_PATH, "${prefix}" RWDATAPATH);
    amxc_var_add_key(cstring_t, config, COPT_STORAGE_DIR, "${rw_data_path}/${name}/");
    amxc_var_add_key(amxc_llist_t, config, COPT_REQUIRES, NULL);

    // set hooks to monitor config option changes
    amxo_parser_set_hooks(parser, &amxrt_hooks);
    // command line options given with -F are stored here and can not be overwritten
    // by odl config section options
    amxc_var_init(&cmd_options);
    amxc_var_set_type(&cmd_options, AMXC_VAR_ID_HTABLE);
}

void config_clean(void) {
    amxc_var_clean((&cmd_options));
}

int config_build(amxo_parser_t* parser,
                 int argc,
                 char* argv[],
                 int* index) {
    int retval = 0;
    char* base_name = NULL;

    config_read_env_vars(&parser->config);

    config_set_default_dirs(parser);

    base_name = strdup(basename(argv[0]));
    when_null(base_name, leave);
    for(int i = strlen(base_name) - 1; i > 0; i--) {
        if(base_name[i] == '.') {
            base_name[i] = 0;
        }
    }
    amxc_var_add_key(cstring_t, &parser->config, COPT_NAME, base_name);

    *index = args_parse_cmd(&parser->config, argc, argv);
    if(*index < 0) {
        retval = abs(*index);
        goto leave;
    }

    if(amxc_var_constcast(bool, GET_ARG(&parser->config, COPT_AUTO_DETECT))) {
        amxc_var_t* backends = GET_ARG(&parser->config, COPT_BACKENDS);
        const char* path = GET_CHAR(&parser->config, COPT_BACKENDS_DIR);
        amxp_dir_scan(path, "d_name matches '.*\\.so'", false, config_add_backend, backends);
        connection_detect_sockets(&parser->config);
    }

leave:
    free(base_name);
    return retval;
}

void config_add_cmd_option(const char* name, amxc_var_t* value) {
    amxc_var_set_key(&cmd_options, name, value, AMXC_VAR_FLAG_COPY | AMXC_VAR_FLAG_UPDATE);
}
