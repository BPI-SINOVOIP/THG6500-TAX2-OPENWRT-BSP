/****************************************************************************
**
** Copyright (c) 2020 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <syslog.h>

#include "main.h"

static int runtime_parse_odl_string(amxo_parser_t* parser,
                                    amxd_object_t* root) {
    const char* odl_str = NULL;
    int retval = 0;

    odl_str = amxc_var_constcast(cstring_t, GET_ARG(&parser->config, COPT_ODL));
    if(odl_str != NULL) {
        retval = amxo_parser_parse_string(parser, odl_str, root);
        if(retval != 0) {
            amxrt_print_failure(parser, odl_str);
        }
    }

    return retval;
}

static bool runtime_file_exists(const char* filename) {
    struct stat buffer;

    return (stat(filename, &buffer) == 0);
}

static void runtime_handle_events(amxd_dm_t* dm, amxo_parser_t* parser) {
    bool handle_events = GET_BOOL(&parser->config, COPT_HANDLE_EVENTS);

    if(handle_events) {
        while(amxp_signal_read() == 0) {
        }
    }
    amxp_sigmngr_trigger_signal(&dm->sigmngr, "app:start", NULL);
}

static int runtime_try_default_odl(amxo_parser_t* parser,
                                   amxd_object_t* root) {
    char* name = amxc_var_dyncast(cstring_t,
                                  GET_ARG(&parser->config,
                                          COPT_NAME));
    char* prefix = amxc_var_dyncast(cstring_t,
                                    GET_ARG(&parser->config,
                                            COPT_PREFIX_PATH));
    char* cfg_dir = amxc_var_dyncast(cstring_t,
                                     GET_ARG(&parser->config,
                                             COPT_CFG_DIR));
    int retval = 0;

    amxc_string_t include;
    amxc_string_init(&include, 32);
    amxc_string_appendf(&include,
                        "%s/%s/%s/%s.odl",
                        prefix,
                        cfg_dir,
                        name,
                        name);
    retval = amxo_parser_parse_file(parser,
                                    amxc_string_get(&include, 0),
                                    root);
    if(retval != 0) {
        amxrt_print_message("No ODL file(s) provided - tried to load %s",
                            amxc_string_get(&include, 0));
        amxrt_print_failure(parser, amxc_string_get(&include, 0));
    }
    amxc_string_clean(&include);

    free(cfg_dir);
    free(prefix);
    free(name);
    return retval;
}

static int runtime_parse_odl_files(amxo_parser_t* parser,
                                   int argc,
                                   char* argv[],
                                   int index,
                                   amxd_object_t* root) {
    int retval = 0;

    if(index >= argc) {
        retval = runtime_try_default_odl(parser, root);
    } else {
        while(index < argc) {
            retval = amxo_parser_parse_file(parser, argv[index++], root);
            if(retval != 0) {
                amxrt_print_failure(parser, argv[index - 1]);
                break;
            }
        }
    }

    return retval;
}

static int runtime_create_pid_file(pid_t pid,
                                   const char* name) {
    amxc_string_t pidfile;
    amxc_string_init(&pidfile, 64);
    int retval = -1;

    // create pidfile
    amxc_string_appendf(&pidfile, "/var/run/%s.pid", name);
    FILE* pf = fopen(amxc_string_get(&pidfile, 0), "w");
    if((pf == NULL) && (errno == EACCES)) {
        amxc_string_reset(&pidfile);
        amxc_string_appendf(&pidfile, "/var/run/%s/%s.pid", name, name);
        pf = fopen(amxc_string_get(&pidfile, 0), "w");
    }
    if(pf != NULL) {
        fprintf(pf, "%d", pid);
        fflush(pf);
        fclose(pf);
        retval = 0;
    } else {
        amxrt_print_error("Failed to create pidfile");
    }

    amxc_string_clean(&pidfile);
    return retval;
}

static void runtime_remove_pid_file(const char* name) {
    amxc_string_t pidfile;
    amxc_string_init(&pidfile, 64);

    amxc_string_appendf(&pidfile, "/var/run/%s.pid", name);
    if(!runtime_file_exists(amxc_string_get(&pidfile, 0))) {
        amxc_string_reset(&pidfile);
        amxc_string_appendf(&pidfile, "/var/run/%s/%s.pid", name, name);
    }

    if(runtime_file_exists(amxc_string_get(&pidfile, 0))) {
        unlink(amxc_string_get(&pidfile, 0));
    }

    amxc_string_clean(&pidfile);
}

int runtime_config_process(amxo_parser_t* parser) {
    int retval = 0;
    int pid = -1;
    bool pidfile = amxc_var_dyncast(bool,
                                    GET_ARG(&parser->config,
                                            COPT_PID_FILE));
    char* name = amxc_var_dyncast(cstring_t,
                                  GET_ARG(&parser->config,
                                          COPT_NAME));

    int priority = amxc_var_dyncast(uint32_t,
                                    GET_ARG(&parser->config,
                                            COPT_PRIORITY));

    if(amxc_var_constcast(bool, GET_ARG(&parser->config, COPT_DAEMON))) {
        WHEN_FAILED(daemon(1, 0), retval, leave);
    }

    pid = getpid();
    WHEN_FAILED(setpriority(PRIO_PROCESS, pid, priority), retval, leave);

    if(pidfile && (name != NULL)) {
        runtime_create_pid_file(pid, name);
    }

    if(GET_BOOL(&parser->config, COPT_LOG) &&
       ( GET_CHAR(&parser->config, COPT_NAME) != NULL)) {
        openlog(GET_CHAR(&parser->config, COPT_NAME), LOG_CONS | LOG_PID, LOG_USER);
        syslog(LOG_USER | LOG_INFO, "** MARK **");
    }

leave:
    free(name);
    return retval;
}

static void runtime_enable_syssigs(amxc_var_t* syssigs) {
    if(amxc_var_type_of(syssigs) == AMXC_VAR_ID_LIST) {
        amxc_var_for_each(var, syssigs) {
            uint32_t sigid = amxc_var_dyncast(uint32_t, var);
            if((sigid != 0) &&
               ( sigid != SIGALRM) &&
               ( sigid != SIGTERM) &&
               ( sigid != SIGINT)) {
                amxp_syssig_enable(sigid, true);
            }
        }
    } else {
        uint32_t sigid = amxc_var_dyncast(uint32_t, syssigs);
        if((sigid != 0) &&
           ( sigid != SIGALRM) &&
           ( sigid != SIGTERM) &&
           ( sigid != SIGINT)) {
            amxp_syssig_enable(sigid, true);
        }
    }
}

static int runtime_init(amxo_parser_t* parser,
                        amxd_dm_t* dm,
                        int argc,
                        char* argv[]) {
    int retval = 0;
    int index = 0;
    amxd_object_t* root = NULL;
    bool dm_eventing_enabled = false;
    amxc_var_t* syssigs = NULL;

    config_init(parser);

    amxp_sigmngr_add_signal(NULL, "connection-added");
    amxp_sigmngr_add_signal(NULL, "connection-wait-write");
    amxp_sigmngr_add_signal(NULL, "listen-added");
    amxp_sigmngr_add_signal(NULL, "connection-deleted");
    amxp_sigmngr_add_signal(NULL, "config:changed");
    amxp_sigmngr_add_signal(NULL, "wait:done");
    amxp_sigmngr_add_signal(NULL, "wait:cancel");

    WHEN_FAILED(config_build(parser, argc, argv, &index), retval, leave);

    dm_eventing_enabled = GET_BOOL(&parser->config, COPT_EVENT);
    amxp_sigmngr_enable(&dm->sigmngr, dm_eventing_enabled);
    root = amxd_dm_get_root(dm);
    WHEN_FAILED(runtime_parse_odl_string(parser, root), retval, leave);
    WHEN_FAILED(runtime_parse_odl_files(parser, argc, argv, index, root),
                retval,
                leave);
    amxo_parser_scan_mib_dirs(parser, NULL);
    amxp_sigmngr_enable(&dm->sigmngr, true);

    amxo_parser_add_entry_point(parser, amxrt_dm_main);

    WHEN_FAILED(connection_load_backends(&parser->config), retval, leave);

    WHEN_FAILED(connection_connect_all(parser), retval, leave);
    WHEN_FAILED(connection_listen_all(parser), retval, leave);
    WHEN_FAILED(runtime_config_process(parser), retval, leave);

    syssigs = GET_ARG(&parser->config, "system-signals");
    if(syssigs != NULL) {
        runtime_enable_syssigs(syssigs);
    }

leave:
    return retval;
}

static int runtime_register(amxo_parser_t* parser,
                            amxd_dm_t* dm) {
    int retval = 0;

    WHEN_FAILED(connection_register_dm(parser, dm), retval, leave);
    amxc_var_set(bool, GET_ARG(&parser->config, COPT_EVENT), true);
    if(parser->post_includes != NULL) {
        WHEN_FAILED(amxo_parser_invoke_entry_points(parser, dm, AMXO_START), retval, leave);
        WHEN_FAILED(amxo_parser_invoke_entry_points(parser, dm, AMXO_ODL_LOADED), retval, leave);
    } else {
        WHEN_FAILED(amxo_parser_invoke_entry_points(parser, dm, AMXO_START), retval, leave);
    }

leave:
    if(retval == 0) {
        amxrt_set_state(amxrt_state_running);
    } else {
        amxrt_set_state(amxrt_state_failed);
    }
    return retval;
}

static void runtime_wait_done(UNUSED const char* const s,
                              UNUSED const amxc_var_t* const d,
                              UNUSED void* const p) {
    amxo_parser_t* parser = amxrt_get_parser();
    amxd_dm_t* dm = amxrt_get_dm();
    amxc_var_t* req = GET_ARG(&parser->config, COPT_REQUIRES);

    amxc_var_clean(req);
    amxc_var_set_type(req, AMXC_VAR_ID_LIST);

    syslog(LOG_USER | LOG_INFO, "RunTime - All required objects available - continue");

    amxp_sigmngr_resume(&dm->sigmngr);

    if(runtime_register(parser, dm) != 0) {
        amxrt_print_error("Failed to register data model");
        syslog(LOG_USER | LOG_CRIT, "RunTime - Failed to register data model");
        el_stop();
    } else {
        runtime_handle_events(dm, parser);
        amxp_slot_disconnect(NULL, "wait:done", runtime_wait_done);
    }
}

int runtime_start(amxo_parser_t* parser,
                  amxd_dm_t* dm,
                  int argc,
                  char* argv[]) {
    int retval = 0;
    bool dump_config = false;
    amxc_var_t* req = NULL;
    const amxc_llist_t* lreq = NULL;

    WHEN_FAILED(runtime_init(parser, dm, argc, argv), retval, leave);
    WHEN_FAILED(el_create(parser), retval, leave);

    req = GET_ARG(&parser->config, COPT_REQUIRES);
    lreq = amxc_var_constcast(amxc_llist_t, req);

    if((lreq == NULL) || amxc_llist_is_empty(lreq)) {
        WHEN_FAILED(runtime_register(parser, dm), retval, leave);
        runtime_handle_events(dm, parser);
    } else {
        if(GET_BOOL(&parser->config, COPT_SUSPEND)) {
            amxp_sigmngr_suspend(&dm->sigmngr);
        }
        amxp_slot_connect(NULL, "wait:done", NULL, runtime_wait_done, NULL);
        amxc_var_for_each(path, req) {
            const char* txt_path = GET_CHAR(path, NULL);
            if(amxd_dm_findf(dm, "%s", txt_path) == NULL) {
                syslog(LOG_USER | LOG_NOTICE, "RunTime - Waiting for required object '%s'", txt_path);
                retval = amxb_wait_for_object(txt_path);
                if(retval != AMXB_STATUS_OK) {
                    syslog(LOG_USER | LOG_NOTICE, "RunTime - wait failed for object '%s'", txt_path);
                    break;
                }
            }
        }
    }

leave:
    if(retval != 0) {
        amxrt_set_state(amxrt_state_failed);
    }
    dump_config = GET_BOOL(&parser->config, COPT_DUMP_CONFIG);
    if(dump_config) {
        amxrt_print_configuration(&parser->config);
    }
    return retval;
}

int runtime_run(UNUSED amxo_parser_t* parser, amxd_dm_t* dm) {
    int retval = 0;

    el_start();
    amxp_sigmngr_trigger_signal(&dm->sigmngr, "app:stop", NULL);
    amxp_sigmngr_trigger_signal(NULL, "wait:cancel", NULL);

    return retval;
}

void runtime_stop(amxo_parser_t* parser, amxd_dm_t* dm) {
    char* name = amxc_var_dyncast(cstring_t,
                                  GET_ARG(&parser->config,
                                          COPT_NAME));
    amxc_var_t* req = GET_ARG(&parser->config, COPT_REQUIRES);

    el_destroy(parser);

    if((req == NULL) || amxc_llist_is_empty(amxc_var_constcast(amxc_llist_t, req))) {
        amxo_parser_rinvoke_entry_points(parser, dm, AMXO_STOP);
    }

    amxb_set_config(NULL);

    runtime_remove_pid_file(name);

    if(GET_BOOL(&parser->config, COPT_LOG) &&
       ( GET_CHAR(&parser->config, COPT_NAME) != NULL)) {
        closelog();
    }

    config_clean();

    amxrt_set_state(amxrt_state_stopped);

    free(name);
}
