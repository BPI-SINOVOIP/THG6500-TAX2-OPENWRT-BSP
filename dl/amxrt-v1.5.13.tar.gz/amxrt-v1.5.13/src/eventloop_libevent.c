/****************************************************************************
**
** Copyright (c) 2020 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <signal.h>

#include <event2/event.h>

#include "main.h"

#define UNUSED __attribute__((unused))

static struct event_base* base = NULL;
static struct event* signal_int = NULL;
static struct event* signal_term = NULL;
static struct event* signal_alarm = NULL;
static struct event* amxp_sig = NULL;
static struct event* amxp_syssig = NULL;

typedef struct _el_data {
    struct event* read;
    struct event* can_write;
} el_data_t;

static void el_signal_cb(UNUSED evutil_socket_t fd,
                         UNUSED short event,
                         UNUSED void* arg) {
    el_stop();
}

static void el_signal_timers(UNUSED evutil_socket_t fd,
                             UNUSED short event,
                             UNUSED void* arg) {
    amxp_timers_calculate();
    amxp_timers_check();
}

static void el_connection_read_cb(UNUSED evutil_socket_t fd,
                                  UNUSED short flags,
                                  void* arg) {
    amxo_connection_t* con = (amxo_connection_t*) arg;
    con->reader(fd, con->priv);
}

static void el_connection_can_write_cb(UNUSED evutil_socket_t fd,
                                       UNUSED short flags,
                                       void* arg) {
    amxo_connection_t* con = (amxo_connection_t*) arg;
    el_data_t* el_data = (el_data_t*) con->el_data;

    con->can_write(fd, con->priv);
    con->can_write = NULL;
    event_del(el_data->can_write);
    free(el_data->can_write);
    el_data->can_write = NULL;
}

static void el_amxp_signal_read_cb(UNUSED evutil_socket_t fd,
                                   UNUSED short flags,
                                   UNUSED void* arg) {
    amxp_signal_read();
}

static void el_amxp_syssignal_read_cb(UNUSED evutil_socket_t fd,
                                      UNUSED short flags,
                                      UNUSED void* arg) {
    amxp_syssig_read();
}

static void el_slot_add_fd(UNUSED const char* const sig_name,
                           const amxc_var_t* const data,
                           void* const priv) {
    amxo_parser_t* parser = (amxo_parser_t*) priv;
    amxo_connection_t* con = NULL;
    el_data_t* el_data = NULL;

    when_true(amxc_var_type_of(data) != AMXC_VAR_ID_FD, leave);

    con = amxo_connection_get(parser, amxc_var_constcast(fd_t, data));
    when_null(con, leave);

    el_data = (el_data_t*) calloc(1, sizeof(el_data_t));
    when_null(el_data, leave);
    el_data->read = event_new(base,
                              con->fd,
                              EV_READ | EV_PERSIST,
                              el_connection_read_cb,
                              con);
    con->el_data = el_data;
    event_add(el_data->read, NULL);

leave:
    return;
}

static void el_slot_wait_write_fd(UNUSED const char* const sig_name,
                                  const amxc_var_t* const data,
                                  void* const priv) {
    amxo_parser_t* parser = (amxo_parser_t*) priv;
    amxo_connection_t* con = NULL;
    el_data_t* el_data = NULL;

    when_true(amxc_var_type_of(data) != AMXC_VAR_ID_FD, leave);

    con = amxo_connection_get(parser, amxc_var_constcast(fd_t, data));
    when_null(con, leave);

    el_data = (el_data_t*) con->el_data;
    when_null(el_data, leave);
    el_data->can_write = event_new(base,
                                   con->fd,
                                   EV_WRITE,
                                   el_connection_can_write_cb,
                                   con);
    event_add(el_data->can_write, NULL);

leave:
    return;
}

static void el_slot_remove_fd(UNUSED const char* const sig_name,
                              const amxc_var_t* const data,
                              void* const priv) {
    amxo_parser_t* parser = (amxo_parser_t*) priv;
    amxc_llist_t* connections = amxo_parser_get_connections(parser);
    amxo_connection_t* con = NULL;

    when_true(amxc_var_type_of(data) != AMXC_VAR_ID_FD, leave);

    con = el_get_connection(connections, amxc_var_constcast(fd_t, data));
    when_null(con, leave);

    if(con->el_data != NULL) {
        el_data_t* el_data = (el_data_t*) con->el_data;
        if(el_data->read != NULL) {
            event_del(el_data->read);
            free(el_data->read);
        }
        if(el_data->can_write != NULL) {
            event_del(el_data->can_write);
            free(el_data->can_write);
        }
        free(el_data);
        con->el_data = NULL;
    }

leave:
    return;
}

static void el_add_read_fd(amxc_llist_t* connections) {
    amxc_llist_for_each(it, connections) {
        amxo_connection_t* con = amxc_llist_it_get_data(it, amxo_connection_t, it);
        el_data_t* el_data = (el_data_t*) calloc(1, sizeof(el_data_t));
        if(el_data != NULL) {
            el_data->read = event_new(base,
                                      con->fd,
                                      EV_READ | EV_PERSIST,
                                      el_connection_read_cb,
                                      con);
            event_add(el_data->read, NULL);
            con->el_data = el_data;
        }
    }
}

static void el_remove_fd(amxc_llist_t* connections) {
    amxc_llist_for_each(it, connections) {
        amxo_connection_t* con = amxc_llist_it_get_data(it, amxo_connection_t, it);
        el_data_t* el_data = (el_data_t*) con->el_data;
        if(el_data != NULL) {
            if(el_data->read != NULL) {
                event_del(el_data->read);
                free(el_data->read);
            }
            if(el_data->can_write != NULL) {
                event_del(el_data->can_write);
                free(el_data->can_write);
            }
            free(el_data);
            con->el_data = NULL;
        }
    }
}

int el_create(amxo_parser_t* parser) {
    int retval = -1;

    base = event_base_new();
    if(base == NULL) {
        printf("Creation of event base failed\n");
        EXIT(retval, 4, leave);
    }

    signal_int = evsignal_new(base,
                              SIGINT,
                              el_signal_cb,
                              NULL);
    event_add(signal_int, NULL);
    signal_term = evsignal_new(base,
                               SIGTERM,
                               el_signal_cb,
                               NULL);
    event_add(signal_term, NULL);
    signal_alarm = evsignal_new(base,
                                SIGALRM,
                                el_signal_timers,
                                NULL);
    event_add(signal_alarm, NULL);

    amxp_sig = event_new(base,
                         amxp_signal_fd(),
                         EV_READ | EV_PERSIST,
                         el_amxp_signal_read_cb,
                         NULL);
    event_add(amxp_sig, NULL);

    amxp_syssig = event_new(base,
                            amxp_syssig_get_fd(),
                            EV_READ | EV_PERSIST,
                            el_amxp_syssignal_read_cb,
                            NULL);
    event_add(amxp_syssig, NULL);

    el_add_read_fd(parser->connections);
    el_add_read_fd(parser->listeners);

    amxp_slot_connect(NULL, "connection-added", NULL, el_slot_add_fd, parser);
    amxp_slot_connect(NULL, "connection-wait-write", NULL, el_slot_wait_write_fd, parser);
    amxp_slot_connect(NULL, "listen-added", NULL, el_slot_add_fd, parser);
    amxp_slot_connect(NULL, "connection-deleted", NULL, el_slot_remove_fd, parser);

    retval = 0;
leave:
    return retval;
}

int el_start(void) {
    int retval = -1;
    if(base != NULL) {
        retval = event_base_dispatch(base);
    }
    return retval;
}

int el_stop(void) {
    int retval = -1;
    if(base != NULL) {
        retval = event_base_loopbreak(base);
    }
    return retval;
}

int el_destroy(amxo_parser_t* parser) {
    amxp_slot_disconnect(NULL, "connection-added", el_slot_add_fd);
    amxp_slot_disconnect(NULL, "listen-added", el_slot_add_fd);
    amxp_slot_disconnect(NULL, "connection-deleted", el_slot_remove_fd);

    if(signal_int != NULL) {
        event_del(signal_int);
    }
    if(signal_term != NULL) {
        event_del(signal_term);
    }
    if(signal_alarm != NULL) {
        event_del(signal_alarm);
    }

    if(amxp_sig != NULL) {
        event_del(amxp_sig);
    }

    if(amxp_syssig != NULL) {
        event_del(amxp_syssig);
    }

    el_remove_fd(parser->connections);
    el_remove_fd(parser->listeners);

    if(base != NULL) {
        event_base_free(base);
        base = NULL;
    }

    free(signal_term);
    signal_term = NULL;
    free(signal_int);
    signal_int = NULL;
    free(signal_alarm);
    signal_alarm = NULL;
    free(amxp_sig);
    amxp_sig = NULL;
    free(amxp_syssig);
    amxp_syssig = NULL;
    return 0;
}

amxo_connection_t* el_get_connection(amxc_llist_t* cons, int fd) {
    amxo_connection_t* con = NULL;
    amxc_llist_for_each(it, cons) {
        con = amxc_llist_it_get_data(it, amxo_connection_t, it);
        if(con->fd == fd) {
            break;
        }
        con = NULL;
    }

    return con;
}
