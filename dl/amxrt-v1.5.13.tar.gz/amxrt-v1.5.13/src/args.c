/****************************************************************************
**
** Copyright (c) 2020 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <getopt.h>

#include "main.h"

void args_parser_option(amxc_var_t* config,
                        const char* option,
                        bool force) {
    amxc_string_t str_option;
    amxc_llist_t options;
    amxc_string_t* name = NULL;
    amxc_string_t* value = NULL;
    amxc_var_t var_option;

    amxc_var_init(&var_option);
    amxc_llist_init(&options);
    amxc_string_init(&str_option, 0);

    amxc_string_set(&str_option, option);
    amxc_string_split_to_llist(&str_option, &options, '=');
    WHEN_TRUE(amxc_llist_is_empty(&options), leave);
    WHEN_TRUE(amxc_llist_size(&options) != 2, leave);

    name = amxc_string_from_llist_it(amxc_llist_get_first(&options));
    value = amxc_string_from_llist_it(amxc_llist_get_last(&options));

    amxc_string_trim(name, NULL);
    amxc_string_trim(value, NULL);

    if(amxc_var_set(jstring_t, &var_option, amxc_string_get(value, 0)) != 0) {
        amxc_var_set(cstring_t, &var_option, amxc_string_get(value, 0));
    } else {
        amxc_var_cast(&var_option, AMXC_VAR_ID_ANY);
    }

    amxc_var_set_path(config, amxc_string_get(name, 0), &var_option,
                      AMXC_VAR_FLAG_AUTO_ADD | AMXC_VAR_FLAG_COPY);

    if(force) {
        config_add_cmd_option(amxc_string_get(name, 0), &var_option);
    }

leave:
    amxc_string_clean(&str_option);
    amxc_llist_clean(&options, amxc_string_list_it_free);
    amxc_var_clean(&var_option);
    return;
}

int args_parse_cmd(amxc_var_t* config,
                   int argc,
                   char** argv) {
    int c;

    while(1) {
        int option_index = 0;

        static struct option long_options[] = {
            {"help", no_argument, 0, 'h' },
            {"HELP", no_argument, 0, 'H' },
            {"backend", required_argument, 0, 'B' },
            {"uri", required_argument, 0, 'u' },
            {"no-auto-detect", no_argument, 0, 'A' },
            {"no-connect", no_argument, 0, 'C' },
            {"include-dir", required_argument, 0, 'I' },
            {"import-dir", required_argument, 0, 'L' },
            {"option", required_argument, 0, 'o' },
            {"forced-option", required_argument, 0, 'F' },
            {"ODL", required_argument, 0, 'O' },
            {"daemon", no_argument, 0, 'D' },
            {"priority", required_argument, 0, 'p' },
            {"no-pid-file", no_argument, 0, 'N' },
            {"eventing", no_argument, 0, 'E'},
            {"dump-config", no_argument, 0, 'd'},
            {"log", no_argument, 0, 'l'},
            {"requires", required_argument, 0, 'R'},
            {0, 0, 0, 0 }
        };

        c = getopt_long(argc, argv, "hHB:u:ACI:L:o:F:O:Dp:NEdlR:",
                        long_options, &option_index);
        if(c == -1) {
            break;
        }

        switch(c) {
        case 'I':
            amxc_var_add(cstring_t, GET_ARG(config, COPT_INCDIRS), optarg);
            break;

        case 'L':
            amxc_var_add(cstring_t, GET_ARG(config, COPT_LIBDIRS), optarg);
            break;

        case 'B':
            amxc_var_add(cstring_t, GET_ARG(config, COPT_BACKENDS), optarg);
            break;

        case 'u':
            amxc_var_add(cstring_t, GET_ARG(config, COPT_URIS), optarg);
            break;

        case 'A': {
            amxc_var_t* var = GET_ARG(config, COPT_AUTO_DETECT);
            amxc_var_set(bool, var, false);
        }
        break;

        case 'C': {
            amxc_var_t* var = GET_ARG(config, COPT_AUTO_CONNECT);
            amxc_var_set(bool, var, false);
        }
        break;

        case 'D': {
            amxc_var_t* var = GET_ARG(config, COPT_DAEMON);
            amxc_var_set(bool, var, true);
        }
        break;

        case 'E': {
            amxc_var_t* var = GET_ARG(config, COPT_EVENT);
            amxc_var_set(bool, var, true);
        }
        break;

        case 'd': {
            amxc_var_t* var = GET_ARG(config, COPT_DUMP_CONFIG);
            amxc_var_set(bool, var, true);
        }
        break;

        case 'p': {
            amxc_var_t* var = GET_ARG(config, COPT_PRIORITY);
            amxc_var_set(uint32_t, var, atoi(optarg));
        }
        break;

        case 'N': {
            amxc_var_t* var = GET_ARG(config, COPT_PID_FILE);
            amxc_var_set(bool, var, false);
        }
        break;

        case 'o':
            args_parser_option(config, optarg, false);
            break;

        case 'F':
            args_parser_option(config, optarg, true);
            break;

        case 'O':
            amxc_var_add_key(cstring_t, config, COPT_ODL, optarg);
            break;

        case 'h': {
            amxc_var_t* dump_config = GET_ARG(config, COPT_DUMP_CONFIG);
            amxrt_print_usage(argc, argv);
            amxc_var_set(bool, dump_config, false);
            return -1;
        }
        break;

        case 'H': {
            amxc_var_t* dump_config = GET_ARG(config, COPT_DUMP_CONFIG);
            amxrt_print_help(argc, argv);
            amxc_var_set(bool, dump_config, true);
            return -1;
        }
        break;

        case 'l': {
            amxc_var_t* var = GET_ARG(config, COPT_LOG);
            amxc_var_set(bool, var, true);
        }
        break;

        case 'R': {
            amxc_var_add(cstring_t, GET_ARG(config, COPT_REQUIRES), optarg);
        }
        break;

        default:
            amxrt_print_error("Argument not recognized - 0%x %c ", c, c);
        }
    }

    return optind;
}

void args_read_env_var(amxc_var_t* config,
                       const char* var_name,
                       const char* config_name,
                       int32_t var_type) {
    const char* env = getenv(var_name);
    amxc_var_t* coption = GET_ARG(config, config_name);
    amxc_var_t var_env;

    amxc_var_init(&var_env);

    if(env == NULL) {
        goto exit;
    }

    amxc_var_set(cstring_t, &var_env, env);

    if(coption == NULL) {
        coption = amxc_var_add_new_key(config, config_name);
        amxc_var_set_type(coption, var_type);
    }

    switch(var_type) {
    case AMXC_VAR_ID_LIST: {
        amxc_string_t* str_env = amxc_var_take(amxc_string_t, &var_env);
        amxc_llist_t parts;
        amxc_llist_init(&parts);
        amxc_string_split_to_llist(str_env, &parts, ';');
        amxc_llist_for_each(it, (&parts)) {
            amxc_string_t* part = amxc_string_from_llist_it(it);
            amxc_var_add(cstring_t, coption, amxc_string_get(part, 0));
            amxc_string_delete(&part);
        }
        amxc_llist_clean(&parts, amxc_string_list_it_free);
        amxc_string_delete(&str_env);
    }
    break;
    default: {
        amxc_var_convert(coption, &var_env, var_type);
    }
    break;
    }

exit:
    amxc_var_clean(&var_env);
    return;
}
