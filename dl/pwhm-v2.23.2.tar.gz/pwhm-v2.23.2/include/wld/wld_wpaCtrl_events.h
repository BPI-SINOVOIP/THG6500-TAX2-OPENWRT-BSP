/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#ifndef __WLD_WPA_CTRL_EVENTS_H__
#define __WLD_WPA_CTRL_EVENTS_H__

#include "swla/swla_chanspec.h"
#include "swla/swla_mac.h"
#include "swl/swl_ieee802_1x_defs.h"
#include "swl/swl_80211.h"
#include "swl/swl_returnCode.h"

typedef struct {
    uint8_t opclass;
    uint8_t channel;
    uint64_t startTime;
    uint16_t duration;
    uint8_t frameInfo;
    uint8_t rcpi;
    uint8_t rsni;
    uint8_t bssid[6];
    uint8_t antennaId;
    uint32_t parentTsf;
} __attribute__((packed)) wld_wpaCtrl_rrmBeaconRsp_t;

typedef void (* wld_wpaCtrl_processMsgCb_f)(void* userData, char* ifName, char* msgData);

typedef void (* wld_wpaCtrl_wpsSuccessMsg_f)(void* userData, char* ifName, swl_macChar_t* mac);
typedef void (* wld_wpaCtrl_wpsTimeoutMsg_f)(void* userData, char* ifName);
typedef void (* wld_wpaCtrl_wpsCancelMsg_f)(void* userData, char* ifName);
typedef void (* wld_wpaCtrl_wpsOverlapMsg_f)(void* userData, char* ifName);
typedef void (* wld_wpaCtrl_wpsFailMsg_f)(void* userData, char* ifName);
typedef void (* wld_wpaCtrl_wpsCredReceivedMsg_f)(void* userData, char* ifName, void* creds, swl_rc_ne status);
typedef void (* wld_wpaCtrl_apStationConnectivityCb_f)(void* userData, char* ifName, swl_macBin_t* bStationMac);
typedef void (* wld_wpaCtrl_btmReplyCb_f)(void* userData, char* ifName, swl_macChar_t* mac, uint8_t status);
typedef void (* wld_wpaCtrl_mgtFrameReceivedCb_f)(void* userData, char* ifName, swl_80211_mgmtFrame_t* frame, size_t frameLen, char* frameStr);
typedef void (* wld_wpaCtrl_stationConnectivityCb_f)(void* userData, char* ifName, swl_macBin_t* bBssidMac, swl_IEEE80211deauthReason_ne reason);
typedef void (* wld_wpaCtrl_stationScanFailedCb_f)(void* userData, char* ifName, int error);
typedef void (* wld_wpaCtrl_beaconResponseCb_f)(void* userData, char* ifName, swl_macBin_t* station, wld_wpaCtrl_rrmBeaconRsp_t* rrmBeaconResponse);

/*
 * @brief structure of AP/EP event handlers
 */
typedef struct {
    wld_wpaCtrl_processMsgCb_f fProcEvtMsg; // Basic handler of received wpa ctrl event
    wld_wpaCtrl_wpsSuccessMsg_f fWpsSuccessMsg;
    wld_wpaCtrl_wpsTimeoutMsg_f fWpsTimeoutMsg;
    wld_wpaCtrl_wpsCancelMsg_f fWpsCancelMsg;
    wld_wpaCtrl_wpsOverlapMsg_f fWpsOverlapMsg;          /** WPS overlap detected in PBC mode */
    wld_wpaCtrl_wpsFailMsg_f fWpsFailMsg;                /** WPS registration failed after M2/M2D */
    wld_wpaCtrl_wpsCredReceivedMsg_f fWpsCredReceivedCb; /** WPS credentials received */
    wld_wpaCtrl_apStationConnectivityCb_f fApStationConnectedCb;
    wld_wpaCtrl_apStationConnectivityCb_f fApStationDisconnectedCb;
    wld_wpaCtrl_btmReplyCb_f fBtmReplyCb;
    wld_wpaCtrl_mgtFrameReceivedCb_f fMgtFrameReceivedCb;
    wld_wpaCtrl_stationConnectivityCb_f fStationDisconnectedCb;
    wld_wpaCtrl_stationConnectivityCb_f fStationConnectedCb;
    wld_wpaCtrl_stationScanFailedCb_f fStationScanFailedCb;
    wld_wpaCtrl_beaconResponseCb_f fBeaconResponseCb;
} wld_wpaCtrl_evtHandlers_cb;

typedef void (* wld_wpaCtrl_chanSwitchStartedCb_f)(void* userData, char* ifName, swl_chanspec_t* chanSpec);
typedef void (* wld_wpaCtrl_chanSwitchCb_f)(void* userData, char* ifName, swl_chanspec_t* chanSpec);
typedef void (* wld_wpaCtrl_apCsaFinishedCb_f)(void* userData, char* ifName, swl_chanspec_t* chanSpec);
typedef void (* wld_wpaCtrl_mngrReadyCb_f)(void* userData, char* ifName, bool isReady);
typedef void (* wld_wpaCtrl_dfsCacStartedCb_f)(void* userData, char* ifName, swl_chanspec_t* chanSpec, uint32_t cac_time);
typedef void (* wld_wpaCtrl_dfsCacDoneCb_f)(void* userData, char* ifName, swl_chanspec_t* chanSpec, bool success);
typedef void (* wld_wpaCtrl_dfsCacExpiredCb_f)(void* userData, char* ifName, swl_chanspec_t* chanSpec);
typedef void (* wld_wpaCtrl_dfsRadarDetectedCb_f)(void* userData, char* ifName, swl_chanspec_t* chanSpec);
typedef void (* wld_wpaCtrl_dfsNopFinishedCb_f)(void* userData, char* ifName, swl_chanspec_t* chanSpec);
typedef void (* wld_wpaCtrl_dfsNewChannelCb_f)(void* userData, char* ifName, swl_chanspec_t* chanSpec);
typedef void (* wld_wpaCtrl_mainApSetupCompletedCb_f)(void* userData, char* ifName);
typedef void (* wld_wpaCtrl_mainApDisabledCb_f)(void* userData, char* ifName);

/*
 * @brief structure of Radio event handlers
 */
typedef struct {
    wld_wpaCtrl_processMsgCb_f fProcEvtMsg; // Basic handler of received wpa ctrl event
    wld_wpaCtrl_chanSwitchStartedCb_f fChanSwitchStartedCb;
    wld_wpaCtrl_chanSwitchCb_f fChanSwitchCb;
    wld_wpaCtrl_apCsaFinishedCb_f fApCsaFinishedCb;
    wld_wpaCtrl_mngrReadyCb_f fMngrReadyCb;
    wld_wpaCtrl_dfsCacStartedCb_f fDfsCacStartedCb;
    wld_wpaCtrl_dfsCacDoneCb_f fDfsCacDoneCb;
    wld_wpaCtrl_dfsCacExpiredCb_f fDfsCacExpiredCb;
    wld_wpaCtrl_dfsRadarDetectedCb_f fDfsRadarDetectedCb;
    wld_wpaCtrl_dfsNopFinishedCb_f fDfsNopFinishedCb;
    wld_wpaCtrl_dfsNewChannelCb_f fDfsNewChannelCb; //fallback after dfs radar detection
    wld_wpaCtrl_mainApSetupCompletedCb_f fMainApSetupCompletedCb;
    wld_wpaCtrl_mainApDisabledCb_f fMainApDisabledCb;
} wld_wpaCtrl_radioEvtHandlers_cb;

int wld_wpaCtrl_getValueStr(const char* pData, const char* pKey, char* pValue, int length);
int wld_wpaCtrl_getValueInt(const char* pData, const char* pKey);
bool wld_wpaCtrl_getValueIntExt(const char* pData, const char* pKey, int32_t* pVal);

#endif /* __WLD_WPA_CTRL_EVENTS_H__ */
