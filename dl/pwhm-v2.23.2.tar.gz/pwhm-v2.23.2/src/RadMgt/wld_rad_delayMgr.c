/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include "wld_common.h"
#include "wld_rad_delayMgr.h"

#define ME "wldDly"

static void s_apDelayUpDone_cb(amxp_timer_t* timer _UNUSED, void* userdata) {
    T_Radio* pR = (T_Radio*) userdata;
    ASSERT_TRUE(debugIsRadPointer(pR), , ME, "INVALID");
    wld_rad_delayMgr_apDelayUpDone(pR);
}

void wld_rad_delayMgr_init(T_Radio* pR) {
    ASSERT_TRUE(debugIsRadPointer(pR), , ME, "INVALID");
    ASSERT_NULL(pR->delayMgr.timer, , ME, "%s timer already initialized", pR->Name);

    SAH_TRACEZ_INFO(ME, "%s init", pR->Name);

    amxp_timer_new(&pR->delayMgr.timer, s_apDelayUpDone_cb, pR);
}

void wld_rad_delayMgr_destroy(T_Radio* pR) {
    ASSERT_TRUE(debugIsRadPointer(pR), , ME, "INVALID");
    ASSERT_NOT_NULL(pR->delayMgr.timer, , ME, "%s timer not initialized", pR->Name);

    SAH_TRACEZ_INFO(ME, "%s destroy", pR->Name);
    amxp_timer_delete(&pR->delayMgr.timer);
    pR->delayMgr.timer = NULL;
}

void wld_rad_delayMgr_startApDelayUp(T_Radio* pR) {
    ASSERT_NOT_NULL(pR, , ME, "NULL");
    if(pR->detailedState != CM_RAD_UP) {
        SAH_TRACEZ_ERROR(ME, "%s: state: %d (expected: %d)", pR->Name, pR->detailedState, CM_RAD_UP);
        return;
    }
    pR->detailedState = CM_RAD_DELAY_AP_UP;
    uint32_t delay = pR->delayMgr.delay;
    amxp_timer_start(pR->delayMgr.timer, delay * 1000);
    SAH_TRACEZ_INFO(ME, "%s: start delay ap up timer (%d)", pR->Name, delay);
}

void wld_rad_delayMgr_apDelayUpDone(T_Radio* pR) {
    ASSERT_NOT_NULL(pR, , ME, "NULL");
    if(pR->detailedState != CM_RAD_DELAY_AP_UP) {
        SAH_TRACEZ_ERROR(ME, "%s: state: %d (expected: %d)", pR->Name, pR->detailedState, CM_RAD_DELAY_AP_UP);
        return;
    }
    SAH_TRACEZ_INFO(ME, "%s: stop timer", pR->Name);
    amxp_timer_stop(pR->delayMgr.timer);
    pR->detailedState = CM_RAD_UP;
    pR->pFA->mfn_wrad_delayApUpDone(pR);
}

amxd_status_t _Radio_apDelayUpDone(amxd_object_t* object,
                                   amxd_function_t* func _UNUSED,
                                   amxc_var_t* args _UNUSED,
                                   amxc_var_t* ret _UNUSED) {
    T_Radio* pR = object->priv;
    ASSERT_NOT_NULL(pR, amxd_status_unknown_error, ME, "NULL");
    wld_rad_delayMgr_apDelayUpDone(pR);
    return amxd_status_ok;
}

amxd_status_t _wld_rad_delayMgr_setDelayApUpPeriod_pwf(amxd_object_t* object _UNUSED,
                                                       amxd_param_t* parameter _UNUSED,
                                                       amxd_action_t reason _UNUSED,
                                                       const amxc_var_t* const args _UNUSED,
                                                       amxc_var_t* const retval _UNUSED,
                                                       void* priv _UNUSED) {
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiRad = object;
    if(amxd_object_get_type(wifiRad) != amxd_object_instance) {
        return rv;
    }
    T_Radio* pR = (T_Radio*) wifiRad->priv;
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    if(rv != amxd_status_ok) {
        return rv;
    }

    SAH_TRACEZ_IN(ME);
    SAH_TRACEZ_INFO(ME, "%p", parameter);

    ASSERT_TRUE(debugIsRadPointer(pR), amxd_status_unknown_error, ME, "NULL");

    pR->delayMgr.delay = amxc_var_dyncast(uint32_t, args);

    SAH_TRACEZ_WARNING(ME, "%s: Update delay timer period to %d", pR->Name, pR->delayMgr.delay);

    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}
