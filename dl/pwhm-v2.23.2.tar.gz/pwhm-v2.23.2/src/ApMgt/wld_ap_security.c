/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2022 SoftAtHome
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <debug/sahtrace.h>
#include <assert.h>



#include "wld.h"
#include "wld_util.h"
#include "wld_accesspoint.h"
#include "wld_ssid.h"
#include "wld_radio.h"
#include "wld_wps.h"
#include "wld_assocdev.h"
#include "swl/swl_assert.h"
#include "wld_ap_rssiMonitor.h"
#include "Utils/wld_autoCommitMgr.h"

#define ME "apSec"

const char* cstr_AP_EncryptionMode[] = {"Default", "AES", "TKIP", "TKIP-AES", 0};

const char* g_str_wld_ap_td[AP_TD_MAX] = {"WPA3-Personal", "SAE-PK", "WPA3-Enterprise", "EnhancedOpen"};


void wld_ap_sec_doSync(T_AccessPoint* pAP) {
    pAP->pFA->mfn_wvap_sec_sync(pAP, SET);
    wld_autoCommitMgr_notifyVapEdit(pAP);
}

/**
 * Check that the security settings are valid.
 **/
amxd_status_t _validateSecurity_pvf(amxd_object_t* obj, void* validationData) {
    _UNUSED_(validationData);
    amxd_param_t* pModeParam = NULL;
    amxd_param_t* pParam = NULL;
    const char* preSharedKey = NULL;
    const char* keyPassPhrase = NULL;
    const char* saePassphrase = NULL;
    const char* wepKey = NULL;
    const char* radiusSecret = NULL;
    const char* modeEnabled = NULL;
    const char* modesAvailableStr = NULL;
    const char* modesSupportedStr = NULL;
    const char* encryptionMode = NULL;
    int ret;
    swl_security_apMode_e modeEnabledId;
    swl_security_apMode_m modesAvailableMask = 0;
    swl_security_apMode_m modesSupportedMask = 0;

    amxc_var_t pVar;
    amxc_var_init(&pVar);

    pModeParam = amxd_object_get_param_def(obj, "ModesAvailable");
    amxd_param_get_value(pModeParam, &pVar);
    modesAvailableStr = amxc_var_get_cstring_t(&pVar);
    assert(modesAvailableStr);

    pModeParam = amxd_object_get_param_def(obj, "ModeEnabled");
    amxd_param_get_value(pModeParam, &pVar);
    modeEnabled = amxc_var_get_cstring_t(&pVar);
    assert(modeEnabled);

    pModeParam = amxd_object_get_param_def(obj, "ModesSupported");
    amxd_param_get_value(pModeParam, &pVar);
    modesSupportedStr = amxc_var_get_cstring_t(&pVar);
    assert(modesSupportedStr);

    pModeParam = amxd_object_get_param_def(obj, "EncryptionMode");
    amxd_param_get_value(pModeParam, &pVar);
    encryptionMode = amxc_var_get_cstring_t(&pVar);
    assert(encryptionMode);

    pParam = amxd_object_get_param_def(obj, "WEPKey");
    amxd_param_get_value(pParam, &pVar);
    wepKey = amxc_var_get_cstring_t(&pVar);
    assert(wepKey);
    if(wepKey && wepKey[0] && !isValidWEPKey(wepKey)) {
        SAH_TRACEZ_ERROR(ME, "isValidWEPKey failed! %s", wepKey);
        return amxd_status_unknown_error;
    }

    pParam = amxd_object_get_param_def(obj, "PreSharedKey");
    amxd_param_get_value(pParam, &pVar);
    preSharedKey = amxc_var_get_cstring_t(&pVar);
    assert(preSharedKey);

    pParam = amxd_object_get_param_def(obj, "KeyPassPhrase");
    amxd_param_get_value(pParam, &pVar);
    keyPassPhrase = amxc_var_get_cstring_t(&pVar);
    assert(keyPassPhrase);

    pParam = amxd_object_get_param_def(obj, "SAEPassphrase");
    amxd_param_get_value(pParam, &pVar);
    saePassphrase = amxc_var_get_cstring_t(&pVar);
    assert(saePassphrase);

    modeEnabledId = swl_security_apModeFromString((char*) modeEnabled);

    // Double check when in WPAx security mode... one of the 2 must be OK!
    if(swl_security_isApModeWPAPersonal(modeEnabledId)) {
        ret = ((preSharedKey && preSharedKey[0] &&
                isValidPSKKey(preSharedKey)) ||
               (keyPassPhrase && keyPassPhrase[0] &&
                isValidAESKey(keyPassPhrase, PSK_KEY_SIZE_LEN - 1)));
        if(!ret) {
            SAH_TRACEZ_ERROR(ME, "isValidPSKKey AND isValidAESKey failed for!");
            if(preSharedKey) {
                SAH_TRACEZ_ERROR(ME, "isValidPSKKey = %s!", preSharedKey);
            }
            if(keyPassPhrase) {
                SAH_TRACEZ_ERROR(ME, "isValidAESKey = %s!", keyPassPhrase);
            }
            return amxd_status_unknown_error;
        }
    }

    pParam = amxd_object_get_param_def(obj, "RadiusSecret");
    amxd_param_get_value(pParam, &pVar);
    radiusSecret = amxc_var_get_cstring_t(&pVar);
    assert(radiusSecret);

    modesSupportedMask = swl_security_apModeMaskFromString(modesSupportedStr);
    modesAvailableMask = swl_security_apModeMaskFromString(modesAvailableStr);

    T_AccessPoint* pAP = amxd_object_get_parent(obj)->priv;
    if((modesSupportedMask != 0) && (modesAvailableMask == 0)) {
        modesAvailableMask = modesSupportedMask;
        char TBuf[256] = {0};
        swl_security_apModeMaskToString(TBuf, sizeof(TBuf), SWL_SECURITY_APMODEFMT_LEGACY, modesAvailableMask);
        if(pAP && debugIsVapPointer(pAP)) {
            amxc_var_t value;
            amxc_var_init(&value);
            amxc_var_set(cstring_t, &value, TBuf);
            amxd_param_t* parameter = amxd_object_get_param_def(obj, "ModesAvailable");
            amxd_param_set_value(parameter, &value);
            amxc_var_clean(&value);
        }
    }
    if((modesSupportedMask != 0) && !(modesSupportedMask & modesAvailableMask)) {
        SAH_TRACEZ_ERROR(ME, "ModesAvailable not supported");
        return amxd_status_unknown_error;
    }


    if((modesAvailableMask != 0) && !(SWL_BIT_IS_SET(modesAvailableMask, modeEnabledId))) {
        if(SWL_BIT_IS_SET(modesAvailableMask, SWL_SECURITY_APMODE_WPA3_P) && (modeEnabledId == SWL_SECURITY_APMODE_WPA2_P)) {
            amxc_var_t value;
            amxc_var_init(&value);
            amxc_var_set(cstring_t, &value, swl_security_apModeToString(SWL_SECURITY_APMODE_WPA3_P, SWL_SECURITY_APMODEFMT_LEGACY));
            amxd_param_t* parameter = amxd_object_get_param_def(obj, "ModeEnabled");
            amxd_param_set_value(parameter, &value);
            SAH_TRACEZ_WARNING(ME, "%s: Default WPA2 set but not available, setting to available WPA3", pAP->alias);
            amxc_var_clean(&value);
        } else {
            SAH_TRACEZ_ERROR(ME, "%s: ModeEnabled %s not available 0x%02x", pAP->alias, modeEnabled, modesAvailableMask);
            if(pAP && debugIsVapPointer(pAP)) {
                if(SWL_BIT_IS_SET(modesAvailableMask, SWL_SECURITY_APMODE_WPA2_P)) {
                    SAH_TRACEZ_ERROR(ME, "%s: reverting to WPA2 from ", pAP->alias);
                    amxc_var_t value;
                    amxc_var_init(&value);
                    amxc_var_set(cstring_t, &value, swl_security_apModeToString(SWL_SECURITY_APMODE_WPA2_P, SWL_SECURITY_APMODEFMT_LEGACY));
                    amxd_param_t* parameter = amxd_object_get_param_def(obj, "ModeEnabled");
                    amxd_param_set_value(parameter, &value);
                }
                if(SWL_BIT_IS_SET(modesAvailableMask, SWL_SECURITY_APMODE_WPA3_P)) {
                    amxc_var_t value;
                    amxc_var_init(&value);
                    amxc_var_set(cstring_t, &value, swl_security_apModeToString(SWL_SECURITY_APMODE_WPA3_P, SWL_SECURITY_APMODEFMT_LEGACY));
                    amxd_param_t* parameter = amxd_object_get_param_def(obj, "ModeEnabled");
                    amxd_param_set_value(parameter, &value);
                } else {
                    SAH_TRACEZ_ERROR(ME, "%s: unable to revert to WPA2, not available", pAP->alias);
                }
            }
            return amxd_status_unknown_error;
        }
    }

    switch(modeEnabledId) {
    case SWL_SECURITY_APMODE_NONE:
    case SWL_SECURITY_APMODE_OWE:
        return amxd_status_ok;
    case SWL_SECURITY_APMODE_WEP64:        /* 5/10 */
    case SWL_SECURITY_APMODE_WEP128:       /* 13/26 */
    case SWL_SECURITY_APMODE_WEP128IV:     /* 16/32 */
        /* BUG 49483 - SOP screwed WEP, result many targets fail
           Our WebUI can't change the WEP key if there's no Key filled in.
           See this as a HACK to get around most of the trouble!
         */
        if(wepKey && !wepKey[0]) {
            /* No WEP key filled in... Generate a valid WEP-128 key! */
            T_AccessPoint* pAP = NULL;

            pAP = amxd_object_get_parent(obj)->priv;
            if(pAP && debugIsVapPointer(pAP)) {
                get_randomstr((unsigned char*) pAP->WEPKey, 13);

                /* push the WEP key directly to the datamodel! */
                amxc_var_t value;
                amxc_var_init(&value);
                amxc_var_set(cstring_t, &value, (const char*) pAP->WEPKey);
                amxd_param_t* parameter = amxd_object_get_param_def(obj, "WEPKey");
                amxd_param_set_value(parameter, &value);

                return amxd_status_ok;     /* It's OK, continue! */
            }
        }
        return (isValidWEPKey(wepKey)) ? true : false;

    case SWL_SECURITY_APMODE_WPA_P:
        if(isValidPSKKey(preSharedKey)) {
            return amxd_status_ok;
        }
        return isValidAESKey(keyPassPhrase, PSK_KEY_SIZE_LEN - 1);
    case SWL_SECURITY_APMODE_WPA2_P:
    case SWL_SECURITY_APMODE_WPA_WPA2_P:
    case SWL_SECURITY_APMODE_WPA2_WPA3_P:
        return isValidAESKey(keyPassPhrase, PSK_KEY_SIZE_LEN - 1);
    case SWL_SECURITY_APMODE_WPA3_P:
        if(swl_str_matches(saePassphrase, "")) {
            return isValidAESKey(keyPassPhrase, PSK_KEY_SIZE_LEN - 1);
        } else {
            return isValidAESKey(saePassphrase, SAE_KEY_SIZE_LEN);
        }
    case SWL_SECURITY_APMODE_WPA_E:
        if(isValidPSKKey(radiusSecret)) {
            return amxd_status_ok;
        }
        return isValidAESKey(keyPassPhrase, PSK_KEY_SIZE_LEN - 1);
    case SWL_SECURITY_APMODE_WPA2_E:
    case SWL_SECURITY_APMODE_WPA_WPA2_E:
    case SWL_SECURITY_APMODE_WPA2_WPA3_E:
    case SWL_SECURITY_APMODE_WPA3_E:
        // The only technical limitation is that shared secrets must be greater than 0 in length!
        ret = strlen(radiusSecret);
        return (ret >= 1 && ret < 64) ? true : false;

    default:
        SAH_TRACEZ_ERROR(ME, "Unknown mode %s", modeEnabled);
        return amxd_status_unknown_error;
    }

    /* Unknown mode? */
    return amxd_status_unknown_error;
}

amxd_status_t _wld_ap_validateWEPKey_pvf(amxd_object_t* object _UNUSED,
                                         amxd_param_t* param,
                                         amxd_action_t reason _UNUSED,
                                         const amxc_var_t* const args,
                                         amxc_var_t* const retval _UNUSED,
                                         void* priv _UNUSED) {
    amxd_status_t status = amxd_status_invalid_value;
    const char* currentValue = amxc_var_constcast(cstring_t, &param->value);
    ASSERT_NOT_NULL(currentValue, status, ME, "NULL");
    char* newValue = amxc_var_dyncast(cstring_t, args);
    if(swl_str_matches(currentValue, newValue) || (isValidWEPKey(newValue) != SWL_SECURITY_APMODE_UNKNOWN)) {
        status = amxd_status_ok;
    } else {
        SAH_TRACEZ_ERROR(ME, "invalid WEPKey (%s)", newValue);
    }
    free(newValue);
    return status;
}

amxd_status_t _wld_ap_setWEPKey_pwf(amxd_object_t* object,
                                    amxd_param_t* parameter,
                                    amxd_action_t reason,
                                    const amxc_var_t* const args,
                                    amxc_var_t* const retval,
                                    void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    char* newValue = amxc_var_dyncast(cstring_t, args); // Get the Key
    ASSERT_NOT_NULL(newValue, rv, ME, "NULL");
    SAH_TRACEZ_INFO(ME, "%s: WEPKey (%s)", pAP->alias, newValue);

    /* We got as return the correct WEP key format used... */
    swl_str_copy(pAP->WEPKey, sizeof(pAP->WEPKey), newValue);

    wld_ap_sec_doSync(pAP);
    free(newValue);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_setMFPConfig_pwf(amxd_object_t* object,
                                       amxd_param_t* parameter,
                                       amxd_action_t reason,
                                       const amxc_var_t* const args,
                                       amxc_var_t* const retval,
                                       void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    const char* mfpStr = amxc_var_constcast(cstring_t, args);
    pAP->mfpConfig = swl_security_mfpModeFromString(mfpStr);
    wld_ap_sec_doSync(pAP);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_setModesAvailable_pwf(amxd_object_t* object,
                                            amxd_param_t* parameter,
                                            amxd_action_t reason,
                                            const amxc_var_t* const args,
                                            amxc_var_t* const retval,
                                            void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    const char* modesAvailable = amxc_var_constcast(cstring_t, args);
    if(modesAvailable && modesAvailable[0]) {
        pAP->secModesAvailable = swl_security_apModeMaskFromString(modesAvailable);
    } else {
        pAP->secModesAvailable = pAP->secModesSupported;
    }
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_setModeEnabled_pwf(amxd_object_t* object,
                                         amxd_param_t* parameter,
                                         amxd_action_t reason,
                                         const amxc_var_t* const args,
                                         amxc_var_t* const retval,
                                         void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");

    const char* mode = amxc_var_constcast(cstring_t, args);
    swl_security_apMode_e idx = swl_security_apModeFromString((char*) mode);
    switch(idx) {
    case SWL_SECURITY_APMODE_NONE:
    case SWL_SECURITY_APMODE_OWE:
        /* If we must enable MAC filter... it must be here */
        break;
    case SWL_SECURITY_APMODE_WEP64:    /* 5/10 */
    case SWL_SECURITY_APMODE_WEP128:   /* 13/26 */
    case SWL_SECURITY_APMODE_WEP128IV: /* 16/32 */
        /* Before changing... check if we've a valid WEP key */
        ASSERT_TRUE(isValidWEPKey(pAP->WEPKey), amxd_status_unknown_error, ME, "Invalid WEPKey(%s) in WEP mode", pAP->WEPKey);
        break;
    case SWL_SECURITY_APMODE_WPA_P:
        if((!isValidPSKKey(pAP->preSharedKey)) &&
           (!isValidAESKey(pAP->keyPassPhrase, PSK_KEY_SIZE_LEN - 1))) {
            SAH_TRACEZ_ERROR(ME, "No valid PSK(%s) KeyPP(%s) in WPA-TKIP mode", pAP->preSharedKey, pAP->keyPassPhrase);
            return amxd_status_unknown_error;
        }
        break;
    case SWL_SECURITY_APMODE_WPA2_P:
    case SWL_SECURITY_APMODE_WPA_WPA2_P:
    case SWL_SECURITY_APMODE_WPA2_WPA3_P:
        ASSERT_TRUE(isValidAESKey((char*) pAP->keyPassPhrase, PSK_KEY_SIZE_LEN - 1), amxd_status_unknown_error,
                    ME, "Invalid AESKey(%s) in WPA(x)-AES mode", pAP->keyPassPhrase);
        break;
    case SWL_SECURITY_APMODE_WPA3_P:
        if(swl_str_isEmpty(pAP->saePassphrase)) {
            ASSERT_TRUE(isValidAESKey(pAP->keyPassPhrase, PSK_KEY_SIZE_LEN - 1), amxd_status_unknown_error,
                        ME, "Invalid AESKey(%s) in WPA3 mode", pAP->keyPassPhrase);
        } else {
            ASSERT_TRUE(isValidAESKey(pAP->saePassphrase, SAE_KEY_SIZE_LEN), amxd_status_unknown_error,
                        ME, "Invalid SAE PassPhrase(%s) in WPA3 mode", pAP->saePassphrase);
        }
        break;
    case SWL_SECURITY_APMODE_WPA_E:
        if((!isValidPSKKey(pAP->radiusSecret)) &&
           (!isValidAESKey(pAP->keyPassPhrase, PSK_KEY_SIZE_LEN - 1))) {
            SAH_TRACEZ_ERROR(ME, "No valid RadSecret(%s) KeyPP(%s) in WPA-Enterprise mode", pAP->radiusSecret, pAP->keyPassPhrase);
            return amxd_status_unknown_error;
        }
        break;
    case SWL_SECURITY_APMODE_WPA2_E:
    case SWL_SECURITY_APMODE_WPA_WPA2_E:
    case SWL_SECURITY_APMODE_WPA3_E:
    case SWL_SECURITY_APMODE_WPA2_WPA3_E:
    {
        int radSecLen = strlen(pAP->radiusSecret);
        ASSERT_TRUE((radSecLen >= 8) && (radSecLen < 64), amxd_status_unknown_error,
                    ME, "Invalid radius secret (%s) length(8-63) in WPAx-Enterprise mode", pAP->radiusSecret);
        break;
    }
    case SWL_SECURITY_APMODE_UNKNOWN:
    default:
        SAH_TRACEZ_ERROR(ME, "%s : unknown security mode %s", pAP->alias, mode);
        return amxd_status_unknown_error;
        break;
    }

    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    pAP->secModeEnabled = idx;
    SAH_TRACEZ_INFO(ME, "Security Mode Enable %s %d", mode, idx);

    wld_ap_sec_doSync(pAP);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_validatePreSharedKey_pvf(amxd_object_t* object _UNUSED,
                                               amxd_param_t* param,
                                               amxd_action_t reason _UNUSED,
                                               const amxc_var_t* const args,
                                               amxc_var_t* const retval _UNUSED,
                                               void* priv _UNUSED) {
    amxd_status_t status = amxd_status_invalid_value;
    const char* currentValue = amxc_var_constcast(cstring_t, &param->value);
    ASSERT_NOT_NULL(currentValue, status, ME, "NULL");
    char* newValue = amxc_var_dyncast(cstring_t, args);
    if(swl_str_matches(currentValue, newValue) || isValidPSKKey(newValue)) {
        status = amxd_status_ok;
    } else {
        SAH_TRACEZ_ERROR(ME, "invalid PreSharedKey (%s)", newValue);
    }
    free(newValue);
    return status;
}

amxd_status_t _wld_ap_setPreSharedKey_pwf(amxd_object_t* object,
                                          amxd_param_t* parameter,
                                          amxd_action_t reason,
                                          const amxc_var_t* const args,
                                          amxc_var_t* const retval,
                                          void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    char* psk = amxc_var_dyncast(cstring_t, args);
    SAH_TRACEZ_INFO(ME, "WPA-TKIP Psk(%s)", psk);
    swl_str_copy(pAP->preSharedKey, sizeof(pAP->preSharedKey), psk);
    wld_ap_sec_doSync(pAP);
    free(psk);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_validateKeyPassPhrase_pvf(amxd_object_t* object _UNUSED,
                                                amxd_param_t* param,
                                                amxd_action_t reason _UNUSED,
                                                const amxc_var_t* const args,
                                                amxc_var_t* const retval _UNUSED,
                                                void* priv _UNUSED) {
    amxd_status_t status = amxd_status_invalid_value;
    const char* currentValue = amxc_var_constcast(cstring_t, &param->value);
    ASSERT_NOT_NULL(currentValue, status, ME, "NULL");
    char* newValue = amxc_var_dyncast(cstring_t, args);
    ASSERT_NOT_NULL(newValue, status, ME, "NULL");
    if(swl_str_matches(currentValue, newValue) || isValidAESKey(newValue, PSK_KEY_SIZE_LEN - 1)) {
        status = amxd_status_ok;
    } else {
        SAH_TRACEZ_ERROR(ME, "Invalid AES Key (%s)", newValue);
    }
    free(newValue);
    return status;
}

amxd_status_t _wld_ap_setKeyPassPhrase_pwf(amxd_object_t* object,
                                           amxd_param_t* parameter,
                                           amxd_action_t reason,
                                           const amxc_var_t* const args,
                                           amxc_var_t* const retval,
                                           void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    char* newPassphrase = amxc_var_dyncast(cstring_t, args);
    SAH_TRACEZ_INFO(ME, "%s: WPA-AES %s", pAP->alias, newPassphrase);
    T_SSID* pSSID = pAP->pSSID;
    bool passUpdated = (pSSID && !wldu_key_matches(pSSID->SSID, newPassphrase, pAP->keyPassPhrase));
    swl_str_copy(pAP->keyPassPhrase, sizeof(pAP->keyPassPhrase), newPassphrase);
    if(passUpdated) {
        wld_ap_sec_doSync(pAP);
    } else {
        SAH_TRACEZ_INFO(ME, "%s: Same key is used, no need to sync %s", pAP->alias, newPassphrase);
    }
    free(newPassphrase);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_validateSaePassphrase_pvf(amxd_object_t* object _UNUSED,
                                                amxd_param_t* param,
                                                amxd_action_t reason _UNUSED,
                                                const amxc_var_t* const args,
                                                amxc_var_t* const retval _UNUSED,
                                                void* priv _UNUSED) {
    amxd_status_t status = amxd_status_invalid_value;
    const char* currentValue = amxc_var_constcast(cstring_t, &param->value);
    ASSERT_NOT_NULL(currentValue, status, ME, "NULL");
    char* newValue = amxc_var_dyncast(cstring_t, args);
    ASSERT_NOT_NULL(newValue, status, ME, "NULL");
    if(swl_str_matches(currentValue, newValue) || isValidAESKey(newValue, SAE_KEY_SIZE_LEN)) {
        status = amxd_status_ok;
    } else {
        SAH_TRACEZ_ERROR(ME, "Invalid SAE Key (%s)", newValue);
    }
    free(newValue);
    return status;
}

amxd_status_t _wld_ap_setSaePassphrase_pwf(amxd_object_t* object,
                                           amxd_param_t* parameter,
                                           amxd_action_t reason,
                                           const amxc_var_t* const args,
                                           amxc_var_t* const retval,
                                           void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    char* newPassphrase = amxc_var_dyncast(cstring_t, args);
    SAH_TRACEZ_INFO(ME, "%s: WPA-AES %s", pAP->alias, newPassphrase);
    T_SSID* pSSID = pAP->pSSID;
    bool passUpdated = (pSSID && !wldu_key_matches(pSSID->SSID, newPassphrase, pAP->saePassphrase));
    swl_str_copy(pAP->saePassphrase, sizeof(pAP->saePassphrase), newPassphrase);
    if(passUpdated) {
        wld_ap_sec_doSync(pAP);
    } else {
        SAH_TRACEZ_INFO(ME, "%s: Same key is used, no need to sync %s", pAP->alias, newPassphrase);
    }
    free(newPassphrase);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_setEncryptionMode_pwf(amxd_object_t* object,
                                            amxd_param_t* parameter,
                                            amxd_action_t reason,
                                            const amxc_var_t* const args,
                                            amxc_var_t* const retval,
                                            void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    const char* newMode = amxc_var_constcast(cstring_t, args);
    pAP->encryptionModeEnabled = conv_strToEnum(cstr_AP_EncryptionMode, newMode, APEMI_MAX, APEMI_DEFAULT);
    wld_ap_sec_doSync(pAP);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_setRekeyInterval_pwf(amxd_object_t* object,
                                           amxd_param_t* parameter,
                                           amxd_action_t reason,
                                           const amxc_var_t* const args,
                                           amxc_var_t* const retval,
                                           void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);

    // They are handled in SyncData_AP2OBJ()
    wld_ap_sec_doSync(pAP);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_setRadiusInfo_pwf(amxd_object_t* object,
                                        amxd_param_t* parameter,
                                        amxd_action_t reason,
                                        const amxc_var_t* const args,
                                        amxc_var_t* const retval,
                                        void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    // They are handled in SyncData_AP2OBJ()
    wld_ap_sec_doSync(pAP);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_setSHA256Enable_pwf(amxd_object_t* object,
                                          amxd_param_t* parameter,
                                          amxd_action_t reason,
                                          const amxc_var_t* const args,
                                          amxc_var_t* const retval,
                                          void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    pAP->SHA256Enable = amxc_var_dyncast(bool, args);
    wld_ap_sec_doSync(pAP);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_setOweTransitionIntf_pwf(amxd_object_t* object,
                                               amxd_param_t* parameter,
                                               amxd_action_t reason,
                                               const amxc_var_t* const args,
                                               amxc_var_t* const retval,
                                               void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    char* oweTransIntf = amxc_var_dyncast(cstring_t, args);
    swl_str_copy(pAP->oweTransModeIntf, sizeof(pAP->oweTransModeIntf), oweTransIntf);
    wld_ap_sec_doSync(pAP);
    free(oweTransIntf);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}

amxd_status_t _wld_ap_setTransitionDisable_pwf(amxd_object_t* object,
                                               amxd_param_t* parameter,
                                               amxd_action_t reason,
                                               const amxc_var_t* const args,
                                               amxc_var_t* const retval,
                                               void* priv) {
    SAH_TRACEZ_IN(ME);
    amxd_status_t rv = amxd_status_ok;
    amxd_object_t* wifiVap = amxd_object_get_parent(object);
    ASSERTI_EQUALS(amxd_object_get_type(wifiVap), amxd_object_instance, rv, ME, "Not instance");
    T_AccessPoint* pAP = (T_AccessPoint*) wifiVap->priv;
    ASSERT_TRUE(debugIsVapPointer(pAP), amxd_status_unknown_error, ME, "Invalid AP Ctx");
    rv = amxd_action_param_write(object, parameter, reason, args, retval, priv);
    ASSERT_EQUALS(rv, amxd_status_ok, rv, ME, "ERR status:%d", rv);
    const char* tdStr = amxc_var_constcast(cstring_t, args);
    wld_ap_td_m transitionDisable = swl_conv_charToMask(tdStr, g_str_wld_ap_td, AP_TD_MAX);
    ASSERTI_NOT_EQUALS(transitionDisable, pAP->transitionDisable, amxd_status_ok, ME, "%s: no change", pAP->alias);
    pAP->transitionDisable = transitionDisable;
    wld_ap_sec_doSync(pAP);
    SAH_TRACEZ_OUT(ME);
    return amxd_status_ok;
}
