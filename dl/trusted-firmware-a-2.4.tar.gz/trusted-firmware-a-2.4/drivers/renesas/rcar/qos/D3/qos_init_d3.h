/*
 * Copyright (c) 2015-2017, Renesas Electronics Corporation
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef QOS_INIT_H_D3__
#define QOS_INIT_H_D3__

void qos_init_d3(void);

#endif	/* QOS_INIT_H_D3__ */
