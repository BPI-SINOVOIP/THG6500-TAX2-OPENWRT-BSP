Contributor Acknowledgements
============================

.. note::
   This file is only relevant for legacy contributions, to acknowledge the
   specific contributors referred to in "Arm Limited and Contributors" copyright
   notices. As contributors are now encouraged to put their name or company name
   directly into the copyright notices, this file is not relevant for new
   contributions. See the :ref:`License` document for the correct template to
   use for new contributions.

- Linaro Limited
- Marvell International Ltd.
- NVIDIA Corporation
- NXP Semiconductors
- Socionext Inc.
- STMicroelectronics
- Xilinx, Inc.

--------------

*Copyright (c) 2019, Arm Limited. All rights reserved.*
